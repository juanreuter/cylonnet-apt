// CylonNet: el ícono WireGuard del escritorio (v0.18) va debajo de "Red" en los escritorios armados antes.
// Sin posición guardada, Plasma lo pondría en el primer lugar libre, que es la fila de la línea de estado.
// Plasma corre este script una sola vez por usuario; solo toca escritorios con orden manual.
desktops().forEach(function (d) {
    d.currentConfigGroup = ["General"];
    if (String(d.readConfig("sortMode", 0)) !== "-1") {
        return;
    }
    var resoluciones;
    try {
        resoluciones = JSON.parse(d.readConfig("positions", "{}"));
    } catch (e) {
        return;
    }
    var cambio = false;
    for (var r in resoluciones) {
        var p = resoluciones[r];
        if (p.indexOf("desktop:/wireguard.desktop") >= 0) {
            continue;
        }
        // Primera fila libre de la columna 0, desde la 1 (la 0 es la de la línea de estado)
        var ocupadas = {};
        for (var i = 2; i + 2 < p.length; i += 3) {
            if (p[i + 1] === "0") {
                ocupadas[p[i + 2]] = true;
            }
        }
        var fila = 1;
        while (ocupadas[String(fila)]) {
            fila++;
        }
        p.push("desktop:/wireguard.desktop", "0", String(fila));
        if (Number(p[1]) <= fila) {
            p[1] = String(fila + 1);
        }
        cambio = true;
    }
    if (cambio) {
        d.writeConfig("positions", JSON.stringify(resoluciones));
    }
});
