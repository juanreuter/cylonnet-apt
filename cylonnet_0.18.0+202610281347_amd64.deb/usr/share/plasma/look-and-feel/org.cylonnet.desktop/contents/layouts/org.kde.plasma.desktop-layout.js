// Disposición inicial del escritorio de CylonNet OS (primer inicio de sesión).
// Barra abajo al estilo Windows 10: inicio y apps fijadas a la izquierda, bandeja y reloj a la derecha.

var panel = new Panel;
panel.location = "bottom";
panel.height = Math.round(gridUnit * 2.6);
panel.floating = false;

var inicio = panel.addWidget("org.kde.plasma.kickoff");
inicio.currentConfigGroup = ["General"];
inicio.writeConfig("icon", "cylonnet-start");
// Favoritos del menú: nombres de .desktop sin el prefijo "applications:"
inicio.writeConfig("favorites", [
    "google-chrome.desktop",
    "cylonnet-mi-equipo.desktop",
    "cylonnet-winbox.desktop",
    "org.wireshark.Wireshark.desktop",
    "ai.storyteller.wordcraft.desktop",
    "ai.storyteller.gridcraft.desktop",
    "ai.storyteller.pdfcraft.desktop",
    "systemsettings.desktop"
]);
inicio.currentConfigGroup = ["Shortcuts"];
inicio.writeConfig("global", "Alt+F1");

var tareas = panel.addWidget("org.kde.plasma.icontasks");
tareas.currentConfigGroup = ["General"];
// Accesos fijados (los cylonnet-* están en /usr/share/applications).
// Tiene que ser una lista: si se pasa un texto separado por comas, Plasma lo toma como un único acceso.
tareas.writeConfig("launchers", [
    "applications:cylonnet-buscar.desktop",
    "applications:cylonnet-mi-equipo.desktop",
    "applications:google-chrome.desktop",
    "applications:cylonnet-terminal.desktop",
    "applications:cylonnet-terminal-admin.desktop",
    "applications:org.kde.kcalc.desktop",
    "applications:cylonnet-speedtest.desktop",
    "applications:cylonnet-winbox.desktop",
    "applications:org.wireshark.Wireshark.desktop",
    "applications:putty.desktop"
]);

panel.addWidget("org.kde.plasma.panelspacer");

panel.addWidget("org.kde.plasma.systemtray");

var reloj = panel.addWidget("org.kde.plasma.digitalclock");
reloj.currentConfigGroup = ["Appearance"];
reloj.writeConfig("showDate", true);
reloj.writeConfig("dateFormat", "custom");
reloj.writeConfig("customDateFormat", "dd.MM.yyyy");
reloj.writeConfig("use24hFormat", 2);
reloj.writeConfig("autoFontAndSize", false);
reloj.writeConfig("fontFamily", "IBM Plex Mono");
reloj.writeConfig("fontSize", 10);

panel.addWidget("org.kde.plasma.showdesktop");

// Sin panel arriba: el ojo Cylon y la línea de estado están en el fondo (como en el login). Un panel
// invisible que se corría ante las ventanas reaparecía al tocar el borde de arriba y tapaba la barra
// de título de las maximizadas. Los widgets y los íconos se ubican debajo de esa franja.
var FRANJA = 64;

// Fondo animado con el visor y widgets Sistema y Tráfico de red a la derecha, en cada pantalla
var escritorios = desktops();
for (var i = 0; i < escritorios.length; i++) {
    var d = escritorios[i];
    d.wallpaperPlugin = "org.cylonnet.visor";
    d.currentConfigGroup = ["Wallpaper", "org.cylonnet.visor", "General"];
    d.writeConfig("Animated", true);
    d.writeConfig("Speed", 3);

    var g = screenGeometry(d.screen);
    // En pantallas bajas (1366×768) van compactos, arriba, sin tapar el emblema CN de abajo
    var chica = g.height < 900;
    var ancho = chica ? 175 : 210;
    var altoSistema = chica ? 130 : 150;
    var altoTrafico = chica ? 115 : 135;
    // Justo bajo la línea de estado
    var y = FRANJA + 8;
    var x = g.width - 24 - ancho;
    d.addWidget("org.cylonnet.sistema", x, y, ancho, altoSistema);
    d.addWidget("org.cylonnet.trafico", x, y + altoSistema + (chica ? 10 : 16), ancho, altoTrafico);

    // Íconos del escritorio en una columna a la izquierda, desde la segunda fila para no pisar la línea
    // de estado. Las posiciones solo valen con orden manual (sortMode -1); formato de Plasma:
    // [columnas, filas por columna, y por ícono: url, columna, fila], por resolución.
    d.currentConfigGroup = ["General"];
    d.writeConfig("arrangement", 1);
    d.writeConfig("sortMode", -1);
    // Grilla más junta que la de Plasma (64 px y dos líneas de texto por ícono): 48 px y una línea,
    // con etiquetas anchas para que "Asistente de red" no se corte
    d.writeConfig("iconSize", 2);
    d.writeConfig("textLines", 1);
    d.writeConfig("labelWidth", 2);
    // "Instalar CylonNet" solo existe en modo vivo; sin posición fija caía en la fila de la línea de estado
    var posiciones = ["1", "8"];
    ["papelera", "asistente", "equipo", "guia", "red", "wireguard", "cylonnet-instalar"].forEach(function (n, fila) {
        posiciones.push("desktop:/" + n + ".desktop", "0", String(fila + 1));
    });
    var resolucion = {};
    resolucion[g.width + "x" + g.height] = posiciones;
    d.writeConfig("positions", JSON.stringify(resolucion));
}
