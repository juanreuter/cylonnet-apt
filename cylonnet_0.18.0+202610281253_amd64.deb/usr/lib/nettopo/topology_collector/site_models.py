from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class SourceConfig:
    type: str
    name: str
    enabled: bool
    settings: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SiteConfig:
    site_name: str
    sources: list[SourceConfig]
    default_credentials: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class CollectionResult:
    source_type: str
    source_name: str
    snapshot: dict[str, Any] | None = None
    warnings: list[str] = field(default_factory=list)

