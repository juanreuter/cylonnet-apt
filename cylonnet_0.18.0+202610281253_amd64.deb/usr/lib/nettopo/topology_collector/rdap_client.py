"""
Cliente RDAP para resolver el nombre de organización de IPs públicas.
Consulta rdap.org (sin auth, gratuito) con cache en disco y lookups paralelos.
"""
from __future__ import annotations

import ipaddress
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

_PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("100.64.0.0/10"),
    ipaddress.ip_network("0.0.0.0/8"),
]


def is_private_ip(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        if addr.is_loopback or addr.is_link_local or addr.is_multicast:
            return True
        return any(addr in net for net in _PRIVATE_NETWORKS)
    except ValueError:
        return True


class RdapClient:
    _RDAP_URL = "https://rdap.org/ip/{ip}"
    _UA = "network-topology-mvp/1.0 (educational)"

    def __init__(self, cache_path: Path | None = None, timeout: float = 4.0) -> None:
        self._cache: dict[str, str] = {}
        self._cache_path = cache_path
        self._timeout = timeout
        self._load_cache()

    def _load_cache(self) -> None:
        if self._cache_path and self._cache_path.exists():
            try:
                self._cache = json.loads(self._cache_path.read_text(encoding="utf-8"))
            except Exception:
                pass

    def _save_cache(self) -> None:
        if not self._cache_path:
            return
        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            self._cache_path.write_text(
                json.dumps(self._cache, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    def lookup(self, ip: str) -> str:
        """Devuelve el nombre de org para una IP pública, '' si es privada/desconocida."""
        if is_private_ip(ip):
            return ""
        if ip in self._cache:
            return self._cache[ip]
        org = self._fetch(ip)
        self._cache[ip] = org
        self._save_cache()
        return org

    def lookup_many(self, ips: list[str]) -> dict[str, str]:
        """Resuelve múltiples IPs en paralelo. Devuelve {ip: org_name}."""
        to_fetch = [ip for ip in set(ips) if not is_private_ip(ip) and ip not in self._cache]
        if to_fetch:
            with ThreadPoolExecutor(max_workers=6) as pool:
                futures = {pool.submit(self._fetch, ip): ip for ip in to_fetch}
                for future in as_completed(futures):
                    ip = futures[future]
                    self._cache[ip] = future.result()
            self._save_cache()
        return {ip: self._cache.get(ip, "") for ip in ips}

    def _fetch(self, ip: str) -> str:
        try:
            req = Request(
                self._RDAP_URL.format(ip=ip),
                headers={"Accept": "application/json", "User-Agent": self._UA},
            )
            with urlopen(req, timeout=self._timeout) as resp:
                data: dict[str, Any] = json.loads(resp.read().decode("utf-8"))

            # 1. campo "name" directo (ej. "GOOGLE", "CLOUDFLARE")
            name = str(data.get("name") or "").strip()
            if name:
                return name

            # 2. primer entity con vcard fn
            for entity in data.get("entities", []):
                vcard = entity.get("vcardArray") or []
                entries = vcard[1] if len(vcard) > 1 and isinstance(vcard[1], list) else []
                for entry in entries:
                    if isinstance(entry, (list, tuple)) and len(entry) >= 4 and entry[0] == "fn":
                        fn = str(entry[3]).strip()
                        if fn:
                            return fn
            return ""
        except Exception:
            return ""
