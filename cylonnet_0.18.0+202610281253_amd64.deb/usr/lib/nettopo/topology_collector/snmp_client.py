from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass


class SnmpUnavailableError(RuntimeError):
    pass


class SnmpCollectionError(RuntimeError):
    pass


@dataclass(slots=True)
class SnmpTargetConfig:
    host: str
    port: int = 161
    version: str = "2c"
    community: str = "public"
    timeout_seconds: int = 3
    retries: int = 1
    # SNMP v3 (version="3"): usuario, autenticación (SHA, SHA-256, MD5...) y cifrado (AES, DES...)
    security_name: str = ""
    auth_protocol: str = "SHA"
    auth_password: str = ""
    priv_protocol: str = "AES"
    priv_password: str = ""


AUTH_PROTOCOLS = ("MD5", "SHA", "SHA-224", "SHA-256", "SHA-384", "SHA-512")
PRIV_PROTOCOLS = ("DES", "AES", "AES-192", "AES-256")


def _check_tools() -> None:
    if not shutil.which("snmpget"):
        raise SnmpUnavailableError(
            "No se encontro snmpget. Instalar snmp habilita el collector snmp-generic."
        )


def _version_flag(version: str) -> str:
    if version in ("1", "2c", "3"):
        return version
    raise SnmpCollectionError(f"Version SNMP no valida: '{version}' (usar 1, 2c o 3).")


def _security_level(config: SnmpTargetConfig) -> str:
    if not config.auth_password:
        return "noAuthNoPriv"
    return "authPriv" if config.priv_password else "authNoPriv"


def _conf_line(key: str, value: str) -> str:
    if any(c in value for c in "\r\n"):
        raise SnmpCollectionError("Las credenciales SNMP no pueden tener saltos de linea.")
    return f"{key} {value}\n"


def _parse_value(line: str) -> str:
    """Extract value from 'OID = Type: Value' or 'OID = Value'."""
    if "=" not in line:
        return line.strip()
    _, rest = line.split("=", 1)
    rest = rest.strip()
    if ":" in rest:
        rest = rest.split(":", 1)[1].strip()
    if len(rest) >= 2 and rest[0] == rest[-1] == '"':
        rest = rest[1:-1]
    return rest


class SimpleSnmpClient:
    """Cliente SNMP sobre las herramientas de net-snmp (snmpget/snmpwalk).

    La comunidad y las claves de v3 no van en la linea de comandos (las veria cualquiera con
    `ps`): se escriben en un snmp.conf temporal, solo legible por el usuario, y net-snmp lo lee
    por SNMPCONFPATH.
    """

    def __init__(self, config: SnmpTargetConfig) -> None:
        self.config = config
        _check_tools()
        _version_flag(config.version)
        if config.version == "3" and not config.security_name:
            raise SnmpCollectionError("SNMP v3 necesita un usuario (security name).")
        self._dir = tempfile.TemporaryDirectory(prefix="nettopo-snmp-")
        os.chmod(self._dir.name, 0o700)
        conf = os.path.join(self._dir.name, "snmp.conf")
        fd = os.open(conf, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as archivo:
            if config.version == "3":
                archivo.write(_conf_line("defSecurityName", config.security_name))
                archivo.write(_conf_line("defSecurityLevel", _security_level(config)))
                if config.auth_password:
                    archivo.write(_conf_line("defAuthType", config.auth_protocol))
                    archivo.write(_conf_line("defAuthPassphrase", config.auth_password))
                if config.priv_password:
                    archivo.write(_conf_line("defPrivType", config.priv_protocol))
                    archivo.write(_conf_line("defPrivPassphrase", config.priv_password))
            else:
                archivo.write(_conf_line("defCommunity", config.community))
        self._env = {**os.environ, "SNMPCONFPATH": self._dir.name, "MIBS": ""}

    def _base_args(self) -> list[str]:
        return [
            "-v", _version_flag(self.config.version),
            "-t", str(self.config.timeout_seconds),
            "-r", str(self.config.retries),
            "-On",  # print OIDs numerically
        ]

    def _target(self) -> str:
        return f"{self.config.host}:{self.config.port}"

    def _run(self, tool: str, oid: str, timeout: int) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [tool] + self._base_args() + [self._target(), oid],
                capture_output=True, text=True, timeout=timeout, env=self._env,
            )
        except subprocess.TimeoutExpired:
            raise SnmpCollectionError(f"{tool} {oid}: timeout after {timeout}s")

    def get_scalar(self, oid: str) -> str | None:
        result = self._run("snmpget", oid, self.config.timeout_seconds * (self.config.retries + 1) + 2)
        if result.returncode != 0:
            err = (result.stderr or result.stdout).strip()
            raise SnmpCollectionError(f"snmpget {oid}: {err}")
        line = result.stdout.strip()
        if not line or "No Such" in line:
            return None
        return _parse_value(line)

    def walk(self, oid: str) -> list[tuple[str, str]]:
        result = self._run("snmpwalk", oid, self.config.timeout_seconds * 10 + 5)
        if result.returncode != 0:
            err = (result.stderr or result.stdout).strip()
            raise SnmpCollectionError(f"snmpwalk {oid}: {err}")
        rows: list[tuple[str, str]] = []
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            if "=" not in line or "No Such" in line or "No more variables" in line:
                continue
            name, _ = line.split("=", 1)
            value = _parse_value(line)
            rows.append((name.strip(), value))
        return rows
