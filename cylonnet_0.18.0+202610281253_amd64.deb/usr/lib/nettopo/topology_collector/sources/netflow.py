"""
NetFlow v5 / v9 / IPFIX receiver adapter.

Escucha en UDP, parsea datagramas con la librería `netflow` (PyPI >=0.12),
enriquece cada flujo con servicio, dirección y org RDAP, y normaliza
al modelo canónico del snapshot.

Parámetros en site-config.json (al nivel raíz del source):
  listen_host      str   "0.0.0.0"   interfaz de escucha
  listen_port      int   2055        puerto UDP
  collect_seconds  int   30          ventana de captura
  exporter_ip      str   null        filtrar por IP exportadora (opcional)
  rdap             bool  true        resolver orgs via RDAP (opcional)
"""
from __future__ import annotations

import socket
import time
from collections import defaultdict
from datetime import datetime, timezone
from ipaddress import ip_address
from pathlib import Path
from typing import Any

from ..rdap_client import RdapClient, is_private_ip
from ..site_models import CollectionResult
from .base import SourceAdapter

try:
    import netflow  # PyPI: netflow
    try:
        from netflow.v9 import V9TemplateNotRecognized as _V9TemplateNotRecognized
    except ImportError:
        _V9TemplateNotRecognized = None
    _NETFLOW_AVAILABLE = True
except ImportError:
    _V9TemplateNotRecognized = None
    _NETFLOW_AVAILABLE = False

# ── constantes ────────────────────────────────────────────────────────────────

_DEFAULT_PORT    = 2055
_DEFAULT_SECONDS = 30
_SOCKET_TIMEOUT  = 1.0

_PROTO_NAMES: dict[int, str] = {
    1: "icmp", 6: "tcp", 17: "udp", 47: "gre", 50: "esp", 89: "ospf",
}

_PORT_SERVICES: dict[int, str] = {
    20: "FTP", 21: "FTP", 22: "SSH", 23: "Telnet",
    25: "SMTP", 53: "DNS", 67: "DHCP", 68: "DHCP",
    80: "HTTP", 110: "POP3", 123: "NTP", 143: "IMAP",
    161: "SNMP", 162: "SNMP", 389: "LDAP",
    443: "HTTPS", 445: "SMB", 465: "SMTPS",
    514: "Syslog", 515: "Impresion", 554: "RTSP",
    587: "SMTP", 636: "LDAPS", 993: "IMAPS", 995: "POP3S",
    1194: "OpenVPN", 1433: "SQL Server", 1723: "PPTP",
    1935: "RTMP", 3306: "MySQL", 3389: "RDP",
    5060: "SIP", 5432: "PostgreSQL", 5900: "VNC",
    8080: "HTTP", 8443: "HTTPS", 9100: "Impresion",
    9200: "Elasticsearch", 27017: "MongoDB",
}

# ── helpers ───────────────────────────────────────────────────────────────────

def _str_ip(raw: Any) -> str:
    try:
        return str(ip_address(int(raw)))
    except (TypeError, ValueError):
        return str(raw)


def _device_id(ip: str) -> str:
    return f"flow-host-{ip.replace('.', '-')}"


def _proto_name(num: Any) -> str:
    try:
        return _PROTO_NAMES.get(int(num), f"proto-{num}")
    except (TypeError, ValueError):
        return str(num)


def _service_name(dst_port: int, src_port: int, proto: str) -> str:
    return _PORT_SERVICES.get(dst_port) or _PORT_SERVICES.get(src_port) or proto.upper()


def _flow_direction(src_ip: str, dst_ip: str) -> tuple[str, str | None]:
    """(direction, external_ip).  direction: 'upload' | 'download' | 'internal'"""
    src_priv = is_private_ip(src_ip)
    dst_priv = is_private_ip(dst_ip)
    if src_priv and not dst_priv:
        return "upload", dst_ip
    if not src_priv and dst_priv:
        return "download", src_ip
    return "internal", None


# ── clave de agregación ───────────────────────────────────────────────────────

class _FlowKey:
    """Clave bidireccional por (par de IPs, servicio)."""
    __slots__ = ("_a", "_b", "service")

    def __init__(self, src: str, dst: str, service: str) -> None:
        self._a, self._b = tuple(sorted((src, dst)))  # type: ignore[assignment]
        self.service = service

    def __hash__(self) -> int:
        return hash((self._a, self._b, self.service))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _FlowKey):
            return NotImplemented
        return self._a == other._a and self._b == other._b and self.service == other.service


# ── extracción de flujos crudos ───────────────────────────────────────────────

def _extract_v5_flows(export: Any) -> list[dict[str, Any]]:
    flows = []
    for flow in export.flows:
        d = flow.data
        flows.append({
            "src_ip":   _str_ip(d.get("IPV4_SRC_ADDR", 0)),
            "dst_ip":   _str_ip(d.get("IPV4_DST_ADDR", 0)),
            "proto":    _proto_name(d.get("PROTO", d.get("PROTOCOL", 0))),
            "src_port": int(d.get("SRC_PORT", 0)),
            "dst_port": int(d.get("DST_PORT", 0)),
            "bytes":    int(d.get("IN_OCTETS", d.get("BYTES", 0))),
            "packets":  int(d.get("IN_PACKETS", d.get("IN_PKTS", d.get("PACKETS", 0)))),
        })
    return flows


def _extract_v9_ipfix_flows(export: Any) -> list[dict[str, Any]]:
    flows = []
    for flow in export.flows:
        d = flow.data
        src  = d.get("IPV4_SRC_ADDR") or d.get("sourceIPv4Address") or d.get("IPV6_SRC_ADDR") or 0
        dst  = d.get("IPV4_DST_ADDR") or d.get("destinationIPv4Address") or d.get("IPV6_DST_ADDR") or 0
        prot = d.get("PROTO") or d.get("PROTOCOL") or d.get("protocolIdentifier") or 0
        byt  = d.get("IN_OCTETS") or d.get("octetDeltaCount") or d.get("BYTES") or 0
        pkt  = d.get("IN_PKTS") or d.get("packetDeltaCount") or d.get("PACKETS") or 0
        sp   = d.get("SRC_PORT") or d.get("sourceTransportPort") or 0
        dp   = d.get("DST_PORT") or d.get("destinationTransportPort") or 0
        flows.append({
            "src_ip":   _str_ip(src),
            "dst_ip":   _str_ip(dst),
            "proto":    _proto_name(prot),
            "src_port": int(sp),
            "dst_port": int(dp),
            "bytes":    int(byt),
            "packets":  int(pkt),
        })
    return flows


# ── construcción del snapshot ─────────────────────────────────────────────────

def _build_snapshot(
    site_name: str,
    source_name: str,
    aggregated: dict[_FlowKey, dict[str, Any]],
    rdap: RdapClient,
) -> dict[str, Any]:

    # Recopilar IPs externas para lookup RDAP en batch
    external_ips = [
        stats["external_ip"]
        for stats in aggregated.values()
        if stats.get("external_ip")
    ]
    org_map = rdap.lookup_many(external_ips) if external_ips else {}

    # Construir mapa: ip → lista de flujos que involucran esa IP
    ip_flows: dict[str, list[dict[str, Any]]] = defaultdict(list)

    links = []
    for key, stats in aggregated.items():
        # Ignorar flujos entre dos IPs externas (no son de nuestra red)
        if not is_private_ip(stats["orig_src"]) and not is_private_ip(stats["orig_dst"]):
            continue
        # Excluir multicast, broadcast y direcciones de red
        skip = False
        for _ip in (stats["orig_src"], stats["orig_dst"]):
            try:
                _a = ip_address(_ip)
                if _a.is_multicast or _a.is_loopback or str(_ip).endswith(".255") or str(_ip).endswith(".0"):
                    skip = True
                    break
            except ValueError:
                skip = True
                break
        if skip:
            continue
        direction, ext_ip = _flow_direction(stats["orig_src"], stats["orig_dst"])
        remote_org = org_map.get(ext_ip, "") if ext_ip else ""
        # IP "local" es la privada cuando hay una externa, si no la src canónica
        local_ip  = stats["orig_src"] if not is_private_ip(stats["orig_dst"]) else stats["orig_dst"]
        remote_ip = ext_ip or (stats["orig_dst"] if local_ip == stats["orig_src"] else stats["orig_src"])

        meta: dict[str, Any] = {
            "bytes":      stats["bytes"],
            "packets":    stats["packets"],
            "service":    key.service,
            "direction":  direction,
            "is_external": ext_ip is not None,
            "src_ip":     stats["orig_src"],
            "dst_ip":     stats["orig_dst"],
            "dst_port":   stats["dst_port"],
            "proto":      stats["proto"],
            "remote_org": remote_org,
        }

        links.append({
            "localDeviceId":       _device_id(stats["orig_src"]),
            "localInterfaceName":  "flow-src",
            "remoteDeviceId":      _device_id(stats["orig_dst"]),
            "remoteInterfaceName": "flow-dst",
            "protocol":            f"netflow-{stats['proto']}",
            "confidence":          0.70,
            "meta":                meta,
        })

        # Acumular flujos por IP para netflowFlows en devices
        flow_entry = {
            "service":    key.service,
            "direction":  direction,
            "bytes":      stats["bytes"],
            "packets":    stats["packets"],
            "remote_ip":  remote_ip,
            "remote_org": remote_org,
        }
        ip_flows[stats["orig_src"]].append(flow_entry)
        ip_flows[stats["orig_dst"]].append(flow_entry)

    # Armar devices con netflowFlows y totales — solo IPs privadas como devices
    seen_ips: set[str] = set()
    for key in aggregated:
        seen_ips.add(key._a)
        seen_ips.add(key._b)

    devices = []
    for ip in sorted(seen_ips):
        if ip in ("0.0.0.0", "::"):
            continue
        if not is_private_ip(ip):
            continue
        try:
            addr = ip_address(ip)
            if addr.is_multicast or addr.is_loopback or addr.is_link_local:
                continue
            # Excluir broadcast de subred (.255) y direcciones de red (.0)
            if str(addr).endswith(".255") or str(addr).endswith(".0"):
                continue
        except ValueError:
            continue
        flows_for_ip = ip_flows.get(ip, [])
        total_bytes = sum(f["bytes"] for f in flows_for_ip)
        devices.append({
            "id":            _device_id(ip),
            "name":          ip,
            "kind":          "host",
            "vendor":        "Unknown",
            "os":            "Unknown",
            "managementIp":  ip,
            "site":          site_name,
            "interfaces":    [],
            "networks":      [],
            "netflowFlows":  sorted(flows_for_ip, key=lambda f: f["bytes"], reverse=True),
            "netflowBytes":  total_bytes,
        })

    return {
        "metadata": {
            "name":        site_name,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "source":      "netflow-ipfix",
            "notes":       f"Receptor NetFlow/IPFIX '{source_name}'.",
        },
        "rootDeviceId": None,
        "devices":      devices,
        "l2Neighbors":  links,
        "hosts":        [],
        "macTable":     [],
    }


# ── adaptador ─────────────────────────────────────────────────────────────────

class NetFlowAdapter(SourceAdapter):
    """Recibe NetFlow v5/v9/IPFIX y devuelve un snapshot de topología enriquecido."""

    def collect(self) -> CollectionResult:
        if not _NETFLOW_AVAILABLE:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=["Instalar: pip install netflow"],
            )

        s = self.source.settings
        listen_host:     str       = str(s.get("listen_host", "0.0.0.0"))
        listen_port:     int       = int(s.get("listen_port", _DEFAULT_PORT))
        collect_seconds: int       = int(s.get("collect_seconds", _DEFAULT_SECONDS))
        exporter_ip:     str | None = s.get("exporter_ip") or None
        use_rdap:        bool      = bool(s.get("rdap", True))

        # Cache RDAP junto al workspace (runtime/rdap-cache.json)
        cache_path: Path | None = None
        if self.workspace_root and use_rdap:
            cache_path = Path(self.workspace_root) / "runtime" / "rdap-cache.json"
        rdap = RdapClient(cache_path=cache_path)

        aggregated: dict[_FlowKey, dict[str, Any]] = {}
        templates:  dict[Any, Any] = {}
        warnings:   list[str] = []
        packets_received = 0

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind((listen_host, listen_port))
            sock.settimeout(_SOCKET_TIMEOUT)
        except OSError as exc:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=[f"No se pudo abrir socket UDP {listen_host}:{listen_port}: {exc}"],
            )

        deadline = time.monotonic() + collect_seconds
        try:
            while time.monotonic() < deadline:
                try:
                    data, addr = sock.recvfrom(65535)
                except TimeoutError:
                    continue

                if exporter_ip and addr[0] != exporter_ip:
                    continue

                try:
                    export = netflow.parse_packet(data, templates)
                except Exception as exc:  # noqa: BLE001
                    if _V9TemplateNotRecognized and isinstance(exc, _V9TemplateNotRecognized):
                        continue  # template aún no recibido, esperar próximo ciclo
                    warnings.append(f"Error parseo de {addr[0]}: {exc}")
                    continue

                packets_received += 1
                version = getattr(export, "header", export).version
                raw_flows = _extract_v5_flows(export) if version == 5 else _extract_v9_ipfix_flows(export)

                for f in raw_flows:
                    service = _service_name(f["dst_port"], f["src_port"], f["proto"])
                    key = _FlowKey(f["src_ip"], f["dst_ip"], service)

                    if key not in aggregated:
                        aggregated[key] = {
                            "bytes": 0, "packets": 0,
                            "orig_src": f["src_ip"],
                            "orig_dst": f["dst_ip"],
                            "dst_port": f["dst_port"],
                            "proto":    f["proto"],
                            "external_ip": None,
                        }
                        _, ext = _flow_direction(f["src_ip"], f["dst_ip"])
                        aggregated[key]["external_ip"] = ext

                    aggregated[key]["bytes"]   += f["bytes"]
                    aggregated[key]["packets"] += f["packets"]
        finally:
            sock.close()

        if packets_received == 0:
            warnings.append(
                f"No se recibieron datagramas en {collect_seconds}s "
                f"en {listen_host}:{listen_port}."
            )
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=warnings,
            )

        snapshot = _build_snapshot(self.site_name, self.source.name, aggregated, rdap)
        return CollectionResult(
            source_type=self.source.type,
            source_name=self.source.name,
            snapshot=snapshot,
            warnings=warnings,
        )
