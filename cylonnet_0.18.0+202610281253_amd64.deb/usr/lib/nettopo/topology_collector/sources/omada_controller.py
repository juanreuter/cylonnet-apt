from __future__ import annotations

from ..site_models import CollectionResult
from .base import SourceAdapter


class OmadaControllerAdapter(SourceAdapter):
    def collect(self) -> CollectionResult:
        base_url = self.source.settings.get("base_url", "")
        return CollectionResult(
            source_type=self.source.type,
            source_name=self.source.name,
            warnings=[
                "Adaptador Omada controller aun no implementado.",
                f"Base URL configurada: {base_url or 'sin definir'}",
            ],
        )
