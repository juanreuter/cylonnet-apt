from __future__ import annotations

import json
from pathlib import Path

from ..site_models import CollectionResult
from .base import SourceAdapter


class StaticSnapshotAdapter(SourceAdapter):
    def collect(self) -> CollectionResult:
        relative_path = self.source.settings.get("path")
        if not relative_path:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=["La fuente static-snapshot no tiene path configurado."],
            )

        snapshot_path = Path(relative_path)
        if not snapshot_path.is_absolute():
            snapshot_path = self.workspace_root / snapshot_path

        payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
        payload.setdefault("metadata", {})
        payload["metadata"]["source"] = "static-snapshot"
        payload["metadata"]["notes"] = (
            payload["metadata"].get("notes")
            or "Snapshot cargado desde archivo para validar la arquitectura multi-fuente."
        )

        return CollectionResult(
            source_type=self.source.type,
            source_name=self.source.name,
            snapshot=payload,
        )
