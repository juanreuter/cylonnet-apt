from .base import SourceAdapter
from .generic_snmp import GenericSnmpAdapter
from .local_discovery import LocalDiscoveryAdapter
from .mikrotik_routeros import MikroTikRouterOsAdapter
from .netflow import NetFlowAdapter
from .omada_controller import OmadaControllerAdapter
from .static_snapshot import StaticSnapshotAdapter
from .unifi_controller import UnifiControllerAdapter


SOURCE_ADAPTERS = {
    "local-discovery": LocalDiscoveryAdapter,
    "static-snapshot": StaticSnapshotAdapter,
    "mikrotik-routeros": MikroTikRouterOsAdapter,
    "snmp-generic": GenericSnmpAdapter,
    "unifi-controller": UnifiControllerAdapter,
    "omada-controller": OmadaControllerAdapter,
    "netflow-ipfix": NetFlowAdapter,
}
