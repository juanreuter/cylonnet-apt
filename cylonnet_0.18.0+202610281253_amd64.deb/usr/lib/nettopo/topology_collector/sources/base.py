from __future__ import annotations

from pathlib import Path

from ..site_models import CollectionResult, SourceConfig


class SourceAdapter:
    def __init__(self, site_name: str, source: SourceConfig, workspace_root: Path) -> None:
        self.site_name = site_name
        self.source = source
        self.workspace_root = workspace_root

    def collect(self) -> CollectionResult:
        raise NotImplementedError
