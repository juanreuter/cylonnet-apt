from __future__ import annotations

from http.client import InvalidURL

from ..config import RouterOsConfig
from ..routeros_discovery import collect_routeros_discovery
from ..routeros_rest import RouterOsRestError
from ..site_models import CollectionResult
from .base import SourceAdapter


class MikroTikRouterOsAdapter(SourceAdapter):
    def collect(self) -> CollectionResult:
        settings = self.source.settings
        config = RouterOsConfig(
            site_name=self.site_name,
            host=settings["host"],
            username=settings["username"],
            password=settings["password"],
            verify_tls=bool(settings.get("verify_tls", False)),
            timeout_seconds=int(settings.get("timeout_seconds", 15)),
            vendor=str(settings.get("vendor", "")),
            model=str(settings.get("model", "")),
            snmp_community=str(settings.get("snmp_community", "")),
            snmp_port=int(settings.get("snmp_port", 161)),
            rest_port=int(settings.get("port", 443)),
        )
        max_neighbor_depth = max(0, int(settings.get("max_neighbor_depth", 1)))

        try:
            result = collect_routeros_discovery(
                config,
                max_neighbor_depth=max_neighbor_depth,
            )
        except (RouterOsRestError, InvalidURL, OSError, ValueError) as exc:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=[f"{type(exc).__name__}: {exc}"],
            )

        return CollectionResult(
            source_type=self.source.type,
            source_name=self.source.name,
            snapshot=result.snapshot,
            warnings=result.warnings,
        )
