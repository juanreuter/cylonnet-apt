from __future__ import annotations

import http.client
import ipaddress
import json
import os
import platform
import re
import shutil
import socket
import ssl
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any

from ..config import RouterOsConfig
from ..oui_lookup import lookup as oui_lookup
from ..routeros_discovery import collect_routeros_discovery
from ..routeros_rest import RouterOsRestError
from ..site_models import CollectionResult
from .base import SourceAdapter


# ── Helpers genéricos ──────────────────────────────────────────────────────────

def _run_command(args: list[str], timeout: float = 30.0) -> str:
    completed = subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
        timeout=timeout,
    )
    if completed.returncode != 0:
        stderr = completed.stderr.strip()
        stdout = completed.stdout.strip()
        details = stderr or stdout or f"codigo {completed.returncode}"
        raise RuntimeError(f"Fallo al ejecutar {' '.join(args)}: {details}")
    return completed.stdout


def _powershell_json(script: str) -> Any:
    raw = _run_command(["powershell", "-NoProfile", "-Command", script])
    if not raw.strip():
        return None
    return json.loads(raw)


def _normalize_records(payload: Any) -> list[dict[str, Any]]:
    if payload is None:
        return []
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        return [payload]
    return []


def _local_hostname() -> str:
    return socket.gethostname() or "collector-local"


def _is_windows() -> bool:
    return platform.system().lower().startswith("win")


# ── Interfaces ─────────────────────────────────────────────────────────────────

def _discover_windows_interfaces() -> list[dict[str, Any]]:
    payload = _powershell_json(
        """
        Get-NetIPConfiguration |
          Where-Object { $_.NetAdapter.Status -eq 'Up' -and $_.IPv4Address } |
          ForEach-Object {
            [pscustomobject]@{
              InterfaceAlias = $_.InterfaceAlias
              InterfaceDescription = $_.InterfaceDescription
              IPv4Address = $_.IPv4Address.IPAddress
              PrefixLength = $_.IPv4Address.PrefixLength
              Gateway = if ($_.IPv4DefaultGateway) { $_.IPv4DefaultGateway.NextHop } else { $null }
            }
          } | ConvertTo-Json -Compress
        """
    )
    return _normalize_records(payload)


def _discover_linux_interfaces() -> list[dict[str, Any]]:
    route_json = _run_command(["ip", "-j", "route"])
    addr_json = _run_command(["ip", "-j", "-4", "address"])

    routes = json.loads(route_json)
    addresses = json.loads(addr_json)
    default_by_dev: dict[str, str] = {}

    for route in routes:
        if route.get("dst") == "default" and route.get("dev") and route.get("gateway"):
            default_by_dev[str(route["dev"])] = str(route["gateway"])

    records: list[dict[str, Any]] = []
    for item in addresses:
        ifname = item.get("ifname")
        addr_info = item.get("addr_info") or []
        if not ifname or not addr_info:
            continue
        for addr in addr_info:
            if addr.get("family") != "inet":
                continue
            records.append({
                "InterfaceAlias": ifname,
                "InterfaceDescription": ifname,
                "IPv4Address": addr.get("local"),
                "PrefixLength": addr.get("prefixlen"),
                "Gateway": default_by_dev.get(str(ifname)),
            })
            break

    return records


def _is_ignored_interface(record: dict[str, Any]) -> bool:
    text = " ".join([
        str(record.get("InterfaceAlias") or ""),
        str(record.get("InterfaceDescription") or ""),
    ]).lower()
    ignored_tokens = (
        "tailscale", "wireguard", "wg", "tun", "tap", "zerotier", "zt",
        "hamachi", "docker", "veth", "br-", "vmware", "virtualbox",
        "hyper-v", "loopback",
    )
    return any(token in text for token in ignored_tokens)


def _score_interface(record: dict[str, Any]) -> int:
    score = 0
    if record.get("Gateway"):
        score += 100
    alias = str(record.get("InterfaceAlias") or "").lower()
    description = str(record.get("InterfaceDescription") or "").lower()
    if "ethernet" in alias or "eth" in alias:
        score += 20
    if "wi-fi" in alias or "wifi" in alias or "wlan" in alias:
        score += 15
    if "virtual" in description or "loopback" in description or "vmware" in description:
        score -= 40
    if _is_ignored_interface(record):
        score -= 1000
    return score


def _select_interface(records: list[dict[str, Any]], preferred_alias: str | None) -> dict[str, Any]:
    if not records:
        raise RuntimeError("No se detectaron interfaces IPv4 activas.")
    if preferred_alias:
        normalized = preferred_alias.strip().lower()
        for record in records:
            alias = str(record.get("InterfaceAlias") or "").strip().lower()
            if alias == normalized:
                return record
        raise RuntimeError(f"No se encontro la interfaz solicitada: {preferred_alias}")
    physical_records = [record for record in records if not _is_ignored_interface(record)]
    ranked = sorted(physical_records or records, key=_score_interface, reverse=True)
    return ranked[0]


def _cidr_from_interface(record: dict[str, Any]) -> tuple[str, str]:
    address = record.get("IPv4Address")
    prefix = record.get("PrefixLength")
    if not address or prefix in (None, ""):
        raise RuntimeError("No se pudo determinar IPv4/prefijo de la interfaz local.")
    interface = ipaddress.ip_interface(f"{address}/{prefix}")
    return str(interface.ip), str(interface.network)


# ── Ping / fping sweep ─────────────────────────────────────────────────────────

def _fping_available() -> bool:
    return shutil.which("fping") is not None


def _probe_network_fping(network_cidr: str, max_hosts: int, timeout_ms: int) -> dict[str, bool]:
    """fping barre toda la subred en paralelo — ~1s para /24 vs ~50s con ping individual."""
    network = ipaddress.ip_network(network_cidr, strict=False)
    candidates = [str(ip) for ip in network.hosts()][:max(0, max_hosts)]
    if not candidates:
        return {}
    try:
        result = subprocess.run(
            ["fping", "-a", "-t", str(timeout_ms), "-q"] + candidates,
            capture_output=True,
            text=True,
            check=False,
            timeout=max(15, timeout_ms / 1000 * 3 + 5),
        )
        # fping -a imprime solo los hosts vivos, uno por línea
        alive = set(result.stdout.strip().splitlines())
        return {ip: (ip in alive) for ip in candidates}
    except (OSError, subprocess.TimeoutExpired):
        return _probe_network_ping(network_cidr, max_hosts, timeout_ms)


def _probe_network_ping(network_cidr: str, max_hosts: int, timeout_ms: int) -> dict[str, bool]:
    """Fallback: ping individual en paralelo."""
    network = ipaddress.ip_network(network_cidr, strict=False)
    candidates = [str(ip) for ip in network.hosts()][:max(0, max_hosts)]
    if not candidates:
        return {}
    workers = min(32, max(4, len(candidates)))
    results: dict[str, bool] = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(_ping_host, ip, timeout_ms): ip for ip in candidates}
        for future in as_completed(future_map):
            ip = future_map[future]
            try:
                results[ip] = bool(future.result())
            except Exception:
                results[ip] = False
    return results


def _ping_host(ip_address: str, timeout_ms: int) -> bool:
    if _is_windows():
        args = ["ping", "-n", "1", "-w", str(timeout_ms), ip_address]
    else:
        seconds = max(1, round(timeout_ms / 1000))
        args = ["ping", "-c", "1", "-W", str(seconds), ip_address]
    completed = subprocess.run(args, capture_output=True, text=True, check=False)
    return completed.returncode == 0


def _probe_network(network_cidr: str, max_hosts: int, timeout_ms: int) -> dict[str, bool]:
    if _fping_available():
        return _probe_network_fping(network_cidr, max_hosts, timeout_ms)
    return _probe_network_ping(network_cidr, max_hosts, timeout_ms)


# ── TCP probe ──────────────────────────────────────────────────────────────────

def _tcp_probe_one(ip_address: str, ports: tuple[int, ...], timeout_s: float) -> bool:
    for port in ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout_s)
            err = sock.connect_ex((ip_address, port))
            sock.close()
            if err in (0, 111, 10061):
                return True
        except OSError:
            pass
    return False


def _tcp_probe_hosts(
    ips: list[str],
    ports: tuple[int, ...] = (80, 443, 8080, 554, 8443, 7000),
    timeout_s: float = 0.4,
) -> set[str]:
    if not ips:
        return set()
    live: set[str] = set()
    workers = min(48, max(4, len(ips)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(_tcp_probe_one, ip, ports, timeout_s): ip for ip in ips}
        for future in as_completed(future_map):
            ip = future_map[future]
            try:
                if future.result():
                    live.add(ip)
            except Exception:
                pass
    return live


# ── SSDP ───────────────────────────────────────────────────────────────────────

def _discover_ssdp(timeout_s: float = 3.0) -> set[str]:
    """SSDP/UPnP multicast: smart TVs, reproductores, IoT que publican servicios."""
    SSDP_ADDR = "239.255.255.250"
    SSDP_PORT = 1900
    msg = "\r\n".join([
        "M-SEARCH * HTTP/1.1",
        f"HOST: {SSDP_ADDR}:{SSDP_PORT}",
        'MAN: "ssdp:discover"',
        "MX: 2",
        "ST: ssdp:all",
        "", "",
    ]).encode()
    ips: set[str] = set()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(timeout_s)
        sock.sendto(msg, (SSDP_ADDR, SSDP_PORT))
        while True:
            try:
                _, addr = sock.recvfrom(2048)
                ips.add(addr[0])
            except socket.timeout:
                break
    except OSError:
        pass
    finally:
        try:
            sock.close()
        except Exception:
            pass
    return ips


# ── mDNS via avahi-browse ──────────────────────────────────────────────────────

_MDNS_SERVICE_SUBTITLE: dict[str, str] = {
    "_googlecast._tcp":        "Chromecast",
    "_androidtvremote2._tcp":  "Android TV",
    "_airplay._tcp":           "AirPlay",
    "_raop._tcp":              "AirPlay Audio",
    "_ipp._tcp":               "Impresora",
    "_ipps._tcp":              "Impresora",
    "_printer._tcp":           "Impresora",
    "_pdl-datastream._tcp":    "Impresora",
    "_ssh._tcp":               "SSH",
    "_sftp-ssh._tcp":          "SSH",
    "_smb._tcp":               "Samba / Windows",
    "_afpovertcp._tcp":        "AFP / macOS",
    "_device-info._tcp":       "Apple Device",
    "_http._tcp":              "HTTP",
    "_https._tcp":             "HTTPS",
    "_onvif._tcp":             "Cámara ONVIF",
    "_rtsp._tcp":              "Cámara / Stream",
    "_nvr._tcp":               "NVR",
    "_daap._tcp":              "iTunes / DAAP",
    "_homekit._tcp":           "HomeKit / IoT",
    "_hap._tcp":               "HomeKit / IoT",
}


def _parse_avahi_txt(txt: str) -> dict[str, str]:
    """Extrae pares clave=valor del campo txt de avahi-browse."""
    result: dict[str, str] = {}
    for m in re.finditer(r'"([^"=]+)=([^"]*)"', txt):
        result[m.group(1)] = m.group(2).strip()
    return result


def _discover_avahi(timeout_s: float = 6.0) -> dict[str, dict[str, Any]]:
    """
    mDNS discovery via avahi-browse -a -t -p -r.
    Retorna {ip: {friendly_name, model, hostname, services: [str], subtitle: str}}
    Resuelve nombres amigables del campo fn= y modelos del campo md=.
    """
    if not shutil.which("avahi-browse"):
        return {}
    try:
        result = subprocess.run(
            ["avahi-browse", "-a", "-t", "-p", "-r"],
            capture_output=True,
            text=True,
            timeout=timeout_s,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return {}

    entries: dict[str, dict[str, Any]] = {}

    for line in result.stdout.splitlines():
        # Solo líneas resueltas: =;iface;proto;name;service_type;domain;hostname;ip;port;txt
        if not line.startswith("="):
            continue
        parts = line.split(";", 9)
        if len(parts) < 9:
            continue
        proto = parts[2]
        if proto != "IPv4":
            continue
        name = parts[3]
        service_type = parts[4]
        hostname = parts[6].removesuffix(".local")
        ip = parts[7]
        txt = parts[9] if len(parts) > 9 else ""

        if not ip or ip.startswith("169.254") or ":" in ip:
            continue

        txt_fields = _parse_avahi_txt(txt)
        friendly_name = txt_fields.get("fn", "").strip() or None
        model = txt_fields.get("md", "").strip() or None

        subtitle = _MDNS_SERVICE_SUBTITLE.get(service_type, "")

        if ip not in entries:
            entries[ip] = {
                "friendly_name": friendly_name,
                "model": model,
                "hostname": hostname if hostname and hostname != ip else None,
                "services": [],
                "subtitle": subtitle,
            }
        else:
            if friendly_name and not entries[ip]["friendly_name"]:
                entries[ip]["friendly_name"] = friendly_name
            if model and not entries[ip]["model"]:
                entries[ip]["model"] = model
            if subtitle and not entries[ip]["subtitle"]:
                entries[ip]["subtitle"] = subtitle

        if service_type not in entries[ip]["services"]:
            entries[ip]["services"].append(service_type)

    return entries


# ── NetBIOS via nbtscan ────────────────────────────────────────────────────────

def _discover_netbios(network_cidr: str, timeout_s: float = 12.0) -> dict[str, str]:
    """
    NetBIOS scan via nbtscan.
    Retorna {ip: nombre_netbios} — PC Windows, NAS Samba, servidores con SMB.
    """
    if not shutil.which("nbtscan"):
        return {}
    try:
        result = subprocess.run(
            ["nbtscan", "-q", network_cidr],
            capture_output=True,
            text=True,
            timeout=timeout_s,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return {}

    names: dict[str, str] = {}
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2:
            ip = parts[0].strip()
            name = parts[1].strip()
            if ip and name and name not in ("<unknown>", ""):
                try:
                    ipaddress.ip_address(ip)
                    names[ip] = name
                except ValueError:
                    pass
    return names


# ── LLDP local via lldpcli ────────────────────────────────────────────────────

def _discover_lldp_local() -> list[dict[str, Any]]:
    """
    Lee vecinos LLDP que lldpd detectó desde esta máquina.
    Requiere que lldpd esté corriendo: sudo systemctl enable --now lldpd
    """
    if not shutil.which("lldpcli"):
        return []
    try:
        result = subprocess.run(
            ["lldpcli", "show", "neighbors", "-f", "json"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if not result.stdout.strip():
            return []
        data = json.loads(result.stdout)
        neighbors: list[dict[str, Any]] = []
        for iface_data in data.get("lldp", {}).get("interface", {}).values():
            chassis = iface_data.get("chassis", {})
            port_info = iface_data.get("port", {})
            for chassis_name, chassis_info in chassis.items():
                mgmt_ips = chassis_info.get("mgmt-ip", [])
                if isinstance(mgmt_ips, str):
                    mgmt_ips = [mgmt_ips]
                neighbors.append({
                    "name": chassis_name,
                    "mgmt_ips": [str(ip) for ip in mgmt_ips],
                    "port": port_info.get("id", {}).get("value", ""),
                    "description": chassis_info.get("descr", ""),
                    "capabilities": list(chassis_info.get("capability", {}).keys()),
                })
        return neighbors
    except Exception:
        return []


# ── HTTP fingerprinting activo ────────────────────────────────────────────────
#
# El sistema NO espera que los dispositivos se anuncien — va a golpearles la
# puerta activamente en todos los puertos de gestión conocidos y analiza cada
# respuesta para determinar fabricante, modelo y tipo. Esto detecta APs, cámaras,
# NAS, routers, switches y cualquier cosa con interfaz web, sin importar si
# responden a SNMP, mDNS o cualquier otro protocolo.

_HTTP_SIGNATURES: list[tuple[str, str, str, str]] = [
    # (patrón regex, fabricante, modelo_hint, kind)
    # Access Points / Controllers
    (r"(?i)TP-?LINK.*EAP|EAP[-_]?\d{3}|Omada|tplink-eap", "TP-Link", "EAP", "ap"),
    (r"(?i)UniFi|ubnt\.com|Ubiquiti|UAP|USW|UDM",          "Ubiquiti", "UniFi", "ap"),
    (r"(?i)Ruckus|ZoneFlex|SmartZone",                      "Ruckus", "", "ap"),
    (r"(?i)Aruba.*IAP|Aruba.*AP|HPE.*Aruba",                "Aruba", "", "ap"),
    (r"(?i)Cambium|cnPilot|ePMP",                           "Cambium", "", "ap"),
    (r"(?i)Mikrotik.*CAPsMAN|RouterOS.*wireless",           "MikroTik", "CAPsMAN", "ap"),
    # Routers / Firewalls
    (r"(?i)RouterOS|MikroTik",                              "MikroTik", "RouterOS", "router"),
    (r"(?i)pfSense",                                        "Netgate", "pfSense", "firewall"),
    (r"(?i)OPNsense",                                       "Deciso", "OPNsense", "firewall"),
    (r"(?i)FortiGate|Fortinet",                             "Fortinet", "FortiGate", "firewall"),
    (r"(?i)OpenWrt|LEDE Project",                           "OpenWrt", "OpenWrt", "router"),
    (r"(?i)AsusWRT|ASUS.*router|asuswrt",                   "ASUS", "", "router"),
    (r"(?i)GL[-.]iNet|gl-inet",                             "GL.iNet", "", "router"),
    (r"(?i)DrayTek|Vigor\d",                                "DrayTek", "Vigor", "router"),
    (r"(?i)Mikrotik|routerboard",                           "MikroTik", "", "router"),
    (r"(?i)TP-?LINK.*router|TL-WR|TL-ER|TL-R\d",           "TP-Link", "", "router"),
    (r"(?i)D-?Link.*router|DIR-\d|DSR-\d",                  "D-Link", "", "router"),
    (r"(?i)Netgear",                                        "Netgear", "", "router"),
    (r"(?i)Linksys",                                        "Linksys", "", "router"),
    # Switches
    (r"(?i)Cisco.*IOS|Cisco.*Switch|C\d{4}X|catalyst",     "Cisco", "", "switch"),
    (r"(?i)HP.*ProCurve|HPE.*Switch|Aruba.*Switch",         "HP/Aruba", "", "switch"),
    (r"(?i)Ruijie|Reyee|RG-S\d",                           "Ruijie", "", "switch"),
    (r"(?i)TP-?LINK.*switch|TL-SG|TL-SF",                  "TP-Link", "", "switch"),
    (r"(?i)Netgear.*switch|GS\d{3}|XS\d{3}",               "Netgear", "", "switch"),
    (r"(?i)D-?Link.*switch|DGS-\d|DES-\d",                 "D-Link", "", "switch"),
    (r"(?i)Ubiquiti.*EdgeSwitch|EdgeSwitch|ES-\d",          "Ubiquiti", "EdgeSwitch", "switch"),
    # Cámaras IP / NVR
    (r"(?i)HIKVISION|Hik-Connect|iVMS",                    "Hikvision", "", "camera"),
    (r"(?i)Dahua|DSS|Smart PSS",                            "Dahua", "", "camera"),
    (r"(?i)Reolink",                                        "Reolink", "", "camera"),
    (r"(?i)Axis.*Network Camera|AXIS",                      "Axis", "", "camera"),
    (r"(?i)Vivotek",                                        "Vivotek", "", "camera"),
    (r"(?i)Amcrest",                                        "Amcrest", "", "camera"),
    (r"(?i)Foscam",                                         "Foscam", "", "camera"),
    (r"(?i)Hanwha|Samsung.*Camera|SNO-\d|SNV-\d",          "Hanwha", "", "camera"),
    # NAS / Servidores
    (r"(?i)Synology|DiskStation|DSM\s\d",                   "Synology", "DiskStation", "server"),
    (r"(?i)QNAP|QTS\s\d",                                   "QNAP", "NAS", "server"),
    (r"(?i)TrueNAS|FreeNAS|iXsystems",                      "iXsystems", "TrueNAS", "server"),
    (r"(?i)Proxmox",                                        "Proxmox", "PVE", "server"),
    (r"(?i)ESXi|VMware",                                    "VMware", "ESXi", "server"),
    # Teléfonos VoIP
    (r"(?i)Grandstream",                                    "Grandstream", "", "phone"),
    (r"(?i)Yealink",                                        "Yealink", "", "phone"),
    (r"(?i)Fanvil",                                         "Fanvil", "", "phone"),
    (r"(?i)Cisco.*IP Phone|CP-\d{4}",                       "Cisco", "IP Phone", "phone"),
    # Huawei / ONTs de ISP (Vodacom, Claro, etc.)
    (r"(?i)Dvodacom|hwlogo|Huawei|HG\d{3}|EG\d{3}|HiLink", "Huawei", "", "router"),
    # Dahua — título "WEB SERVICE" + header P3P es su firma característica
    (r"(?i)WEB SERVICE|dahua|SmartPSS|DSS",                 "Dahua", "", "camera"),
    # TrueNAS / FreeNAS identifiable por NetBIOS — firma HTTP básica
    (r"(?i)TrueNAS|FreeNAS|truenas",                        "iXsystems", "TrueNAS", "server"),
    # TP-Link genérico (después de los más específicos)
    (r"(?i)TP-?LINK",                                       "TP-Link", "", "device"),
]

# Kinds que corresponden a dispositivos de infraestructura administrable
_INFRA_KINDS = {"ap", "router", "switch", "firewall", "camera", "nvr", "server", "phone"}

_COMMON_PORT_LABELS: dict[int, str] = {
    22: "SSH",
    23: "Telnet",
    53: "DNS",
    80: "HTTP",
    139: "NetBIOS",
    443: "HTTPS",
    445: "SMB",
    554: "RTSP",
    631: "IPP",
    9100: "JetDirect",
    5000: "NAS",
    5001: "NAS",
    8000: "SDK",
    8080: "HTTP-alt",
    8291: "WinBox",
    8443: "HTTPS-alt",
    37777: "DVR/NVR",
}


def _port_probe_one(ip_address: str, ports: tuple[int, ...], timeout_s: float) -> list[int]:
    open_ports: list[int] = []
    for port in ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout_s)
            err = sock.connect_ex((ip_address, port))
            sock.close()
            if err == 0:
                open_ports.append(port)
        except OSError:
            pass
    return open_ports


def _probe_open_ports(
    ips: list[str],
    ports: tuple[int, ...] = (22, 23, 53, 80, 139, 443, 445, 554, 631, 9100, 5000, 5001, 8000, 8080, 8291, 8443, 37777),
    timeout_s: float = 0.35,
) -> dict[str, list[int]]:
    if not ips:
        return {}
    results: dict[str, list[int]] = {}
    workers = min(48, max(6, len(ips)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(_port_probe_one, ip, ports, timeout_s): ip for ip in ips}
        for future in as_completed(future_map):
            ip = future_map[future]
            try:
                open_ports = sorted(set(future.result()))
                if open_ports:
                    results[ip] = open_ports
            except Exception:
                pass
    return results


def _kind_label(kind: str) -> str:
    return {
        "camera": "Camara IP",
        "nvr": "Grabador",
        "printer": "Impresora",
        "server": "Servidor",
        "workstation": "Computadora",
        "router": "Router",
        "switch": "Switch",
        "ap": "Access Point",
        "phone": "Telefono IP",
        "tv": "TV",
        "tvbox": "TV Box",
        "iot": "IoT",
        "host": "Host",
    }.get(kind, kind.replace("-", " ").title())


def _infer_host_profile(
    *,
    vendor: str | None,
    dns_name: str | None,
    netbios_name: str | None,
    friendly_name: str | None,
    model: str | None,
    services: list[str] | None,
    open_ports: list[int] | None,
) -> dict[str, str]:
    hay = " ".join(
        part for part in [
            vendor or "",
            dns_name or "",
            netbios_name or "",
            friendly_name or "",
            model or "",
            " ".join(services or []),
        ]
        if part
    ).lower()
    ports = set(open_ports or [])

    def result(kind: str, inferred_vendor: str = "", inferred_model: str = "", subtitle: str = "") -> dict[str, str]:
        return {
            "kind": kind,
            "vendor": inferred_vendor,
            "model": inferred_model,
            "subtitle": subtitle,
            "label": _kind_label(kind),
        }

    if 8291 in ports or "routeros" in hay or "mikrotik" in hay:
        return result("router", "MikroTik" if "mikrotik" in hay or 8291 in ports else "", "RouterOS", "WinBox / RouterOS")
    if 37777 in ports or 554 in ports or "_onvif._tcp" in hay or "_rtsp._tcp" in hay:
        return result("camera", "", "", "RTSP / ONVIF")
    if 631 in ports or 9100 in ports or "_ipp._tcp" in hay or "_printer._tcp" in hay:
        return result("printer", "", "", "Impresion en red")
    if 5000 in ports or 5001 in ports or "synology" in hay or "truenas" in hay or "qnap" in hay or "_smb._tcp" in hay:
        return result("server", "", "", "NAS / archivos")
    if "_googlecast._tcp" in hay or "_airplay._tcp" in hay or "chromecast" in hay:
        return result("tvbox", "Google" if "google" in hay else "", "", "Streaming")
    if "_device-info._tcp" in hay or "apple-tv" in hay:
        return result("tv", "Apple" if "apple" in hay else "", "", "Display / media")
    if "eap" in hay or "unifi" in hay or "omada" in hay or "access point" in hay:
        return result("ap", "", "", "Wi-Fi")
    if 445 in ports or 139 in ports or "windows" in hay or "desktop" in hay or "laptop" in hay or "pc" in hay:
        return result("workstation", "", "", "SMB / workstation")

    return result("host")


# ── SNMP recursivo: detección de switches/APs administrables ─────────────────

def _probe_snmp_ifcount(ip: str, community: str, timeout_s: float = 2.0) -> int | None:
    """Returns ifNumber via SNMP, or None if SNMP not available/responding."""
    if not shutil.which("snmpget"):
        return None
    try:
        r = subprocess.run(
            ["snmpget", "-v2c", "-c", community, "-t", str(int(max(1, timeout_s))),
             "-r", "0", "-On", f"{ip}:161", "1.3.6.1.2.1.2.1.0"],
            capture_output=True, text=True, timeout=timeout_s + 1, check=False,
        )
        if r.returncode != 0:
            return None
        for part in r.stdout.split():
            try:
                return int(part)
            except ValueError:
                pass
    except Exception:
        pass
    return None


def _snmp_get_arp_neighbors(ip: str, community: str, timeout_s: float = 3.0) -> list[str]:
    """Get IP neighbors from the ARP cache of a device via SNMP."""
    if not shutil.which("snmpwalk"):
        return []
    try:
        r = subprocess.run(
            ["snmpwalk", "-v2c", "-c", community, "-t", str(int(max(1, timeout_s))),
             "-r", "0", "-OQn", f"{ip}:161", "1.3.6.1.2.1.4.22.1.3"],
            capture_output=True, text=True, timeout=timeout_s + 2, check=False,
        )
        neighbors: list[str] = []
        for line in r.stdout.splitlines():
            oid_part = line.split("=")[0].strip().lstrip(".")
            parts = oid_part.split(".")
            if len(parts) >= 4:
                candidate = ".".join(parts[-4:])
                try:
                    ipaddress.ip_address(candidate)
                    neighbors.append(candidate)
                except ValueError:
                    pass
        return neighbors
    except Exception:
        return []


def _discover_snmp_admins(
    ips: list[str],
    community: str,
    timeout_s: float = 2.0,
    min_interfaces: int = 2,
) -> dict[str, dict[str, Any]]:
    """
    Probe each IP via SNMP. Returns {ip: {interfaces, neighbors}} for devices
    with >= min_interfaces (likely switches/routers/APs).
    """
    results: dict[str, dict[str, Any]] = {}

    def probe(ip: str) -> tuple[str, dict[str, Any] | None]:
        ifcount = _probe_snmp_ifcount(ip, community, timeout_s)
        if ifcount is None or ifcount < min_interfaces:
            return ip, None
        neighbors = _snmp_get_arp_neighbors(ip, community, timeout_s)
        return ip, {"interfaces": ifcount, "neighbors": neighbors}

    with ThreadPoolExecutor(max_workers=24) as pool:
        for ip, data in pool.map(lambda i: probe(i), ips):
            if data is not None:
                results[ip] = data

    return results


def _http_get_banner(ip: str, port: int, use_ssl: bool, timeout_s: float) -> str:
    """Hace un GET / y retorna headers + primeros 8KB del body."""
    try:
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            conn: http.client.HTTPConnection = http.client.HTTPSConnection(
                ip, port, timeout=timeout_s, context=ctx
            )
        else:
            conn = http.client.HTTPConnection(ip, port, timeout=timeout_s)
        conn.request("GET", "/", headers={
            "User-Agent": "Mozilla/5.0",
            "Accept": "text/html,*/*",
            "Connection": "close",
        })
        resp = conn.getresponse()
        header_str = "".join(f"{k}: {v}\n" for k, v in resp.getheaders())
        body = resp.read(8192).decode("utf-8", errors="ignore")
        conn.close()
        return header_str + "\n" + body
    except Exception:
        return ""


def _fingerprint_one(ip: str, timeout_s: float = 1.5) -> dict[str, Any] | None:
    """
    Interroga activamente un host en todos los puertos de gestión conocidos.
    No espera que el dispositivo se anuncie — va y le pregunta.
    Retorna {vendor, model, kind, port, use_ssl} si lo identifica.
    """
    probes = [
        (80,   False),
        (443,  True),
        (8080, False),
        (8443, True),
        (8088, False),
        (8000, False),
    ]
    for port, use_ssl in probes:
        banner = _http_get_banner(ip, port, use_ssl, timeout_s)
        if not banner:
            continue
        for pattern, vendor, model, kind in _HTTP_SIGNATURES:
            if re.search(pattern, banner):
                return {
                    "vendor": vendor,
                    "model": model,
                    "kind": kind,
                    "port": port,
                    "use_ssl": use_ssl,
                    "mgmt_url": f"{'https' if use_ssl else 'http'}://{ip}:{port}",
                }
        # Respondió HTTP pero no matcheó ninguna firma — tiene interfaz web
        return {
            "vendor": "",
            "model": "",
            "kind": "device",
            "port": port,
            "use_ssl": use_ssl,
            "mgmt_url": f"{'https' if use_ssl else 'http'}://{ip}:{port}",
        }
    return None


def _fingerprint_hosts(ips: list[str], timeout_s: float = 1.5) -> dict[str, dict[str, Any]]:
    """
    Interroga todos los hosts en paralelo.
    Con 30 dispositivos el tiempo total es ~1.5s (un solo timeout round).
    """
    if not ips:
        return {}
    results: dict[str, dict[str, Any]] = {}
    workers = min(64, max(8, len(ips)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(_fingerprint_one, ip, timeout_s): ip for ip in ips}
        for future in as_completed(future_map):
            ip = future_map[future]
            try:
                result = future.result()
                if result is not None:
                    results[ip] = result
            except Exception:
                pass
    return results


# ── arping sweep ───────────────────────────────────────────────────────────────

def _arping_available() -> bool:
    return shutil.which("arping") is not None


def _arping_one(ip_address: str, interface: str) -> str | None:
    try:
        result = subprocess.run(
            ["arping", "-c", "1", "-I", interface, ip_address],
            capture_output=True,
            text=True,
            timeout=2.5,
            check=False,
        )
        match = re.search(r"([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})", result.stdout)
        if match:
            return match.group(1).upper()
    except (subprocess.TimeoutExpired, OSError):
        pass
    return None


def _arping_sweep(network_cidr: str, interface: str, max_hosts: int) -> dict[str, str]:
    """ARP sweep L2: obtiene MACs directamente. No puede ser bloqueado por firewalls."""
    network = ipaddress.ip_network(network_cidr, strict=False)
    candidates = [str(ip) for ip in network.hosts()][:max(0, max_hosts)]
    if not candidates:
        return {}
    results: dict[str, str] = {}
    workers = min(48, max(4, len(candidates)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(_arping_one, ip, interface): ip for ip in candidates}
        for future in as_completed(future_map):
            ip = future_map[future]
            try:
                mac = future.result()
                if mac:
                    results[ip] = mac
            except Exception:
                pass
    return results


def _nmap_sweep(network_cidr: str, max_hosts: int) -> dict[str, dict[str, str]]:
    """Sweep adicional con nmap, útil para inventario y MAC/vendor cuando está disponible."""
    if not shutil.which("nmap"):
        return {}

    network = ipaddress.ip_network(network_cidr, strict=False)
    candidates = [str(ip) for ip in network.hosts()][:max(0, max_hosts)]
    if not candidates:
        return {}

    target_args = [network_cidr] if len(candidates) > 16 else candidates
    commands = [["nmap", "-sn", "-n", *target_args]]
    if not _is_windows() and shutil.which("sudo"):
        commands.insert(0, ["sudo", "-n", "nmap", "-sn", "-n", *target_args])

    output = ""
    for args in commands:
        try:
            output = _run_command(args, timeout=max(25.0, min(180.0, len(candidates) * 0.8)))
            if output:
                break
        except Exception:
            output = ""

    results: dict[str, dict[str, str]] = {}
    current_ip: str | None = None
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line.startswith("Nmap scan report for "):
            host = line.removeprefix("Nmap scan report for ").strip()
            match = re.search(r"\((\d{1,3}(?:\.\d{1,3}){3})\)", host)
            current_ip = match.group(1) if match else host.split()[-1]
            if current_ip:
                results.setdefault(current_ip, {})
        elif current_ip and line.startswith("MAC Address:"):
            match = re.search(r"MAC Address:\s+([0-9A-Fa-f:.-]+)(?:\s+\(([^)]+)\))?", line)
            if match:
                results.setdefault(current_ip, {})["mac"] = _normalize_mac(match.group(1)) or match.group(1)
                if match.group(2):
                    results[current_ip]["vendor"] = match.group(2).strip()
    return results


# ── Resolución DNS/mDNS inversa ────────────────────────────────────────────────

def _resolve_hostname(ip_address: str) -> str | None:
    try:
        name = socket.gethostbyaddr(ip_address)[0]
        if name and name != ip_address:
            return name.split(".")[0]
    except (socket.herror, OSError):
        pass
    return None


# ── Tabla de vecinos ARP ───────────────────────────────────────────────────────

def _read_windows_neighbors(local_ip: str) -> list[dict[str, Any]]:
    try:
        payload = _powershell_json(
            r"""
            Get-NetNeighbor -AddressFamily IPv4 |
              Where-Object {
                $_.IPAddress -notmatch '^(224\.|239\.|255\.|127\.)' -and
                $_.LinkLayerAddress -and
                $_.LinkLayerAddress -notmatch '^(00-00-00-00-00-00|FF-FF-FF-FF-FF-FF)$'
              } |
              ForEach-Object {
                [pscustomobject]@{
                  InterfaceAlias   = $_.InterfaceAlias
                  IPAddress        = $_.IPAddress
                  LinkLayerAddress = $_.LinkLayerAddress
                  State            = $_.State.ToString()
                }
              } | ConvertTo-Json -Compress -Depth 3
            """
        )
        return [
            {
                "InterfaceAlias": str(r.get("InterfaceAlias") or ""),
                "IPAddress": str(r.get("IPAddress") or ""),
                "LinkLayerAddress": str(r.get("LinkLayerAddress") or ""),
                "State": str(r.get("State") or ""),
            }
            for r in _normalize_records(payload)
        ]
    except Exception:
        raw = _run_command(["arp", "-a"])
        records: list[dict[str, Any]] = []
        pattern = re.compile(
            r"^\s*(?P<ip>\d+\.\d+\.\d+\.\d+)\s+(?P<mac>(?:[0-9a-f]{2}-){5}[0-9a-f]{2})\s+(?P<state>\w+)",
            re.IGNORECASE,
        )
        for line in raw.splitlines():
            m = pattern.match(line)
            if m:
                records.append({
                    "InterfaceAlias": "",
                    "IPAddress": m.group("ip"),
                    "LinkLayerAddress": m.group("mac"),
                    "State": m.group("state"),
                })
        return records


def _read_linux_neighbors() -> list[dict[str, Any]]:
    payload = json.loads(_run_command(["ip", "-j", "neigh"]))
    records: list[dict[str, Any]] = []
    for item in payload:
        if item.get("family") not in (None, "inet"):
            continue
        records.append({
            "InterfaceAlias": item.get("dev"),
            "IPAddress": item.get("dst"),
            "LinkLayerAddress": item.get("lladdr"),
            "State": item.get("state"),
        })
    return records


def _neighbors_for_network(
    network_cidr: str,
    interface_alias: str,
    local_ip: str,
    gateway_ip: str | None,
    probe_results: dict[str, bool],
    arping_results: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    network = ipaddress.ip_network(network_cidr, strict=False)
    records = _read_windows_neighbors(local_ip) if _is_windows() else _read_linux_neighbors()
    invalid_states = {"unreachable", "incomplete", "invalid", "probe", "failed"}
    invalid_macs = {"", "00:00:00:00:00:00", "FF:FF:FF:FF:FF:FF"}

    filtered: list[dict[str, Any]] = []
    for item in records:
        ip_value = str(item.get("IPAddress") or "")
        if not ip_value:
            continue
        try:
            ip_obj = ipaddress.ip_address(ip_value)
        except ValueError:
            continue
        if ip_obj not in network:
            continue
        if ip_obj == network.broadcast_address or ip_obj == network.network_address:
            continue
        record_interface = str(item.get("InterfaceAlias") or "")
        if record_interface and record_interface != interface_alias:
            continue
        if ip_value == local_ip:
            continue
        normalized_mac = str(item.get("LinkLayerAddress") or "").replace("-", ":").upper()
        state = str(item.get("State") or "").lower()
        if state in invalid_states:
            continue
        if normalized_mac in invalid_macs:
            continue
        filtered.append({
            "ip": ip_value,
            "mac": normalized_mac,
            "state": state,
            "isGateway": bool(gateway_ip and ip_value == gateway_ip),
        })

    deduped: dict[str, dict[str, Any]] = {item["ip"]: item for item in filtered}

    for ip_address, responded in probe_results.items():
        if not responded or ip_address == local_ip:
            continue
        if ip_address not in deduped:
            deduped[ip_address] = {
                "ip": ip_address,
                "mac": "",
                "state": "ping",
                "isGateway": bool(gateway_ip and ip_address == gateway_ip),
            }

    if arping_results:
        for ip_address, mac in arping_results.items():
            if ip_address == local_ip:
                continue
            if ip_address in deduped:
                if not deduped[ip_address].get("mac"):
                    deduped[ip_address]["mac"] = mac
            else:
                deduped[ip_address] = {
                    "ip": ip_address,
                    "mac": mac,
                    "state": "arping",
                    "isGateway": bool(gateway_ip and ip_address == gateway_ip),
                }

    return list(deduped.values())


# ── Snapshot builder ───────────────────────────────────────────────────────────

def _best_display_name(
    ip: str,
    friendly_name: str | None,
    model: str | None,
    netbios_name: str | None,
    dns_name: str | None,
    vendor: str | None,
) -> str:
    """Nombre más descriptivo disponible, con IP entre paréntesis."""
    label = friendly_name or netbios_name or dns_name or model or vendor
    if label:
        return f"{label} ({ip})"
    return ip


def _build_local_snapshot(
    site_name: str,
    interface_record: dict[str, Any],
    local_ip: str,
    network_cidr: str,
    neighbors: list[dict[str, Any]],
    avahi_data: dict[str, dict[str, Any]] | None = None,
    netbios_data: dict[str, str] | None = None,
    lldp_neighbors: list[dict[str, Any]] | None = None,
    http_fingerprints: dict[str, dict[str, Any]] | None = None,
    open_port_data: dict[str, list[int]] | None = None,
    mikrotik_warning: str | None = None,
    snmp_admin_devices: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    gateway_ip = interface_record.get("Gateway")
    root_device_id = "observed-gateway" if gateway_ip else "observed-segment"
    interface_alias = str(interface_record.get("InterfaceAlias") or "lan")
    hostname = _local_hostname()

    gateway_mac = next((item.get("mac") for item in neighbors if item.get("isGateway")), "") or ""
    notes = [
        "Snapshot generado por descubrimiento local multi-protocolo (fping+arping+mDNS+NetBIOS+SSDP).",
        "No representa topologia L2 completa; muestra la red visible desde la subred actual.",
    ]
    if mikrotik_warning:
        notes.append(mikrotik_warning)

    devices = [
        {
            "id": root_device_id,
            "name": gateway_ip or f"Segmento {network_cidr}",
            "kind": "router" if gateway_ip else "segment",
            "vendor": "Gateway detectado" if gateway_ip else "Segmento local",
            "os": "Autodetectado",
            "managementIp": gateway_ip or local_ip,
            "site": site_name,
            "interfaces": [
                {
                    "name": interface_alias,
                    "role": "observed-lan",
                    "mode": "unknown",
                    "allowedVlans": [],
                }
            ],
            "networks": [
                {
                    "cidr": network_cidr,
                    "name": interface_alias,
                    "vlanId": None,
                }
            ],
        }
    ]

    # Agregar vecinos LLDP como dispositivos administrables si tienen IP de gestión
    if lldp_neighbors:
        for lldp in lldp_neighbors:
            for mgmt_ip in lldp.get("mgmt_ips", []):
                lldp_id = f"lldp-{mgmt_ip.replace('.', '-')}"
                caps = lldp.get("capabilities", [])
                kind = "switch" if "Bridge" in caps else "router" if "Router" in caps else "device"
                devices.append({
                    "id": lldp_id,
                    "name": lldp["name"],
                    "kind": kind,
                    "vendor": "LLDP",
                    "os": lldp.get("description", ""),
                    "managementIp": mgmt_ip,
                    "site": site_name,
                    "interfaces": [],
                    "networks": [],
                })

    # Agregar dispositivos administrables detectados por SNMP
    # Build lookup: ip → device_id for all already-known infra devices
    known_infra_ips = {gateway_ip} if gateway_ip else set()
    for d in devices:
        if d.get("managementIp"):
            known_infra_ips.add(d["managementIp"])

    # Map ip → snmp device_id for later host attachment
    snmp_device_id_by_ip: dict[str, str] = {}
    if snmp_admin_devices:
        for admin_ip, admin_data in snmp_admin_devices.items():
            if admin_ip in known_infra_ips:
                continue  # Already represented
            dev_id = f"snmp-admin-{admin_ip.replace('.', '-')}"
            snmp_device_id_by_ip[admin_ip] = dev_id
            iface_count = admin_data.get("interfaces", 2)
            kind = "router" if iface_count > 8 else "ap" if iface_count <= 3 else "switch"
            devices.append({
                "id": dev_id,
                "name": admin_ip,
                "kind": kind,
                "vendor": f"SNMP ({iface_count} interfaces)",
                "os": "Detectado por SNMP",
                "managementIp": admin_ip,
                "site": site_name,
                "interfaces": [],
                "networks": [],
            })
            known_infra_ips.add(admin_ip)

    # Build reverse map: host_ip → admin_device_id (for parent assignment)
    host_to_admin: dict[str, str] = {}
    if snmp_admin_devices:
        for admin_ip, admin_data in snmp_admin_devices.items():
            admin_dev_id = snmp_device_id_by_ip.get(admin_ip) or (
                root_device_id if admin_ip == gateway_ip else None
            )
            if not admin_dev_id:
                continue
            for neighbor_ip in admin_data.get("neighbors", []):
                if neighbor_ip not in known_infra_ips and neighbor_ip != local_ip:
                    host_to_admin[neighbor_ip] = admin_dev_id

    hosts = [
        {
            "id": "collector-local",
            "name": hostname,
            "kind": "collector",
            "subtitle": "Collector NetTopo",
            "ip": local_ip,
            "mac": "",
            "vlanId": None,
            "attachedTo": {
                "deviceId": root_device_id,
                "interfaceName": interface_alias,
            },
        }
    ]
    mac_table: list[dict[str, Any]] = []

    avahi = avahi_data or {}
    netbios = netbios_data or {}
    fingerprints = http_fingerprints or {}
    open_ports_map = open_port_data or {}

    for index, item in enumerate(neighbors, start=1):
        if item.get("isGateway"):
            continue

        host_id = f"host-local-{index}"
        mac = item.get("mac", "")
        ip = item["ip"]

        vendor = oui_lookup(mac) if mac else None
        dns_name = _resolve_hostname(ip)

        avahi_info = avahi.get(ip, {})
        friendly_name = avahi_info.get("friendly_name")
        avahi_model = avahi_info.get("model")
        avahi_hostname = avahi_info.get("hostname")
        services = avahi_info.get("services", [])
        subtitle = avahi_info.get("subtitle", "")
        open_ports = open_ports_map.get(ip, [])

        netbios_name = netbios.get(ip)
        fp = fingerprints.get(ip)

        # El HTTP fingerprint enriquece vendor/model si lo identifica
        fp_vendor = fp.get("vendor", "") if fp else ""
        fp_model = fp.get("model", "") if fp else ""
        fp_kind = fp.get("kind", "") if fp else ""
        fp_url = fp.get("mgmt_url", "") if fp else ""

        # Vendor final: fingerprint HTTP > OUI MAC
        final_vendor = fp_vendor or vendor or "Desconocido"
        final_model = fp_model or avahi_model or ""
        inferred = _infer_host_profile(
            vendor=final_vendor if final_vendor != "Desconocido" else vendor,
            dns_name=dns_name,
            netbios_name=netbios_name,
            friendly_name=friendly_name,
            model=final_model,
            services=services,
            open_ports=open_ports,
        )
        final_kind = fp_kind or inferred.get("kind", "host")
        if final_vendor == "Desconocido" and inferred.get("vendor"):
            final_vendor = inferred["vendor"]
        if not final_model and inferred.get("model"):
            final_model = inferred["model"]

        display_name = _best_display_name(
            ip=ip,
            friendly_name=friendly_name,
            model=final_model if (not friendly_name and final_model) else None,
            netbios_name=netbios_name,
            dns_name=dns_name or avahi_hostname,
            vendor=final_vendor if final_vendor != "Desconocido" else None,
        )
        if display_name == ip and final_kind not in ("host", "device", "observed-host"):
            display_name = f"{inferred.get('label') or _kind_label(final_kind)} ({ip})"

        # Subtitle compuesto con toda la info disponible
        parts: list[str] = []
        if subtitle:
            parts.append(subtitle)
        elif final_kind and final_kind not in ("device", "host", "observed-host"):
            parts.append(inferred.get("subtitle") or _kind_label(final_kind))
        if final_model and final_model not in "".join(parts):
            parts.append(final_model)
        if not parts and final_vendor and final_vendor != "Desconocido":
            parts.append(final_vendor)
        if not parts and open_ports:
            parts.append("Puertos: " + ", ".join(_COMMON_PORT_LABELS.get(port, str(port)) for port in open_ports[:4]))
        final_subtitle = " · ".join(parts)

        # Si el HTTP fingerprint lo identifica como infraestructura,
        # va a devices (nodo azul administrable) en vez de hosts (endpoint)
        if fp and fp_kind in _INFRA_KINDS:
            dev_id = f"http-device-{ip.replace('.', '-')}"
            device: dict[str, Any] = {
                "id": dev_id,
                "name": display_name,
                "kind": fp_kind,
                "vendor": final_vendor,
                "model": final_model,
                "os": f"Detectado por HTTP ({fp_url})",
                "managementIp": ip,
                "mac": mac,
                "subtitle": final_subtitle,
                "site": site_name,
                "interfaces": [],
                "networks": [],
            }
            if fp_url:
                device["mgmtUrl"] = fp_url
            if services:
                device["mdnsServices"] = services
            devices.append(device)
            if mac:
                mac_table.append({
                    "deviceId": dev_id,
                    "interfaceName": "eth0",
                    "vlanId": None,
                    "macAddress": mac,
                })
            continue

        # Si el host es vecino ARP de un admin SNMP, adscribirlo a ese dispositivo
        parent_device_id = host_to_admin.get(ip, root_device_id)
        host: dict[str, Any] = {
            "id": host_id,
            "name": display_name,
            "kind": final_kind or "observed-host",
            "subtitle": final_subtitle,
            "ip": ip,
            "mac": mac,
            "vendor": final_vendor,
            "openPorts": open_ports,
            "vlanId": None,
            "attachedTo": {
                "deviceId": parent_device_id,
                "interfaceName": interface_alias,
            },
        }
        if fp_url:
            host["mgmtUrl"] = fp_url
        if fp:
            host["httpInfo"] = fp
        if services:
            host["mdnsServices"] = services
        if netbios_name:
            host["netbiosName"] = netbios_name

        hosts.append(host)

        if mac:
            mac_table.append({
                "deviceId": root_device_id,
                "interfaceName": interface_alias,
                "vlanId": None,
                "macAddress": mac,
            })

    if gateway_mac:
        mac_table.append({
            "deviceId": root_device_id,
            "interfaceName": interface_alias,
            "vlanId": None,
            "macAddress": gateway_mac,
        })

    return {
        "metadata": {
            "name": site_name,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "source": "local-discovery",
            "notes": " ".join(notes),
        },
        "rootDeviceId": root_device_id,
        "devices": devices,
        "l2Neighbors": [],
        "hosts": hosts,
        "macTable": mac_table,
    }


# ── Adapter principal ──────────────────────────────────────────────────────────

class LocalDiscoveryAdapter(SourceAdapter):
    def collect(self) -> CollectionResult:
        settings = self.source.settings
        warnings: list[str] = []
        snmp_admin_devices: dict[str, dict[str, Any]] | None = None
        open_port_data: dict[str, list[int]] | None = None

        try:
            records = _discover_windows_interfaces() if _is_windows() else _discover_linux_interfaces()
            preferred_alias = settings.get("interface_alias")
            interface_record = _select_interface(records, preferred_alias)
            local_ip, network_cidr = _cidr_from_interface(interface_record)
            if settings.get("network_cidr"):
                network_cidr = str(settings["network_cidr"])
            interface_name = str(interface_record.get("InterfaceAlias") or "")

            max_hosts = int(settings.get("max_hosts", 254))
            ping_timeout_ms = int(settings.get("ping_timeout_ms", 400))

            tcp_cfg = settings.get("tcp_probe") if isinstance(settings.get("tcp_probe"), dict) else {}
            ssdp_cfg = settings.get("ssdp") if isinstance(settings.get("ssdp"), dict) else {}
            ssdp_timeout = float(ssdp_cfg.get("timeout_s", 3.0)) if ssdp_cfg.get("enabled", True) else 0.0

            # ── Fase 1: todos los métodos de descubrimiento en paralelo ──────
            with ThreadPoolExecutor(max_workers=6) as pool:
                fut_probe  = pool.submit(_probe_network, network_cidr, max_hosts, ping_timeout_ms)
                fut_ssdp   = pool.submit(_discover_ssdp, ssdp_timeout) if ssdp_timeout > 0 else None
                fut_avahi  = pool.submit(_discover_avahi, 7.0)
                fut_nbtscan = pool.submit(_discover_netbios, network_cidr, 12.0)
                fut_lldp   = pool.submit(_discover_lldp_local)

                probe_results: dict[str, bool] = fut_probe.result()
                ssdp_ips: set[str] = fut_ssdp.result() if fut_ssdp else set()
                avahi_data: dict[str, dict[str, Any]] = fut_avahi.result()
                netbios_data: dict[str, str] = fut_nbtscan.result()
                lldp_neighbors: list[dict[str, Any]] = fut_lldp.result()

            # Marcar IPs de SSDP como vivos
            network_obj = ipaddress.ip_network(network_cidr, strict=False)
            for ssdp_ip in ssdp_ips:
                try:
                    if ipaddress.ip_address(ssdp_ip) in network_obj and ssdp_ip != local_ip:
                        probe_results[ssdp_ip] = True
                except ValueError:
                    pass

            # Marcar IPs de avahi como vivos (responden mDNS → están en la red)
            for avahi_ip in avahi_data:
                try:
                    if ipaddress.ip_address(avahi_ip) in network_obj and avahi_ip != local_ip:
                        probe_results[avahi_ip] = True
                except ValueError:
                    pass

            # ── Fase 2: TCP probe en los que no respondieron a nada ──────────
            if tcp_cfg.get("enabled", True):
                non_alive = [ip for ip, alive in probe_results.items() if not alive and ip != local_ip]
                tcp_ports = tuple(tcp_cfg.get("ports", [80, 443, 8080, 554, 8443, 7000, 8291]))
                tcp_timeout = float(tcp_cfg.get("timeout_ms", 400)) / 1000
                for ip in _tcp_probe_hosts(non_alive, tcp_ports, tcp_timeout):
                    probe_results[ip] = True

            # ── Fase 3: arping sweep L2 (MACs directas, sin depender del caché ARP) ──
            arping_results: dict[str, str] = {}
            if not _is_windows() and interface_name and _arping_available():
                arping_results = _arping_sweep(network_cidr, interface_name, max_hosts)
                for ip in arping_results:
                    if ip != local_ip:
                        probe_results[ip] = True

            # ── Fase 3b: nmap ping/ARP sweep si está instalado ───────────────
            nmap_results = _nmap_sweep(network_cidr, max_hosts)
            for ip, info in nmap_results.items():
                if ip == local_ip:
                    continue
                probe_results[ip] = True
                if info.get("mac"):
                    arping_results.setdefault(ip, info["mac"])

            neighbors = _neighbors_for_network(
                network_cidr=network_cidr,
                interface_alias=interface_name,
                local_ip=local_ip,
                gateway_ip=interface_record.get("Gateway"),
                probe_results=probe_results,
                arping_results=arping_results if arping_results else None,
            )

            # ── Fase 4: HTTP fingerprinting activo ──────────────────────────
            # Interroga cada host descubierto en todos los puertos de gestión.
            # No espera que los dispositivos se anuncien — va y les pregunta.
            all_discovered_ips = [
                item["ip"] for item in neighbors
                if not item.get("isGateway") and item["ip"] != local_ip
            ]
            http_fingerprints = _fingerprint_hosts(all_discovered_ips, timeout_s=1.5)
            open_port_data = _probe_open_ports(all_discovered_ips)

            # ── Fase 5: SNMP recursive scan ──────────────────────────────────
            # Detecta dispositivos administrables (switches/APs) "aguas adentro"
            # de la red que no responden a ARP/ICMP directamente desde el collector.
            snmp_admin_devices: dict[str, dict[str, Any]] | None = None
            snmp_cfg = settings.get("snmp") if isinstance(settings, dict) else {}
            if isinstance(snmp_cfg, dict) and snmp_cfg.get("enabled", False):
                community = str(snmp_cfg.get("community", "public"))
                snmp_timeout = float(snmp_cfg.get("timeout_s", 2.0))
                min_ifaces = int(snmp_cfg.get("min_interfaces", 3))
                # Scan todos los IPs descubiertos buscando dispositivos con muchas interfaces
                snmp_admin_devices = _discover_snmp_admins(
                    ips=all_discovered_ips,
                    community=community,
                    timeout_s=snmp_timeout,
                    min_interfaces=min_ifaces,
                )

        except Exception as exc:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=[f"No se pudo ejecutar el descubrimiento local: {exc}"],
            )

        # ── Enriquecimiento RouterOS en el gateway (si configurado) ──────────
        gateway_ip = interface_record.get("Gateway")
        mikrotik_settings = settings.get("mikrotik") if isinstance(settings.get("mikrotik"), dict) else {}
        use_gateway_as_routeros = bool(mikrotik_settings.get("enabled")) and bool(gateway_ip)

        if use_gateway_as_routeros:
            username = str(mikrotik_settings.get("username") or "").strip()
            password = str(mikrotik_settings.get("password") or "")
            if not username or not password:
                warnings.append("Se omitio el enriquecimiento MikroTik porque faltan credenciales.")
            else:
                config = RouterOsConfig(
                    site_name=self.site_name,
                    host=str(gateway_ip),
                    username=username,
                    password=password,
                    verify_tls=bool(mikrotik_settings.get("verify_tls", False)),
                    timeout_seconds=int(mikrotik_settings.get("timeout_seconds", 10)),
                    rest_port=int(mikrotik_settings.get("port", 443)),
                )
                max_neighbor_depth = max(0, int(mikrotik_settings.get("max_neighbor_depth", 1)))
                try:
                    result = collect_routeros_discovery(config, max_neighbor_depth=max_neighbor_depth)
                    snapshot = result.snapshot
                    snapshot.setdefault("metadata", {})
                    snapshot["metadata"]["source"] = "local-discovery+routeros-rest"
                    snapshot["metadata"]["notes"] = (
                        "Snapshot iniciado por descubrimiento local y enriquecido desde RouterOS REST recursivo."
                    )
                    combined_warnings = [*warnings, *result.warnings]
                    if combined_warnings:
                        snapshot["metadata"]["warnings"] = combined_warnings
                    return CollectionResult(
                        source_type=self.source.type,
                        source_name=self.source.name,
                        snapshot=snapshot,
                        warnings=combined_warnings,
                    )
                except RouterOsRestError as exc:
                    warnings.append(f"No se pudo enriquecer por RouterOS REST: {exc}")

        snapshot = _build_local_snapshot(
            site_name=self.site_name,
            interface_record=interface_record,
            local_ip=local_ip,
            network_cidr=network_cidr,
            neighbors=neighbors,
            avahi_data=avahi_data,
            netbios_data=netbios_data,
            lldp_neighbors=lldp_neighbors,
            http_fingerprints=http_fingerprints,
            open_port_data=open_port_data,
            mikrotik_warning=warnings[0] if warnings else None,
            snmp_admin_devices=snmp_admin_devices,
        )

        return CollectionResult(
            source_type=self.source.type,
            source_name=self.source.name,
            snapshot=snapshot,
            warnings=warnings,
        )
