from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from ..site_models import CollectionResult
from ..snmp_client import SnmpCollectionError, SnmpTargetConfig, SnmpUnavailableError
from ..snmp_snapshot import collect_snmp_target_snapshot
from .base import SourceAdapter


def _merge_defined_fields(base: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in incoming.items():
        if value not in (None, "", [], {}):
            merged[key] = value
    return merged


def _merge_interfaces(existing: list[dict[str, Any]], incoming: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {
        str(item.get("name")): dict(item)
        for item in existing
        if item.get("name")
    }
    for item in incoming:
        name = str(item.get("name") or "")
        if not name:
            continue
        merged[name] = _merge_defined_fields(merged.get(name, {}), item)
    return list(merged.values())


def _merge_networks(existing: list[dict[str, Any]], incoming: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[tuple[str, Any], dict[str, Any]] = {}
    for item in [*existing, *incoming]:
        cidr = str(item.get("cidr") or "")
        if not cidr:
            continue
        key = (cidr, item.get("vlanId"))
        merged[key] = _merge_defined_fields(merged.get(key, {}), item)
    return list(merged.values())


def _merge_devices(current: dict[str, Any] | None, candidate: dict[str, Any]) -> dict[str, Any]:
    if current is None:
        return {
            **candidate,
            "interfaces": [dict(item) for item in candidate.get("interfaces", [])],
            "networks": [dict(item) for item in candidate.get("networks", [])],
        }

    merged = _merge_defined_fields(current, candidate)
    merged["interfaces"] = _merge_interfaces(current.get("interfaces", []), candidate.get("interfaces", []))
    merged["networks"] = _merge_networks(current.get("networks", []), candidate.get("networks", []))
    return merged


def _host_score(host: dict[str, Any]) -> int:
    attached = host.get("attachedTo") or {}
    observed = host.get("observedVia") or {}
    if attached.get("deviceId") and attached.get("deviceId") != observed.get("deviceId"):
        return 3
    if attached.get("deviceId"):
        return 2
    if host.get("ip"):
        return 1
    return 0


def _merge_hosts(current: dict[str, Any] | None, candidate: dict[str, Any]) -> dict[str, Any]:
    if current is None:
        return dict(candidate)

    preferred = candidate if _host_score(candidate) >= _host_score(current) else current
    fallback = current if preferred is candidate else candidate
    merged = _merge_defined_fields(fallback, preferred)
    if "observedVia" not in merged and "observedVia" in fallback:
        merged["observedVia"] = fallback["observedVia"]
    return merged


class GenericSnmpAdapter(SourceAdapter):
    def collect(self) -> CollectionResult:
        targets = self.source.settings.get("targets", [])
        if not targets:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=["La fuente snmp-generic no tiene targets configurados."],
            )

        try:
            warnings: list[str] = []
            root_device_id = None
            max_neighbor_depth = max(0, int(self.source.settings.get("max_neighbor_depth", 1)))
            visited_targets: set[str] = set()
            queue: list[tuple[str, int]] = [(str(target), 0) for target in targets if target]
            devices_by_id: dict[str, dict[str, Any]] = {}
            hosts_by_id: dict[str, dict[str, Any]] = {}
            mac_rows: dict[tuple[str, str, Any, str], dict[str, Any]] = {}
            l2_neighbors: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}

            while queue:
                target, depth = queue.pop(0)
                if target in visited_targets:
                    continue
                visited_targets.add(target)

                snmp_config = SnmpTargetConfig(
                    host=target,
                    port=int(self.source.settings.get("port", 161)),
                    version=str(self.source.settings.get("version", "2c")),
                    community=str(self.source.settings.get("community", "public")),
                    timeout_seconds=int(self.source.settings.get("timeout_seconds", 3)),
                    retries=int(self.source.settings.get("retries", 1)),
                )

                try:
                    result = collect_snmp_target_snapshot(target, self.site_name, snmp_config)
                except SnmpCollectionError as exc:
                    warnings.append(f"{target}: {exc}")
                    continue

                snapshot = result.snapshot
                if root_device_id is None:
                    root_device_id = snapshot.get("rootDeviceId")

                warnings.extend(result.warnings)

                for device in snapshot.get("devices", []):
                    device_id = str(device.get("id") or "")
                    if not device_id:
                        continue
                    devices_by_id[device_id] = _merge_devices(devices_by_id.get(device_id), device)

                for host in snapshot.get("hosts", []):
                    host_id = str(host.get("id") or "")
                    if not host_id:
                        continue
                    hosts_by_id[host_id] = _merge_hosts(hosts_by_id.get(host_id), host)

                for row in snapshot.get("macTable", []):
                    key = (
                        str(row.get("deviceId") or ""),
                        str(row.get("interfaceName") or ""),
                        row.get("vlanId"),
                        str(row.get("macAddress") or "").upper(),
                    )
                    if key[0] and key[1] and key[3]:
                        mac_rows.setdefault(key, row)

                for link in snapshot.get("l2Neighbors", []):
                    key = (
                        str(link.get("localDeviceId") or ""),
                        str(link.get("localInterfaceName") or ""),
                        str(link.get("remoteDeviceId") or ""),
                        str(link.get("remoteInterfaceName") or ""),
                        str(link.get("protocol") or ""),
                    )
                    reverse = (key[2], key[3], key[0], key[1], key[4])
                    if key[0] and key[1] and key[2] and reverse not in l2_neighbors:
                        l2_neighbors.setdefault(key, link)

                if depth >= max_neighbor_depth:
                    continue

                for neighbor_ip in result.neighbor_ips:
                    if neighbor_ip and neighbor_ip not in visited_targets:
                        queue.append((str(neighbor_ip), depth + 1))

            if not devices_by_id:
                return CollectionResult(
                    source_type=self.source.type,
                    source_name=self.source.name,
                    warnings=["No se pudo recolectar ningun target SNMP valido."],
                )

            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                snapshot={
                    "metadata": {
                        "name": self.site_name,
                        "generatedAt": datetime.now(timezone.utc).isoformat(),
                        "source": "snmp-generic",
                        "notes": "Snapshot generado por SNMP generico con expansion recursiva.",
                        "warnings": warnings,
                    },
                    "rootDeviceId": root_device_id,
                    "devices": list(devices_by_id.values()),
                    "l2Neighbors": list(l2_neighbors.values()),
                    "hosts": list(hosts_by_id.values()),
                    "macTable": list(mac_rows.values()),
                },
                warnings=warnings,
            )
        except SnmpUnavailableError as exc:
            return CollectionResult(
                source_type=self.source.type,
                source_name=self.source.name,
                warnings=[
                    str(exc),
                    "Instalacion sugerida: python -m pip install pysnmp",
                ],
            )
