"""
OUI vendor lookup for MAC address identification.
Key: 6 uppercase hex chars (OUI without separators). Source: IEEE MA-L registry.
Complemented at load time with manuf.txt (Wireshark database) if present.
"""
from __future__ import annotations
import os as _os
import re as _re

def _load_manuf() -> dict[str, str]:
    manuf_path = _os.path.join(_os.path.dirname(__file__), "manuf.txt")
    result: dict[str, str] = {}
    try:
        with open(manuf_path, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                if len(parts) < 2:
                    continue
                raw_mac = parts[0].strip()
                vendor = parts[1].strip()
                if not vendor or vendor == raw_mac:
                    vendor = parts[2].strip() if len(parts) > 2 else ""
                if not vendor:
                    continue
                # Solo OUI de 3 bytes (6 hex chars)
                normalized = raw_mac.upper().replace(":", "").replace("-", "")
                if len(normalized) == 6 and _re.fullmatch(r"[0-9A-F]{6}", normalized):
                    result[normalized] = vendor
    except OSError:
        pass
    return result

_MANUF: dict[str, str] = _load_manuf()

# fmt: off
_OUI: dict[str, str] = {

    # ── Apple ──────────────────────────────────────────────────
    "000393": "Apple", "000A27": "Apple", "000A95": "Apple",
    "000D93": "Apple", "001124": "Apple", "001451": "Apple",
    "0016CB": "Apple", "0017F2": "Apple", "0019E3": "Apple",
    "001B63": "Apple", "001CB3": "Apple", "001D4F": "Apple",
    "001E52": "Apple", "001EC2": "Apple", "001F5B": "Apple",
    "001FF3": "Apple", "002241": "Apple", "002312": "Apple",
    "002332": "Apple", "00236C": "Apple", "0023DF": "Apple",
    "002436": "Apple", "002500": "Apple", "00254B": "Apple",
    "0025BC": "Apple", "002608": "Apple", "00264A": "Apple",
    "0026B0": "Apple", "0026BB": "Apple", "003065": "Apple",
    "040CCE": "Apple", "041552": "Apple", "041E64": "Apple",
    "042665": "Apple", "044536": "Apple", "04F13E": "Apple",
    "080007": "Apple", "0C3E9F": "Apple", "0C74C2": "Apple",
    "0C771A": "Apple", "0C9D92": "Apple", "101C0C": "Apple",
    "109ADD": "Apple", "10DDB1": "Apple", "14109F": "Apple",
    "145A05": "Apple", "148FC6": "Apple", "1499E2": "Apple",
    "14BD61": "Apple", "183451": "Apple", "186590": "Apple",
    "18AF61": "Apple", "18E7F4": "Apple", "1C1AC0": "Apple",
    "1C36BB": "Apple", "1C5CF2": "Apple", "1CABA7": "Apple",
    "2078F0": "Apple", "209BCD": "Apple", "20A2E4": "Apple",
    "20AB37": "Apple", "241EEB": "Apple", "245BA7": "Apple",
    "24A074": "Apple", "280B5C": "Apple", "285AEB": "Apple",
    "286ABA": "Apple", "28CFE9": "Apple", "2C1F23": "Apple",
    "2CBE08": "Apple", "2CF0A2": "Apple", "3408BC": "Apple",
    "34159E": "Apple", "3451C9": "Apple", "34A395": "Apple",
    "380F4A": "Apple", "38539C": "Apple", "3C0754": "Apple",
    "3C15C2": "Apple", "3C2EF9": "Apple", "3CD0F8": "Apple",
    "403CFC": "Apple", "406C8F": "Apple", "40A6D9": "Apple",
    "442A60": "Apple", "44D884": "Apple", "44FB42": "Apple",
    "48437C": "Apple", "48746E": "Apple", "48BF6B": "Apple",
    "4C5745": "Apple", "4C7403": "Apple", "4C8D79": "Apple",
    "503237": "Apple", "5082D5": "Apple", "542696": "Apple",
    "54AE27": "Apple", "54E43A": "Apple", "581FAA": "Apple",
    "5855CA": "Apple", "587F57": "Apple", "5C5948": "Apple",
    "5C8D4E": "Apple", "5C969D": "Apple", "5CF7E6": "Apple",
    "600308": "Apple", "60334B": "Apple", "609AC1": "Apple",
    "60C547": "Apple", "60D9C7": "Apple", "640CC4": "Apple",
    "6476BA": "Apple", "64B0A6": "Apple", "680927": "Apple",
    "685B35": "Apple", "68967B": "Apple", "689C70": "Apple",
    "6C1900": "Apple", "6C4008": "Apple", "6C7220": "Apple",
    "6C94F8": "Apple", "701124": "Apple", "703EAC": "Apple",
    "70480F": "Apple", "705681": "Apple", "70CD60": "Apple",
    "741BB2": "Apple", "74E1B6": "Apple", "7831C1": "Apple",
    "784F43": "Apple", "786C1C": "Apple", "789F70": "Apple",
    "7C04D0": "Apple", "7C11BE": "Apple", "7C6D62": "Apple",
    "7CD1C3": "Apple", "7CF954": "Apple", "804971": "Apple",
    "84A134": "Apple", "84B153": "Apple", "84FCFE": "Apple",
    "881FA1": "Apple", "88532E": "Apple", "88665A": "Apple",
    "8C006D": "Apple", "8C5877": "Apple", "8C7C92": "Apple",
    "8C8590": "Apple", "901B0E": "Apple", "903C92": "Apple",
    "9060F1": "Apple", "94BF2D": "Apple", "9801A7": "Apple",
    "9810E8": "Apple", "985AEB": "Apple", "98D6BB": "Apple",
    "9C04EB": "Apple", "9C207B": "Apple", "9C35EB": "Apple",
    "A01828": "Apple", "A04EA7": "Apple", "A0D795": "Apple",
    "A45E60": "Apple", "A4C361": "Apple", "A4D18C": "Apple",
    "A82066": "Apple", "A851AB": "Apple", "A85B78": "Apple",
    "A8667F": "Apple", "A88E24": "Apple", "AC1F74": "Apple",
    "AC3C0B": "Apple", "AC7F3E": "Apple", "ACBC32": "Apple",
    "ACCF5C": "Apple", "B03495": "Apple", "B065BD": "Apple",
    "B418D1": "Apple", "B44BD2": "Apple", "B48B19": "Apple",
    "B8098A": "Apple", "B853AC": "Apple", "B8C75D": "Apple",
    "B8E856": "Apple", "BC3BAF": "Apple", "BC526B": "Apple",
    "BC6C21": "Apple", "BC926B": "Apple", "BCD074": "Apple",
    "C0847A": "Apple", "C09F42": "Apple", "C42C03": "Apple",
    "C4618B": "Apple", "C48E8F": "Apple", "C4B301": "Apple",
    "C81EE7": "Apple", "C82A14": "Apple", "C8334B": "Apple",
    "C8BCC8": "Apple", "CC088D": "Apple", "CC08FB": "Apple",
    "CC4463": "Apple", "D0034B": "Apple", "D02598": "Apple",
    "D04F7E": "Apple", "D0E140": "Apple", "D4619D": "Apple",
    "D49A20": "Apple", "D4DCCD": "Apple", "D4F46F": "Apple",
    "D8004D": "Apple", "D81D72": "Apple", "D83062": "Apple",
    "D8BBC1": "Apple", "DC0C5C": "Apple", "DC2B2A": "Apple",
    "DC3714": "Apple", "DC9B9C": "Apple", "E0338E": "Apple",
    "E05F45": "Apple", "E0B52D": "Apple", "E425E7": "Apple",
    "E4CE8F": "Apple", "E8040B": "Apple", "E840F2": "Apple",
    "EC3586": "Apple", "EC852F": "Apple", "F0B479": "Apple",
    "F0CBA1": "Apple", "F0D1A9": "Apple", "F40F24": "Apple",
    "F41BA1": "Apple", "F45C89": "Apple", "F4F15A": "Apple",
    "F81EDF": "Apple", "F82D7C": "Apple", "F86DC7": "Apple",
    "FCFC48": "Apple",

    # ── Samsung ────────────────────────────────────────────────
    "000278": "Samsung", "0007AB": "Samsung", "000918": "Samsung",
    "001247": "Samsung", "0012FB": "Samsung", "001599": "Samsung",
    "001632": "Samsung", "00166B": "Samsung", "0017C9": "Samsung",
    "0018AF": "Samsung", "001A8A": "Samsung", "001B98": "Samsung",
    "001C43": "Samsung", "001D25": "Samsung", "001EE1": "Samsung",
    "002119": "Samsung", "00214C": "Samsung", "002339": "Samsung",
    "0023D7": "Samsung", "002454": "Samsung", "002490": "Samsung",
    "002538": "Samsung", "002566": "Samsung", "002637": "Samsung",
    "04180F": "Samsung", "082622": "Samsung", "0C1420": "Samsung",
    "10D542": "Samsung", "1030E0": "Samsung", "143A4D": "Samsung",
    "147D58": "Samsung", "14BB6E": "Samsung", "1816C9": "Samsung",
    "182195": "Samsung", "187060": "Samsung", "18B169": "Samsung",
    "1C232C": "Samsung", "1C5A3E": "Samsung", "1C62B8": "Samsung",
    "1CF523": "Samsung", "20134E": "Samsung", "24920E": "Samsung",
    "24B6FD": "Samsung", "282168": "Samsung", "28987B": "Samsung",
    "2CB15C": "Samsung", "2CC5A0": "Samsung", "30C7AE": "Samsung",
    "34145F": "Samsung", "342BA7": "Samsung", "38AA3C": "Samsung",
    "3C0518": "Samsung", "3C6200": "Samsung", "3C8BFE": "Samsung",
    "3CA10D": "Samsung", "3CBA1B": "Samsung", "404E36": "Samsung",
    "40B0FA": "Samsung", "44658F": "Samsung", "447F40": "Samsung",
    "44A742": "Samsung", "4878AB": "Samsung", "4C3C16": "Samsung",
    "4C8809": "Samsung", "50A4C8": "Samsung", "50B5C6": "Samsung",
    "50F0D3": "Samsung", "5403A1": "Samsung", "5451DE": "Samsung",
    "549B12": "Samsung", "58C38B": "Samsung", "5C0AF5": "Samsung",
    "5C3C27": "Samsung", "5C49EB": "Samsung", "5CA3E4": "Samsung",
    "5CCA7A": "Samsung", "5CEA1D": "Samsung", "60014E": "Samsung",
    "60451D": "Samsung", "608F5C": "Samsung", "6437B9": "Samsung",
    "6476D0": "Samsung", "6488B4": "Samsung", "68EBAE": "Samsung",
    "6C2F2C": "Samsung", "6CB7F4": "Samsung", "700514": "Samsung",
    "7049B8": "Samsung", "70768A": "Samsung", "7088B1": "Samsung",
    "70A1B2": "Samsung", "7422B9": "Samsung", "742355": "Samsung",
    "745AA5": "Samsung", "74E789": "Samsung", "780190": "Samsung",
    "7825AD": "Samsung", "7C1C4E": "Samsung", "7C61AB": "Samsung",
    "7C766D": "Samsung", "7CF8DB": "Samsung", "8063E9": "Samsung",
    "809B20": "Samsung", "8426B9": "Samsung", "8465EE": "Samsung",
    "8468BC": "Samsung", "8832F9": "Samsung", "883935": "Samsung",
    "88E87F": "Samsung", "8C71F8": "Samsung", "8CB5AD": "Samsung",
    "8CBEBA": "Samsung", "8CF231": "Samsung", "8CFCD5": "Samsung",
    "900628": "Samsung", "907B4A": "Samsung", "90E7C4": "Samsung",
    "9401C2": "Samsung", "944AE6": "Samsung", "98523D": "Samsung",
    "985546": "Samsung", "9C0298": "Samsung", "9C3AAF": "Samsung",
    "9C6536": "Samsung", "9CB70D": "Samsung", "9CEF95": "Samsung",
    "A0215A": "Samsung", "A07591": "Samsung", "A0CCAB": "Samsung",
    "A4178B": "Samsung", "A49A58": "Samsung", "A4EBDB": "Samsung",
    "A82395": "Samsung", "A84E3F": "Samsung", "AC36B2": "Samsung",
    "AC5F3E": "Samsung", "B04721": "Samsung", "B063D8": "Samsung",
    "B0C559": "Samsung", "B0D09C": "Samsung", "B0EC71": "Samsung",
    "B44EF9": "Samsung", "B4A5AC": "Samsung", "B4B52A": "Samsung",
    "B4EF39": "Samsung", "B85A73": "Samsung", "B8BC1B": "Samsung",
    "B8D9CE": "Samsung", "B8F594": "Samsung", "BC1491": "Samsung",
    "BC2028": "Samsung", "BC441E": "Samsung", "BC7281": "Samsung",
    "BC8C97": "Samsung", "C01173": "Samsung", "C44686": "Samsung",
    "C46200": "Samsung", "C4624A": "Samsung", "C4735A": "Samsung",
    "C48A6B": "Samsung", "C81279": "Samsung", "C875A7": "Samsung",
    "C8AD77": "Samsung", "CCEBD2": "Samsung", "D0177E": "Samsung",
    "D02544": "Samsung", "D0DFC7": "Samsung", "D485CA": "Samsung",
    "D4BB5C": "Samsung", "D4E8B2": "Samsung", "D87474": "Samsung",
    "D8CC08": "Samsung", "DCF759": "Samsung", "E006E6": "Samsung",
    "E09AAB": "Samsung", "E4926D": "Samsung", "E49B8A": "Samsung",
    "E80C7B": "Samsung", "E89309": "Samsung", "E8B4C8": "Samsung",
    "E8D5A3": "Samsung", "ECE83B": "Samsung", "F008F1": "Samsung",
    "F08998": "Samsung", "F4E370": "Samsung", "F8042E": "Samsung",
    "F84F57": "Samsung", "F87C89": "Samsung", "FC1A11": "Samsung",
    "FCF136": "Samsung",

    # ── Google / Nest ──────────────────────────────────────────
    "001A11": "Google",  "3C5AB4": "Google",  "3CA4C4": "Google",
    "408D5C": "Google",  "48A4E2": "Google",  "4C8B30": "Google",
    "54601F": "Google",  "5C97F3": "Google",  "60F81D": "Google",
    "642E6B": "Google",  "78E873": "Google",  "7C2E0D": "Google",
    "8C1C0F": "Google",  "8CECE4": "Google",  "94E96A": "Google",
    "A47733": "Google",  "A4773C": "Google",  "AC9B1B": "Google",
    "B0A737": "Google",  "CC529A": "Google",  "D06224": "Google",
    "D0E7B9": "Google",  "D803D6": "Google",  "E0CF94": "Google",
    "F030F9": "Google",

    # ── Amazon ─────────────────────────────────────────────────
    "0026B9": "Amazon", "10AE60": "Amazon", "18741D": "Amazon",
    "1CE06F": "Amazon", "34D270": "Amazon", "40B4CD": "Amazon",
    "44654B": "Amazon", "48C19E": "Amazon", "50F5DA": "Amazon",
    "68371B": "Amazon", "6849BF": "Amazon", "6CEE91": "Amazon",
    "74C246": "Amazon", "78E103": "Amazon", "7CB3E8": "Amazon",
    "8009E8": "Amazon", "84D6D0": "Amazon", "8871E5": "Amazon",
    "98FEDB": "Amazon", "A002DC": "Amazon", "A43A96": "Amazon",
    "B47C9C": "Amazon", "B87CED": "Amazon", "D8CB8A": "Amazon",
    "D89720": "Amazon", "ECDEF1": "Amazon", "F0D2F1": "Amazon",
    "F4A169": "Amazon", "FCE998": "Amazon",

    # ── Xiaomi ─────────────────────────────────────────────────
    "0C1DAF": "Xiaomi", "1456CB": "Xiaomi", "1477AF": "Xiaomi",
    "18FD74": "Xiaomi", "20CF30": "Xiaomi", "286C07": "Xiaomi",
    "28E31F": "Xiaomi", "2C4412": "Xiaomi", "3408E0": "Xiaomi",
    "34CE00": "Xiaomi", "38A4ED": "Xiaomi", "3C8337": "Xiaomi",
    "406089": "Xiaomi", "50648A": "Xiaomi", "50EC50": "Xiaomi",
    "58443B": "Xiaomi", "5C0272": "Xiaomi", "5CC353": "Xiaomi",
    "60AB14": "Xiaomi", "64B473": "Xiaomi", "6892A5": "Xiaomi",
    "6C5AB0": "Xiaomi", "74184E": "Xiaomi", "780F77": "Xiaomi",
    "7CC3A1": "Xiaomi", "8CCDE8": "Xiaomi", "98FAE3": "Xiaomi",
    "9C99A0": "Xiaomi", "A4B1E9": "Xiaomi", "AC77B4": "Xiaomi",
    "B0E235": "Xiaomi", "C40BCB": "Xiaomi", "C46AB7": "Xiaomi",
    "C4A7A9": "Xiaomi", "D4EE07": "Xiaomi", "F0B429": "Xiaomi",
    "F48B32": "Xiaomi", "FC64BA": "Xiaomi",

    # ── Huawei ─────────────────────────────────────────────────
    "001882": "Huawei", "0019CF": "Huawei", "001E10": "Huawei",
    "00259E": "Huawei", "0046E3": "Huawei", "00504C": "Huawei",
    "085D51": "Huawei", "0C7A15": "Huawei", "101B54": "Huawei",
    "104B46": "Huawei", "107B44": "Huawei", "147A8D": "Huawei",
    "18A9E7": "Huawei", "1C2EB9": "Huawei", "1C676F": "Huawei",
    "20F17C": "Huawei", "240AC4": "Huawei", "285FDB": "Huawei",
    "28BFC1": "Huawei", "2C9D1E": "Huawei", "3032CC": "Huawei",
    "34BB26": "Huawei", "3444E8": "Huawei", "38D82F": "Huawei",
    "3CD7AB": "Huawei", "4033C0": "Huawei", "4440B1": "Huawei",
    "44A51E": "Huawei", "4C5499": "Huawei", "4C54A5": "Huawei",
    "4C8869": "Huawei", "5039AA": "Huawei", "505014": "Huawei",
    "5070AA": "Huawei", "50A87A": "Huawei", "5CA802": "Huawei",
    "5CBB35": "Huawei", "5CF96A": "Huawei", "60DE44": "Huawei",
    "64328A": "Huawei", "6499C0": "Huawei", "6C8D37": "Huawei",
    "70723F": "Huawei", "7072CF": "Huawei", "70849F": "Huawei",
    "74882A": "Huawei", "749DC2": "Huawei", "78D752": "Huawei",
    "7CAC3E": "Huawei", "8030E0": "Huawei", "8425DB": "Huawei",
    "849FB5": "Huawei", "8C21DA": "Huawei", "8CC8CD": "Huawei",
    "904E2B": "Huawei", "986D35": "Huawei", "9C7DA3": "Huawei",
    "9CB286": "Huawei", "A00800": "Huawei", "A4CAA1": "Huawei",
    "A8BBF3": "Huawei", "AC853D": "Huawei", "AC9201": "Huawei",
    "B05B67": "Huawei", "B468A8": "Huawei", "B4430D": "Huawei",
    "B4CD27": "Huawei", "B4FDA3": "Huawei", "B834D7": "Huawei",
    "B875F3": "Huawei", "BC1E85": "Huawei", "BC6D2A": "Huawei",
    "C00E5E": "Huawei", "C4072F": "Huawei", "C4F042": "Huawei",
    "C8514E": "Huawei", "D405AA": "Huawei", "D4E1B0": "Huawei",
    "D882A5": "Huawei", "DCC64F": "Huawei", "E0247F": "Huawei",
    "E0287A": "Huawei", "E4B3AF": "Huawei", "E84D7E": "Huawei",
    "E8EEA7": "Huawei", "EC233D": "Huawei", "F01373": "Huawei",
    "F0D5BF": "Huawei", "F46059": "Huawei", "F4538E": "Huawei",
    "F8235F": "Huawei", "F8641B": "Huawei", "FC4A73": "Huawei",

    # ── MikroTik ───────────────────────────────────────────────
    "000C42": "MikroTik", "18FD74": "MikroTik", "2C15D2": "MikroTik",
    "48A97A": "MikroTik", "4C5E0C": "MikroTik", "54B80A": "MikroTik",
    "64D154": "MikroTik", "6C3B6B": "MikroTik", "74B57E": "MikroTik",
    "788A20": "MikroTik", "7CB24F": "MikroTik", "8C886D": "MikroTik",
    "8CE7AE": "MikroTik", "B863BC": "MikroTik", "B88BA9": "MikroTik",
    "C4AD34": "MikroTik", "C4CE4F": "MikroTik", "CC2DE0": "MikroTik",
    "DC2C6E": "MikroTik", "E48D8C": "MikroTik", "E4BA3A": "MikroTik",

    # ── Cisco ──────────────────────────────────────────────────
    "000142": "Cisco", "00014A": "Cisco", "00015F": "Cisco",
    "00017E": "Cisco", "00024A": "Cisco", "000284": "Cisco",
    "0002FC": "Cisco", "000340": "Cisco", "0003A0": "Cisco",
    "0004C0": "Cisco", "0004DD": "Cisco", "00050F": "Cisco",
    "000513": "Cisco", "000530": "Cisco", "000541": "Cisco",
    "000563": "Cisco", "000574": "Cisco", "0005DC": "Cisco",
    "000609": "Cisco", "00063B": "Cisco", "00070D": "Cisco",
    "000740": "Cisco", "000749": "Cisco", "000763": "Cisco",
    "0007B3": "Cisco", "0007EC": "Cisco", "000802": "Cisco",
    "000854": "Cisco", "000876": "Cisco", "0008A3": "Cisco",
    "0008E2": "Cisco", "000939": "Cisco", "00095B": "Cisco",
    "000986": "Cisco", "0009B7": "Cisco", "000A41": "Cisco",
    "000A8A": "Cisco", "000B45": "Cisco", "000B85": "Cisco",
    "000BBE": "Cisco", "000BFD": "Cisco", "000C30": "Cisco",
    "000C41": "Cisco", "000C85": "Cisco", "000D28": "Cisco",
    "000D65": "Cisco", "000D88": "Cisco", "000DBC": "Cisco",
    "000DC9": "Cisco", "000E08": "Cisco", "000E38": "Cisco",
    "000E83": "Cisco", "000EBE": "Cisco", "000EF6": "Cisco",
    "000F05": "Cisco", "000F23": "Cisco", "000F66": "Cisco",
    "000FAA": "Cisco", "0CFC7E": "Cisco", "1C1D86": "Cisco",
    "2C3124": "Cisco", "3C0854": "Cisco", "40F4EC": "Cisco",
    "58F39C": "Cisco", "5C5015": "Cisco", "6CB2AE": "Cisco",
    "6CDDBC": "Cisco", "70CA9B": "Cisco", "74868A": "Cisco",
    "84B2F2": "Cisco", "8839EF": "Cisco", "9880BB": "Cisco",
    "A4936F": "Cisco", "ACF2C5": "Cisco", "B04DBD": "Cisco",
    "C0264D": "Cisco", "C8F9F9": "Cisco", "D0574C": "Cisco",
    "D4A0BA": "Cisco", "D4D7C7": "Cisco", "D867D9": "Cisco",
    "E8B748": "Cisco", "EC1D8B": "Cisco", "F01E34": "Cisco",
    "F04BF2": "Cisco", "F8B156": "Cisco",

    # ── TP-Link ────────────────────────────────────────────────
    "000AEB": "TP-Link", "001018": "TP-Link", "0014D1": "TP-Link",
    "001E58": "TP-Link", "002191": "TP-Link", "005079": "TP-Link",
    "04ABD1": "TP-Link", "086638": "TP-Link", "08BEF8": "TP-Link",
    "10FEA8": "TP-Link", "1062EB": "TP-Link", "14CF92": "TP-Link",
    "14EBB6": "TP-Link", "18A6F7": "TP-Link", "1C3BF3": "TP-Link",
    "1C7EE5": "TP-Link", "24E9B3": "TP-Link", "305A3A": "TP-Link",
    "30DE4B": "TP-Link", "347587": "TP-Link", "34EA34": "TP-Link",
    "38D547": "TP-Link", "3C52A1": "TP-Link", "40A5EF": "TP-Link",
    "40ED98": "TP-Link", "485EFE": "TP-Link", "4CE676": "TP-Link",
    "50091B": "TP-Link", "50C7BF": "TP-Link", "50FA84": "TP-Link",
    "548445": "TP-Link", "54AFF7": "TP-Link", "5C89B5": "TP-Link",
    "60A4B7": "TP-Link", "60E327": "TP-Link", "6466B3": "TP-Link",
    "6C5D5F": "TP-Link", "6C72E7": "TP-Link", "6CEAD3": "TP-Link",
    "6CF049": "TP-Link", "74EA3A": "TP-Link", "7874E1": "TP-Link",
    "7C3912": "TP-Link", "7C8BCA": "TP-Link", "7C95F3": "TP-Link",
    "80EA96": "TP-Link", "80F6E1": "TP-Link", "84165F": "TP-Link",
    "8419A6": "TP-Link", "84A423": "TP-Link", "88C3E3": "TP-Link",
    "8C4DDB": "TP-Link", "8C8D28": "TP-Link", "9003B7": "TP-Link",
    "9054E4": "TP-Link", "98DA74": "TP-Link", "9C3A9A": "TP-Link",
    "A0004C": "TP-Link", "A02195": "TP-Link", "A0F3C1": "TP-Link",
    "ACCF85": "TP-Link", "B0487A": "TP-Link", "B4B024": "TP-Link",
    "B4E9F6": "TP-Link", "B874CB": "TP-Link", "C006C3": "TP-Link",
    "C03F0E": "TP-Link", "C4A81D": "TP-Link", "C4E984": "TP-Link",
    "CC32E5": "TP-Link", "D461DA": "TP-Link", "D46AA8": "TP-Link",
    "D4EE43": "TP-Link", "D8EB97": "TP-Link", "DC0774": "TP-Link",
    "DC4400": "TP-Link", "DC97C6": "TP-Link", "DC9F12": "TP-Link",
    "E0D0E8": "TP-Link", "E83935": "TP-Link", "EC086B": "TP-Link",
    "F0A731": "TP-Link", "F4EC38": "TP-Link", "F8D111": "TP-Link",
    "FCA47B": "TP-Link",

    # ── Netgear ────────────────────────────────────────────────
    "0014BF": "Netgear", "001E2A": "Netgear", "001F33": "Netgear",
    "002045": "Netgear", "00223F": "Netgear", "002369": "Netgear",
    "004F49": "Netgear", "009063": "Netgear", "00A040": "Netgear",
    "04A222": "Netgear", "08028E": "Netgear", "0CBEE1": "Netgear",
    "100C6B": "Netgear", "107457": "Netgear", "18DBF2": "Netgear",
    "20E52A": "Netgear", "28C68E": "Netgear", "2C3033": "Netgear",
    "2C4012": "Netgear", "30469A": "Netgear", "3C3786": "Netgear",
    "3C8CF8": "Netgear", "44944A": "Netgear", "4C60DE": "Netgear",
    "4CEFCA": "Netgear", "5C4CA9": "Netgear", "60375E": "Netgear",
    "60E401": "Netgear", "6CB0CE": "Netgear", "743458": "Netgear",
    "7C2664": "Netgear", "80372F": "Netgear", "84189F": "Netgear",
    "849D8B": "Netgear", "88C9D0": "Netgear", "8C3BAD": "Netgear",
    "9C2A83": "Netgear", "9C3426": "Netgear", "A040A0": "Netgear",
    "A40C66": "Netgear", "A42BB0": "Netgear", "A4BEEF": "Netgear",
    "B003EE": "Netgear", "B0485A": "Netgear", "B0BF77": "Netgear",
    "C04A00": "Netgear", "C4B8B4": "Netgear", "C83A35": "Netgear",
    "CC9F7A": "Netgear", "D0674F": "Netgear", "D07AB5": "Netgear",
    "D4850D": "Netgear", "D4CA6D": "Netgear", "D83060": "Netgear",
    "DCA4CA": "Netgear", "E091F5": "Netgear", "E4F4C6": "Netgear",
    "E81DC9": "Netgear", "F08CBE": "Netgear", "F831A2": "Netgear",

    # ── Ubiquiti ───────────────────────────────────────────────
    "002722": "Ubiquiti", "04187A": "Ubiquiti", "0418D6": "Ubiquiti",
    "0C8112": "Ubiquiti", "18E829": "Ubiquiti", "241FE0": "Ubiquiti",
    "2AB360": "Ubiquiti", "3417EB": "Ubiquiti", "44D9E7": "Ubiquiti",
    "4AF1E8": "Ubiquiti", "5444B2": "Ubiquiti", "687272": "Ubiquiti",
    "6CFDB9": "Ubiquiti", "7C2C67": "Ubiquiti", "7CF586": "Ubiquiti",
    "8027A2": "Ubiquiti", "802AA8": "Ubiquiti", "9C16F0": "Ubiquiti",
    "B4FBE4": "Ubiquiti", "DCCC0A": "Ubiquiti", "E063DA": "Ubiquiti",
    "E4956E": "Ubiquiti", "F4E2C6": "Ubiquiti", "FC1375": "Ubiquiti",

    # ── ASUS ───────────────────────────────────────────────────
    "001E8C": "ASUS", "001FC6": "ASUS", "00226B": "ASUS",
    "002618": "ASUS", "049219": "ASUS", "10BF48": "ASUS",
    "107B44": "ASUS", "10C37B": "ASUS", "14DAE9": "ASUS",
    "18F1D8": "ASUS", "1C872C": "ASUS", "1CB72C": "ASUS",
    "2C9D1E": "ASUS", "2C4D54": "ASUS", "2C59E5": "ASUS",
    "30B49E": "ASUS", "404A03": "ASUS", "40167E": "ASUS",
    "48EE0C": "ASUS", "4CE170": "ASUS", "54A050": "ASUS",
    "54BEF7": "ASUS", "5C514F": "ASUS", "60A44C": "ASUS",
    "686B2B": "ASUS", "6C19C0": "ASUS", "70E585": "ASUS",
    "78242D": "ASUS", "788CB5": "ASUS", "7C10C9": "ASUS",
    "90E6BA": "ASUS", "9C5C8E": "ASUS", "A43820": "ASUS",
    "A8DFE1": "ASUS", "AC9E17": "ASUS", "B022AB": "ASUS",
    "B066D9": "ASUS", "B4A4E3": "ASUS", "B8AE67": "ASUS",
    "BC2B83": "ASUS", "C8D37B": "ASUS", "D017C2": "ASUS",
    "D850E6": "ASUS", "DCFE18": "ASUS", "E0CB1D": "ASUS",
    "E03F49": "ASUS", "E84EE1": "ASUS", "EC088B": "ASUS",
    "F04DA2": "ASUS", "F46BEF": "ASUS", "F832E4": "ASUS",

    # ── Hikvision (camaras IP) ─────────────────────────────────
    "286ED4": "Hikvision", "3CF20B": "Hikvision", "44194B": "Hikvision",
    "5004B0": "Hikvision", "5044BB": "Hikvision", "68C09A": "Hikvision",
    "7C1CF1": "Hikvision", "84C9B2": "Hikvision", "B4A3B5": "Hikvision",
    "C07392": "Hikvision", "D0D3E0": "Hikvision", "E85AB6": "Hikvision",
    "EC44A0": "Hikvision", "BCAD28": "Hikvision",

    # ── Dahua (camaras IP) ─────────────────────────────────────
    "10109F": "Dahua", "14119F": "Dahua", "18C914": "Dahua",
    "1C702D": "Dahua", "34E1D0": "Dahua", "3CE5A6": "Dahua",
    "54A7B3": "Dahua", "7008E1": "Dahua", "90C792": "Dahua",
    "90D385": "Dahua", "9C2F9D": "Dahua", "A4B62E": "Dahua",
    "BCC690": "Dahua",

    # ── Axis Communications (camaras IP) ───────────────────────
    "00408C": "Axis", "ACCC8E": "Axis", "B8A44F": "Axis",

    # ── Reolink ────────────────────────────────────────────────
    "EC71DB": "Reolink", "20189A": "Reolink",

    # ── Amcrest / Foscam ───────────────────────────────────────
    "9C8ECD": "Amcrest", "5C0A5B": "Amcrest", "C8D083": "Foscam",

    # ── LG Electronics ────────────────────────────────────────
    "001C62": "LG", "001E75": "LG", "002483": "LG",
    "0026E2": "LG", "00E091": "LG", "100B83": "LG",
    "1025B9": "LG", "1C39F3": "LG", "20A3A2": "LG",
    "24A9D8": "LG", "2C54CF": "LG", "300CF1": "LG",
    "30B5C2": "LG", "34B2BA": "LG", "38270E": "LG",
    "38F23E": "LG", "404745": "LG", "40F37A": "LG",
    "441EA1": "LG", "48599F": "LG", "4C2CF5": "LG",
    "507FC5": "LG", "5CD88E": "LG", "60BE5B": "LG",
    "64899A": "LG", "68CDAE": "LG", "6C5C14": "LG",
    "6CC8D1": "LG", "6CFEF2": "LG", "706CF5": "LG",
    "74F8DB": "LG", "78929C": "LG", "7C61B3": "LG",
    "8C3AE3": "LG", "900AD5": "LG", "94B0AB": "LG",
    "98D6C4": "LG", "9CDD60": "LG", "A04298": "LG",
    "A04ECA": "LG", "A41B62": "LG", "A84F25": "LG",
    "AC3574": "LG", "AC8AFA": "LG", "B09797": "LG",
    "B4E6A0": "LG", "C44B44": "LG", "CC2D8C": "LG",
    "D8858B": "LG", "E4928B": "LG", "E81563": "LG",
    "ECF505": "LG", "F0089D": "LG", "F01D2D": "LG",
    "F4EAB5": "LG", "F85EF7": "LG", "FC3468": "LG",

    # ── Sony ───────────────────────────────────────────────────
    "000166": "Sony", "001040": "Sony", "0013A9": "Sony",
    "001A80": "Sony", "001D0D": "Sony", "002394": "Sony",
    "0024BE": "Sony", "0024EF": "Sony", "00261E": "Sony",
    "0027A6": "Sony", "005030": "Sony", "047D7B": "Sony",
    "28384E": "Sony", "2C3A3E": "Sony", "3440B5": "Sony",
    "38EC0B": "Sony", "5CC316": "Sony", "680716": "Sony",
    "6CE0B3": "Sony", "70C1B5": "Sony", "74CAA5": "Sony",
    "80CF86": "Sony", "84C7CB": "Sony", "8C4509": "Sony",
    "9C7FBD": "Sony", "A0E453": "Sony", "AC9B0A": "Sony",
    "B400A4": "Sony", "B8F96B": "Sony", "C4E11B": "Sony",
    "C8348A": "Sony", "D0BE38": "Sony", "D83B41": "Sony",
    "E0AEB0": "Sony", "E4E750": "Sony", "EC2280": "Sony",
    "F02576": "Sony", "F03A93": "Sony", "F0BFD7": "Sony",
    "F8A9D0": "Sony",

    # ── Dell ───────────────────────────────────────────────────
    "001422": "Dell", "00142A": "Dell", "001564": "Dell",
    "0016F0": "Dell", "001A4B": "Dell", "001BFC": "Dell",
    "001D09": "Dell", "001ECA": "Dell", "00234E": "Dell",
    "002481": "Dell", "002564": "Dell", "00274D": "Dell",
    "4CCC6A": "Dell", "5C26CA": "Dell", "5CB901": "Dell",
    "64007B": "Dell", "689408": "Dell", "74867A": "Dell",
    "78452C": "Dell", "848D2B": "Dell", "8CCEA4": "Dell",
    "90B11C": "Dell", "985FD3": "Dell", "A0DCBC": "Dell",
    "B083FE": "Dell", "B097CA": "Dell", "B8AC6F": "Dell",
    "C81F66": "Dell", "C8D9D2": "Dell", "D067E5": "Dell",
    "D4AE52": "Dell", "D4BE29": "Dell", "D89EF3": "Dell",
    "E026CB": "Dell", "F48E38": "Dell", "F8BC12": "Dell",

    # ── HP ─────────────────────────────────────────────────────
    "001560": "HP", "001B78": "HP", "001CBF": "HP",
    "001E0B": "HP", "002500": "HP", "002642": "HP",
    "002735": "HP", "1C8B21": "HP", "38EAA7": "HP",
    "3C4A92": "HP", "3C7754": "HP", "3C98B4": "HP",
    "408661": "HP", "40B034": "HP", "40E6A5": "HP",
    "487221": "HP", "48A484": "HP", "4C1272": "HP",
    "4CC15F": "HP", "50DAD9": "HP", "543B39": "HP",
    "54551A": "HP", "54E8D2": "HP", "58A85C": "HP",
    "5CFF35": "HP", "609741": "HP", "60EB69": "HP",
    "7069B9": "HP", "7CB72C": "HP", "80CE62": "HP",
    "84348B": "HP", "843DC6": "HP", "84FDCC": "HP",
    "88AE1D": "HP", "90059C": "HP", "900635": "HP",
    "94571A": "HP", "9CB6D0": "HP", "A0B3CC": "HP",
    "A09FDF": "HP", "A4BA76": "HP", "A8B1D4": "HP",
    "B49A7E": "HP", "B4DDAE": "HP", "B80F6D": "HP",
    "B87547": "HP", "C4346B": "HP", "C43DC7": "HP",
    "C48508": "HP", "C8B5AD": "HP", "CCAB8D": "HP",
    "D469A5": "HP", "D85D4C": "HP", "D8F2CA": "HP",
    "E0079D": "HP", "E42690": "HP", "EC3A05": "HP",
    "EC8DCE": "HP", "F01F74": "HP", "FCECDA": "HP",

    # ── Lenovo ─────────────────────────────────────────────────
    "001D72": "Lenovo", "001FA0": "Lenovo", "0021CC": "Lenovo",
    "00231D": "Lenovo", "002404": "Lenovo", "0024D7": "Lenovo",
    "002619": "Lenovo", "002655": "Lenovo", "00905E": "Lenovo",
    "04C2B6": "Lenovo", "0CD29C": "Lenovo", "103022": "Lenovo",
    "10AD77": "Lenovo", "1468D4": "Lenovo", "20C1D1": "Lenovo",
    "20DBA7": "Lenovo", "248BFE": "Lenovo", "28D244": "Lenovo",
    "38B1DB": "Lenovo", "3C6A9D": "Lenovo", "403C8D": "Lenovo",
    "4059DC": "Lenovo", "44A842": "Lenovo", "485B39": "Lenovo",
    "48551E": "Lenovo", "4CAC0A": "Lenovo", "5079BA": "Lenovo",
    "54EEB8": "Lenovo", "5CF6DC": "Lenovo", "60A24C": "Lenovo",
    "6034AD": "Lenovo", "64724E": "Lenovo", "680D84": "Lenovo",
    "685522": "Lenovo", "6CF049": "Lenovo", "70721C": "Lenovo",
    "745EA5": "Lenovo", "7846B7": "Lenovo", "80FA5B": "Lenovo",
    "84372B": "Lenovo", "8C9B0B": "Lenovo", "9CEBDF": "Lenovo",
    "A80C0D": "Lenovo", "A85BFF": "Lenovo", "AC9EC9": "Lenovo",
    "B0706E": "Lenovo", "B42253": "Lenovo", "BCEE7B": "Lenovo",
    "C076FA": "Lenovo", "C8B389": "Lenovo", "CCF9E8": "Lenovo",
    "D04B78": "Lenovo", "DC7143": "Lenovo", "E0DA70": "Lenovo",
    "EC0193": "Lenovo", "F02F74": "Lenovo", "F40E11": "Lenovo",
    "F4A733": "Lenovo", "F8A963": "Lenovo", "FCF8AE": "Lenovo",

    # ── Raspberry Pi Foundation ────────────────────────────────
    "B827EB": "Raspberry Pi", "DCA632": "Raspberry Pi",
    "E45F01": "Raspberry Pi", "2CCF67": "Raspberry Pi",

    # ── Intel (adaptadores WiFi / Ethernet) ───────────────────
    "001E67": "Intel", "0021D8": "Intel", "0022FA": "Intel",
    "00236E": "Intel", "0026C7": "Intel", "4C7FC1": "Intel",
    "6C2934": "Intel", "74E5F9": "Intel", "78F5FD": "Intel",
    "8C700E": "Intel", "A0A8CD": "Intel", "A4C3F0": "Intel",
    "B4B676": "Intel", "D40CF9": "Intel", "D85DFB": "Intel",
    "E4E79A": "Intel", "E8D8D1": "Intel",

    # ── Philips Hue / Signify ──────────────────────────────────
    "001788": "Philips Hue", "0017E5": "Philips Hue",
    "EC0BAE": "Philips Hue",

    # ── Nintendo ───────────────────────────────────────────────
    "000F91": "Nintendo", "001F32": "Nintendo", "002309": "Nintendo",
    "00175C": "Nintendo", "0019FD": "Nintendo", "009BF0": "Nintendo",
    "040514": "Nintendo", "0827DC": "Nintendo", "1C11EB": "Nintendo",
    "203AB1": "Nintendo", "2C10C1": "Nintendo", "34AF2C": "Nintendo",
    "48A5E7": "Nintendo", "5C521E": "Nintendo", "6078E0": "Nintendo",
    "64B5C6": "Nintendo", "A438CC": "Nintendo", "A4C0E1": "Nintendo",
    "E00C7F": "Nintendo",

    # ── Sony PlayStation ───────────────────────────────────────
    "001315": "PlayStation", "0019C5": "PlayStation",
    "001FA7": "PlayStation", "28FDA1": "PlayStation",
    "38D8DD": "PlayStation", "709E29": "PlayStation",
    "70A242": "PlayStation", "A8E3EE": "PlayStation",
    "BC60A7": "PlayStation", "F8461C": "PlayStation",

    # ── Microsoft / Xbox ───────────────────────────────────────
    "00125A": "Microsoft", "00137A": "Microsoft",
    "0015E9": "Microsoft", "0017FA": "Microsoft",
    "001DD8": "Microsoft", "001F16": "Microsoft",
    "002269": "Microsoft", "00267B": "Microsoft",
    "0050F2": "Microsoft", "28DCAD": "Microsoft",
    "28DCCE": "Microsoft", "3C83A2": "Microsoft",
    "485073": "Microsoft", "603299": "Microsoft",
    "686E92": "Microsoft", "7C1E52": "Microsoft",
    "7CD30A": "Microsoft", "98B54E": "Microsoft",
    "A4502B": "Microsoft", "B85E28": "Microsoft",
    "C851EB": "Microsoft",

    # ── Canon ──────────────────────────────────────────────────
    "000168": "Canon", "00021A": "Canon", "00024E": "Canon",
    "000361": "Canon", "000367": "Canon", "000385": "Canon",
    "00038A": "Canon", "000D68": "Canon", "001158": "Canon",
    "0019D1": "Canon", "001BF8": "Canon", "001E8F": "Canon",
    "002204": "Canon", "00237E": "Canon", "002483": "Canon",
    "0024C4": "Canon", "00266E": "Canon", "04476C": "Canon",
    "08D4CE": "Canon", "143D67": "Canon", "186598": "Canon",
    "2C9EFC": "Canon", "30055C": "Canon", "3C43BB": "Canon",
    "5C0E8B": "Canon", "600026": "Canon", "64066A": "Canon",
    "6C0EB5": "Canon", "708869": "Canon", "7C1C68": "Canon",
    "80988A": "Canon", "8CB54B": "Canon", "900DF1": "Canon",
    "9026A3": "Canon", "9C49B0": "Canon", "A4EF15": "Canon",
    "A8F92F": "Canon", "B4222B": "Canon", "BC3400": "Canon",
    "C471BE": "Canon", "C88B80": "Canon", "CC7FEB": "Canon",

    # ── Epson ──────────────────────────────────────────────────
    "00004C": "Epson", "0002B3": "Epson", "00085B": "Epson",
    "000B8E": "Epson", "000D7E": "Epson", "000EA0": "Epson",
    "001523": "Epson", "001641": "Epson", "001B6B": "Epson",
    "001EDF": "Epson", "002134": "Epson", "002498": "Epson",
    "00268C": "Epson", "00C0E8": "Epson", "0CABEF": "Epson",
    "4C4E23": "Epson", "64EB8C": "Epson", "80921F": "Epson",
    "9CE3C4": "Epson",

    # ── Brother (impresoras) ───────────────────────────────────
    "000B98": "Brother", "000F08": "Brother", "0012D5": "Brother",
    "001D92": "Brother", "002676": "Brother", "00904C": "Brother",
    "009DA9": "Brother", "00A0D1": "Brother", "2C872B": "Brother",
    "30055C": "Brother",

    # ── VMware (VMs) ───────────────────────────────────────────
    "000C29": "VMware VM", "000569": "VMware VM",
    "001C14": "VMware VM", "005056": "VMware VM",

    # ── VirtualBox ─────────────────────────────────────────────
    "080027": "VirtualBox VM",

    # ── Hyper-V ────────────────────────────────────────────────
    "002248": "Hyper-V VM", "00155D": "Hyper-V VM",

    # ── Espressif (ESP8266 / ESP32 - IoT/domótica) ────────────
    "18FE34": "Espressif (IoT)", "24B2DE": "Espressif (IoT)",
    "2CF432": "Espressif (IoT)", "3C61F1": "Espressif (IoT)",
    "3CE90E": "Espressif (IoT)", "484CAB": "Espressif (IoT)",
    "4CEBD6": "Espressif (IoT)", "5CCF7F": "Espressif (IoT)",
    "60019F": "Espressif (IoT)", "70039F": "Espressif (IoT)",
    "7C87CE": "Espressif (IoT)", "84CCA8": "Espressif (IoT)",
    "84F3EB": "Espressif (IoT)", "8CAAB5": "Espressif (IoT)",
    "905F10": "Espressif (IoT)", "A020A6": "Espressif (IoT)",
    "A4CF12": "Espressif (IoT)", "A84040": "Espressif (IoT)",
    "AC67B2": "Espressif (IoT)", "B4E62D": "Espressif (IoT)",
    "BC DD C2": "Espressif (IoT)", "C44F33": "Espressif (IoT)",
    "CC50E3": "Espressif (IoT)", "D8BFC0": "Espressif (IoT)",
    "E89F6D": "Espressif (IoT)", "EC94CB": "Espressif (IoT)",
    "F0921C": "Espressif (IoT)", "F4CFA2": "Espressif (IoT)",

    # ── Shelly (IoT domótica) ──────────────────────────────────
    "30AEA4": "Shelly (IoT)", "34945B": "Shelly (IoT)",
    "84CCA8": "Shelly (IoT)",

    # ── Tuya / Smart Life (IoT) ────────────────────────────────
    "D8F15B": "Tuya (IoT)", "E82C6D": "Tuya (IoT)",

}
# fmt: on


def lookup(mac: str) -> str | None:
    """
    Retorna el fabricante para una dirección MAC, o None si no se encuentra.
    Acepta cualquier formato: 'AA:BB:CC:DD:EE:FF', 'AA-BB-CC-DD-EE-FF', 'AABBCCDDEEFF'.
    """
    if not mac:
        return None
    normalized = mac.upper().replace(":", "").replace("-", "").replace(".", "").replace(" ", "")
    if len(normalized) < 6:
        return None
    oui = normalized[:6]
    return _MANUF.get(oui) or _OUI.get(oui)
