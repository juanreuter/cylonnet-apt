"""Cliente de la API clásica de RouterOS (puerto 8728, o 8729 con TLS).

Sirve para los MikroTik con RouterOS 6, que no tienen REST. Se usa igual que RouterOsRestClient
(mismas rutas, mismos campos y mismos errores), así el resto de NetTopo no distingue entre los dos.
Protocolo: oraciones de palabras con largo variable; ver https://help.mikrotik.com/docs/display/ROS/API
"""

from __future__ import annotations

import hashlib
import socket
import ssl
from typing import Any

from .config import RouterOsConfig
from .routeros_rest import RouterOsRestClient, RouterOsRestError


class RouterOsApiError(RouterOsRestError):
    pass


def client_for(config: RouterOsConfig) -> RouterOsRestClient:
    """El cliente que corresponde al protocolo del equipo (REST en 7.1+, API clásica en v6)."""
    return RouterOsApiClient(config) if config.protocol == "api" else RouterOsRestClient(config)


def _largo(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    if n < 0x4000:
        return (n | 0x8000).to_bytes(2, "big")
    if n < 0x200000:
        return (n | 0xC00000).to_bytes(3, "big")
    if n < 0x10000000:
        return (n | 0xE0000000).to_bytes(4, "big")
    return b"\xf0" + n.to_bytes(4, "big")


class RouterOsApiClient(RouterOsRestClient):
    def __init__(self, config: RouterOsConfig) -> None:
        self.config = config
        self.port = config.api_port or (8729 if config.api_tls else 8728)
        self.base_url = f"api{'-ssl' if config.api_tls else ''}://{config.host}:{self.port}"
        self._socket: socket.socket | None = None

    # ── Conexión ──────────────────────────────────────────────────────────────
    def _conectar(self) -> None:
        try:
            crudo = socket.create_connection((self.config.host, self.port), timeout=self.config.timeout_seconds)
            if self.config.api_tls:
                contexto = ssl.create_default_context() if self.config.verify_tls else ssl._create_unverified_context()
                crudo = contexto.wrap_socket(crudo, server_hostname=self.config.host)
        except OSError as exc:
            raise RouterOsApiError(f"No se pudo conectar a la API de RouterOS en {self.base_url}: {exc}") from exc
        self._socket = crudo
        respuesta = self._hablar(["/login", f"=name={self.config.username}", f"=password={self.config.password}"],
                                 login=True)
        reto = next((r.get("ret") for tipo, r in respuesta if tipo == "!done" and r.get("ret")), None)
        if reto:  # RouterOS anterior a 6.43: login con desafío MD5
            md5 = hashlib.md5(b"\x00" + self.config.password.encode() + bytes.fromhex(reto)).hexdigest()
            self._hablar(["/login", f"=name={self.config.username}", f"=response=00{md5}"], login=True)

    def close(self) -> None:
        if self._socket is not None:
            try:
                self._socket.close()
            finally:
                self._socket = None

    def __del__(self) -> None:
        self.close()

    def _enviar(self, palabras: list[str]) -> None:
        datos = b"".join(_largo(len(p.encode())) + p.encode() for p in palabras) + b"\x00"
        self._socket.sendall(datos)

    def _leer(self, n: int) -> bytes:
        datos = b""
        while len(datos) < n:
            parte = self._socket.recv(n - len(datos))
            if not parte:
                raise RouterOsApiError(f"El equipo cerró la conexión de la API ({self.base_url}).")
            datos += parte
        return datos

    def _leer_palabra(self) -> str:
        b = self._leer(1)[0]
        if b < 0x80:
            n = b
        elif b < 0xC0:
            n = ((b & 0x3F) << 8) | self._leer(1)[0]
        elif b < 0xE0:
            n = ((b & 0x1F) << 16) | int.from_bytes(self._leer(2), "big")
        elif b < 0xF0:
            n = ((b & 0x0F) << 24) | int.from_bytes(self._leer(3), "big")
        else:
            n = int.from_bytes(self._leer(4), "big")
        return self._leer(n).decode("utf-8", errors="replace")

    def _hablar(self, palabras: list[str], login: bool = False) -> list[tuple[str, dict[str, str]]]:
        """Manda un comando y junta las respuestas hasta !done. Un !trap o !fatal es error."""
        if self._socket is None and not login:
            self._conectar()
        try:
            self._enviar(palabras)
            respuestas: list[tuple[str, dict[str, str]]] = []
            while True:
                oracion = []
                while (palabra := self._leer_palabra()) != "":
                    oracion.append(palabra)
                if not oracion:
                    continue
                tipo, atributos = oracion[0], {}
                for palabra in oracion[1:]:
                    if palabra.startswith("="):
                        clave, _, valor = palabra[1:].partition("=")
                        atributos[clave] = valor
                respuestas.append((tipo, atributos))
                if tipo == "!fatal":
                    self.close()
                    raise RouterOsApiError(f"RouterOS API ({self.base_url}): {atributos or oracion}")
                if tipo == "!done":
                    break
        except OSError as exc:
            self.close()
            raise RouterOsApiError(f"Falló la comunicación con la API de RouterOS en {self.base_url}: {exc}") from exc
        errores = [r for tipo, r in respuestas if tipo == "!trap"]
        if errores:
            mensaje = errores[0].get("message", "error")
            if login:
                self.close()
                raise RouterOsApiError(f"RouterOS API devolvio HTTP 401 (login rechazado) en {self.base_url}: {mensaje}")
            codigo = 403 if "permission" in mensaje.lower() else 400
            raise RouterOsApiError(f"RouterOS API devolvio HTTP {codigo} para {palabras[0]}: {mensaje}")
        return respuestas

    # ── Mismas operaciones que el cliente REST ────────────────────────────────
    @staticmethod
    def _separar(path: str) -> tuple[str, str | None]:
        """'ip/firewall/filter/*7' → ('/ip/firewall/filter', '*7')."""
        menu, _, ultimo = path.strip("/").rpartition("/")
        if ultimo.startswith("*") and menu:
            return "/" + menu, ultimo
        return "/" + path.strip("/"), None

    def get(self, path: str, proplist: list[str] | None = None, filters: dict[str, str] | None = None) -> Any:
        menu, id_ = self._separar(path)
        palabras = [f"{menu}/print"]
        if proplist:
            palabras.append("=.proplist=" + ",".join(proplist))
        for campo, valor in (filters or {}).items():
            palabras.append(f"?{campo}={valor}")
        if id_:
            palabras.append(f"?.id={id_}")
        registros = [r for tipo, r in self._hablar(palabras) if tipo == "!re"]
        if id_:
            if not registros:
                raise RouterOsApiError(f"RouterOS API devolvio HTTP 404 para {path}: no existe el registro")
            return registros[0]
        return registros

    def put(self, path: str, body: dict[str, Any]) -> Any:
        menu, _ = self._separar(path)
        respuestas = self._hablar([f"{menu}/add", *(f"={k}={v}" for k, v in body.items())])
        nuevo = next((r.get("ret") for tipo, r in respuestas if tipo == "!done" and r.get("ret")), None)
        return self.get(f"{path.strip('/')}/{nuevo}") if nuevo else {}

    def patch(self, path: str, body: dict[str, Any]) -> Any:
        menu, id_ = self._separar(path)
        self._hablar([f"{menu}/set", f"=.id={id_}", *(f"={k}={v}" for k, v in body.items())])
        return self.get(path)

    def delete(self, path: str) -> Any:
        menu, id_ = self._separar(path)
        self._hablar([f"{menu}/remove", f"=.id={id_}"])
        return None
