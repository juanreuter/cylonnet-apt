from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .site_models import CollectionResult, SiteConfig
from .sources import SOURCE_ADAPTERS


def _dedupe_by_key(items: list[dict[str, Any]], key_fields: list[str]) -> list[dict[str, Any]]:
    seen: set[tuple[Any, ...]] = set()
    output: list[dict[str, Any]] = []
    for item in items:
        key = tuple(item.get(field) for field in key_fields)
        if key in seen:
            continue
        seen.add(key)
        output.append(item)
    return output


def _dedupe_devices(devices: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Deduplica por id Y por managementIp. Cuando dos entradas tienen la misma
    IP pero distinto id (ej: RouterOS vs NetFlow), se fusionan prefiriendo los
    campos con más información (no None, no vacío, no 'Unknown')."""
    by_id: dict[str, dict[str, Any]] = {}
    ip_to_id: dict[str, str] = {}

    for device in devices:
        dev_id = device.get("id") or ""
        dev_ip = device.get("managementIp") or ""

        canonical_id = ip_to_id.get(dev_ip) if dev_ip else None

        if canonical_id:
            # Ya existe una entrada con esta IP — fusionar
            existing = by_id[canonical_id]
            merged = {**device}
            for k, v in existing.items():
                if v not in (None, "", "Unknown", "Desconocido"):
                    merged[k] = v
            by_id[canonical_id] = merged
        elif dev_id and dev_id not in by_id:
            by_id[dev_id] = device
            if dev_ip:
                ip_to_id[dev_ip] = dev_id
        elif dev_id in by_id:
            existing = by_id[dev_id]
            merged = {**device}
            for k, v in existing.items():
                if v not in (None, "", "Unknown", "Desconocido"):
                    merged[k] = v
            by_id[dev_id] = merged

    return list(by_id.values())


def merge_snapshots(site_name: str, results: list[CollectionResult]) -> dict[str, Any]:
    snapshots = [result.snapshot for result in results if result.snapshot]
    warnings = [warning for result in results for warning in result.warnings]

    if not snapshots:
        return {
            "metadata": {
                "name": site_name,
                "generatedAt": datetime.now(timezone.utc).isoformat(),
                "source": "site-orchestrator",
                "notes": "No se recolectaron snapshots validos.",
                "warnings": warnings,
            },
            "rootDeviceId": None,
            "devices": [],
            "l2Neighbors": [],
            "hosts": [],
            "macTable": [],
        }

    primary = snapshots[0]
    devices: list[dict[str, Any]] = []
    l2_neighbors: list[dict[str, Any]] = []
    hosts: list[dict[str, Any]] = []
    mac_table: list[dict[str, Any]] = []

    for snapshot in snapshots:
        devices.extend(snapshot.get("devices", []))
        l2_neighbors.extend(snapshot.get("l2Neighbors", []))
        hosts.extend(snapshot.get("hosts", []))
        mac_table.extend(snapshot.get("macTable", []))

    merged = {
        "metadata": {
            "name": site_name,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "source": "site-orchestrator",
            "notes": "Snapshot unificado a partir de multiples fuentes.",
            "sourcesUsed": [
                {
                    "type": result.source_type,
                    "name": result.source_name,
                    "hasSnapshot": bool(result.snapshot),
                }
                for result in results
            ],
            "warnings": warnings,
        },
        "rootDeviceId": primary.get("rootDeviceId"),
        "devices": _dedupe_devices(devices),
        "l2Neighbors": _dedupe_by_key(
            l2_neighbors,
            [
                "localDeviceId",
                "localInterfaceName",
                "remoteDeviceId",
                "remoteInterfaceName",
            ],
        ),
        "hosts": _dedupe_by_key(hosts, ["id"]),
        "macTable": _dedupe_by_key(mac_table, ["deviceId", "interfaceName", "vlanId", "macAddress"]),
    }
    return merged


def _gather_discovered_ips(snapshot: dict[str, Any]) -> list[str]:
    ips: list[str] = []
    for host in snapshot.get("hosts", []):
        ip = host.get("ip")
        if ip and not ip.startswith("169.254"):
            ips.append(ip)
    for device in snapshot.get("devices", []):
        ip = device.get("managementIp")
        if ip:
            ips.append(ip)
    return ips


def _known_hosts(site_config: SiteConfig) -> set[str]:
    hosts: set[str] = set()
    for source in site_config.sources:
        host = source.settings.get("host")
        if host:
            hosts.add(host)
        for target in source.settings.get("targets", []):
            hosts.add(target)
    return hosts


def collect_site(site_config: SiteConfig, workspace_root: Path) -> tuple[dict[str, Any], list[CollectionResult]]:
    results: list[CollectionResult] = []

    for source in site_config.sources:
        if not source.enabled:
            continue

        adapter_cls = SOURCE_ADAPTERS.get(source.type)
        if adapter_cls is None:
            results.append(
                CollectionResult(
                    source_type=source.type,
                    source_name=source.name,
                    warnings=[f"No existe adaptador registrado para source type '{source.type}'."],
                )
            )
            continue

        adapter = adapter_cls(site_name=site_config.site_name, source=source, workspace_root=workspace_root)
        results.append(adapter.collect())

    merged = merge_snapshots(site_config.site_name, results)

    if site_config.default_credentials:
        from .credential_prober import probe_hosts
        discovered_ips = _gather_discovered_ips(merged)
        known = _known_hosts(site_config)
        auto_sources = probe_hosts(discovered_ips, site_config.default_credentials, known)
        merged["metadata"]["autoDiscoveredSources"] = auto_sources

    return merged, results
