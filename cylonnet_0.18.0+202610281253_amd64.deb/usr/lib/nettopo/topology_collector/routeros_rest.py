from __future__ import annotations

from base64 import b64encode
import json
import ssl
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .config import RouterOsConfig


class RouterOsRestError(RuntimeError):
    pass


class RouterOsRestClient:
    def __init__(self, config: RouterOsConfig) -> None:
        self.config = config
        https = config.rest_https if config.rest_https is not None else config.rest_port != 80
        protocol = "https" if https else "http"
        port_part = "" if config.rest_port == (443 if https else 80) else f":{config.rest_port}"
        self.base_url = f"{protocol}://{config.host}{port_part}/rest"
        self.auth_header = self._build_auth_header(config.username, config.password)
        self.ssl_context = self._build_ssl_context(config.verify_tls)

    @staticmethod
    def _build_auth_header(username: str, password: str) -> str:
        token = b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
        return f"Basic {token}"

    @staticmethod
    def _build_ssl_context(verify_tls: bool) -> ssl.SSLContext:
        if verify_tls:
            return ssl.create_default_context()
        return ssl._create_unverified_context()

    def get(
        self,
        path: str,
        proplist: list[str] | None = None,
        filters: dict[str, str] | None = None,
    ) -> Any:
        params = dict(filters or {})
        if proplist:
            params[".proplist"] = ",".join(proplist)
        query = "?" + urlencode(params) if params else ""
        return self._request_json("GET", f"{self.base_url}/{path}{query}")

    # Escritura (las usa NetTopo solo después de que el usuario confirma el cambio)
    def put(self, path: str, body: dict[str, Any]) -> Any:
        """Agrega un registro (equivale a `add`). Devuelve el registro creado, con su .id."""
        return self._request_json("PUT", f"{self.base_url}/{path}", body)

    def patch(self, path: str, body: dict[str, Any]) -> Any:
        """Modifica un registro (equivale a `set`); path termina en el .id."""
        return self._request_json("PATCH", f"{self.base_url}/{path}", body)

    def delete(self, path: str) -> Any:
        """Borra un registro (equivale a `remove`); path termina en el .id."""
        return self._request_json("DELETE", f"{self.base_url}/{path}")

    def _request_json(self, method: str, url: str, body: dict[str, Any] | None = None) -> Any:
        headers = {
            "Authorization": self.auth_header,
            "Accept": "application/json",
        }
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = Request(
            url,
            data=data,
            method=method,
            headers=headers,
        )

        try:
            with urlopen(
                request,
                timeout=self.config.timeout_seconds,
                context=self.ssl_context,
            ) as response:
                charset = response.headers.get_content_charset() or "utf-8"
                raw = response.read().decode(charset)
                if not raw:
                    return None
                return json.loads(raw)
        except HTTPError as exc:
            details = exc.read().decode("utf-8", errors="replace")
            raise RouterOsRestError(
                f"RouterOS REST devolvio HTTP {exc.code} para {url}: {details}"
            ) from exc
        except URLError as exc:
            raise RouterOsRestError(
                f"No se pudo conectar a RouterOS REST en {url}: {exc.reason}"
            ) from exc

    def fetch_identity(self) -> dict[str, Any]:
        data = self.get("system/identity")
        if isinstance(data, list):
            return data[0] if data else {}
        return data or {}

    def fetch_resource(self) -> dict[str, Any]:
        data = self.get("system/resource")
        if isinstance(data, list):
            return data[0] if data else {}
        return data or {}

    def fetch_interfaces(self) -> list[dict[str, Any]]:
        return list(self.get("interface") or [])

    def fetch_ip_addresses(self) -> list[dict[str, Any]]:
        return list(self.get("ip/address") or [])

    def fetch_neighbors(self) -> list[dict[str, Any]]:
        return list(self.get("ip/neighbor") or [])

    def fetch_bridge_vlans(self) -> list[dict[str, Any]]:
        return list(self.get("interface/bridge/vlan") or [])

    def fetch_bridge_hosts(self) -> list[dict[str, Any]]:
        return list(self.get("interface/bridge/host") or [])

    def fetch_arp(self) -> list[dict[str, Any]]:
        return list(self.get("ip/arp") or [])
