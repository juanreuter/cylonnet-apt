from __future__ import annotations

import argparse
import json
from pathlib import Path

from .site_config import load_site_config
from .site_runner import collect_site


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Orquestador multi-fuente para descubrir topologia por sitio."
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Ruta al archivo JSON con las fuentes del sitio.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Ruta del snapshot JSON unificado a generar.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_path = Path(args.config)
    workspace_root = config_path.resolve().parent.parent
    site_config = load_site_config(config_path)
    snapshot, results = collect_site(site_config, workspace_root)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")

    print(f"Snapshot unificado generado en {output_path}")
    for result in results:
        print(
            f"- {result.source_name} [{result.source_type}] -> "
            f"{'snapshot' if result.snapshot else 'sin snapshot'}"
        )
        for warning in result.warnings:
            print(f"  warning: {warning}")
    return 0
