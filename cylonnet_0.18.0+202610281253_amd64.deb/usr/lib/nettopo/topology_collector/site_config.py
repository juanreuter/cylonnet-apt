from __future__ import annotations

import json
from pathlib import Path

from .site_models import SiteConfig, SourceConfig


def load_site_config(path: str | Path) -> SiteConfig:
    config_path = Path(path)
    payload = json.loads(config_path.read_text(encoding="utf-8"))

    sources = [
        SourceConfig(
            type=item["type"],
            name=item["name"],
            enabled=bool(item.get("enabled", True)),
            settings={key: value for key, value in item.items() if key not in {"type", "name", "enabled"}},
        )
        for item in payload.get("sources", [])
    ]

    return SiteConfig(
        site_name=payload["site_name"],
        sources=sources,
        default_credentials=payload.get("default_credentials", {}),
    )
