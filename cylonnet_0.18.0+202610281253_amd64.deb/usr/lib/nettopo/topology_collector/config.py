from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(slots=True)
class RouterOsConfig:
    site_name: str
    host: str
    username: str
    password: str
    verify_tls: bool = False
    timeout_seconds: int = 15
    vendor: str = ""
    model: str = ""
    snmp_community: str = ""
    snmp_port: int = 161
    rest_port: int = 443
    rest_https: bool | None = None  # None: HTTPS salvo en el puerto 80
    protocol: str = "rest"  # "rest" (RouterOS 7.1+) o "api" (API clásica 8728/8729, para RouterOS 6)
    api_port: int = 0  # 0: 8728, o 8729 con api_tls
    api_tls: bool = False


def load_config(path: str | Path) -> RouterOsConfig:
    config_path = Path(path)
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    return RouterOsConfig(
        site_name=payload["site_name"],
        host=payload["host"],
        username=payload["username"],
        password=payload["password"],
        verify_tls=bool(payload.get("verify_tls", False)),
        timeout_seconds=int(payload.get("timeout_seconds", 15)),
    )
