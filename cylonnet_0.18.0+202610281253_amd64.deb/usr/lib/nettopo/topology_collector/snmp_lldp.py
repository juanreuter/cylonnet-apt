from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Any

from .snmp_client import SimpleSnmpClient, SnmpCollectionError, SnmpTargetConfig, SnmpUnavailableError

# LLDP-MIB (IEEE 802.1AB) OIDs
_SYS_NAME_OID     = "1.3.6.1.2.1.1.5.0"
_SYS_DESCR_OID    = "1.3.6.1.2.1.1.1.0"
_LOC_PORT_ID      = "1.0.8802.1.1.2.1.3.7.1.3"   # lldpLocPortId by portNum
_REM_SYS_NAME     = "1.0.8802.1.1.2.1.4.1.1.9"   # lldpRemSysName
_REM_PORT_ID      = "1.0.8802.1.1.2.1.4.1.1.7"   # lldpRemPortId
_REM_PORT_DESC    = "1.0.8802.1.1.2.1.4.1.1.8"   # lldpRemPortDesc
_REM_SYS_DESC     = "1.0.8802.1.1.2.1.4.1.1.10"  # lldpRemSysDesc
_REM_MAN_ADDR_COL = "1.0.8802.1.1.2.1.4.2.1.3"   # lldpRemManAddrIfSubtype (index encodes the IP)


def _slugify(value: Any) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower())
    return text.strip("-") or "unknown"


def _oid_suffix(full_oid: str, prefix: str) -> str:
    # Strip leading dot first (snmpwalk -On returns ".1.0.8802..." with leading dot)
    return full_oid.lstrip(".").removeprefix(prefix.lstrip(".")).lstrip(".")


def _parse_rem_index(suffix: str) -> tuple[int, int, int] | None:
    """Extract (timeMark, localPortNum, remoteIndex) from lldpRemTable OID suffix."""
    parts = suffix.split(".")
    if len(parts) < 3:
        return None
    try:
        return int(parts[0]), int(parts[1]), int(parts[2])
    except ValueError:
        return None


def _parse_man_addr_ipv4(suffix: str) -> tuple[int, int, str | None]:
    """
    lldpRemManAddrTable index: timeMark.localPortNum.remoteIndex.addrSubtype.addrLen.addr...
    For IPv4: addrSubtype=1, addrLen=4, followed by 4 octets.
    Returns (localPortNum, remoteIndex, ipv4_string | None).
    """
    try:
        parts = [int(x) for x in suffix.split(".") if x]
    except ValueError:
        return 0, 0, None
    if len(parts) < 3:
        return 0, 0, None
    local_port = parts[1]
    rem_idx = parts[2]
    if len(parts) >= 9 and parts[3] == 1 and parts[4] == 4:
        return local_port, rem_idx, ".".join(str(x) for x in parts[5:9])
    return local_port, rem_idx, None


def _infer_vendor(sys_descr: str) -> str:
    desc = sys_descr.lower()
    if "mikrotik" in desc or "routeros" in desc:
        return "MikroTik"
    if "cisco" in desc:
        return "Cisco"
    if ("aruba" in desc or "procurve" in desc or "hewlett" in desc or "officeconnect" in desc
            or re.match(r"(hpe?|hp\s+j[0-9a-z]+)\b", desc) or re.search(r"\bhpe?\b", desc)):
        return "HP"
    if "tp-link" in desc or "tplink" in desc or "omada" in desc or "jetstream" in desc or re.search(r"\b(tl-|sg[0-9]{4})", desc):
        return "TP-Link"
    if "ubiquiti" in desc or "unifi" in desc or "edgeswitch" in desc or "edgeos" in desc:
        return "Ubiquiti"
    if "ruijie" in desc:
        return "Ruijie"
    if "juniper" in desc:
        return "Juniper"
    return "Unknown"


def fetch_lldp_snapshot(
    host: str,
    snmp_config: SnmpTargetConfig,
    site_name: str,
) -> tuple[dict[str, Any], list[str]]:
    """
    Query any SNMP-enabled device for its LLDP neighbor table.

    Returns:
      - snapshot dict compatible with the unified snapshot format
      - list of neighbor management IPs discovered (for recursive walking)
    """
    client = SimpleSnmpClient(snmp_config)
    root_device_id = f"device-{_slugify(host)}"

    try:
        sys_name = client.get_scalar(_SYS_NAME_OID) or host
        sys_descr = client.get_scalar(_SYS_DESCR_OID) or ""
    except SnmpCollectionError as exc:
        raise SnmpUnavailableError(f"SNMP no disponible en {host}: {exc}") from exc

    # Map localPortNum → interface name from lldpLocPortTable
    port_name_by_num: dict[int, str] = {}
    try:
        for oid, value in client.walk(_LOC_PORT_ID):
            suffix = _oid_suffix(oid, _LOC_PORT_ID).strip(".")
            parts = suffix.split(".")
            if parts and parts[-1].isdigit():
                port_name_by_num[int(parts[-1])] = str(value)
    except SnmpCollectionError:
        pass

    # Gather remote neighbor fields indexed by (localPortNum, remoteIndex)
    rem_records: dict[tuple[int, int], dict[str, Any]] = {}

    def get_rec(lp: int, ri: int) -> dict[str, Any]:
        key = (lp, ri)
        if key not in rem_records:
            rem_records[key] = {"localPort": lp, "remoteIndex": ri}
        return rem_records[key]

    for table_oid, field in [
        (_REM_SYS_NAME,  "sysName"),
        (_REM_PORT_ID,   "portId"),
        (_REM_PORT_DESC, "portDesc"),
        (_REM_SYS_DESC,  "sysDesc"),
    ]:
        try:
            for oid, value in client.walk(table_oid):
                idx = _parse_rem_index(_oid_suffix(oid, table_oid))
                if idx:
                    _, lp, ri = idx
                    get_rec(lp, ri)[field] = str(value)
        except SnmpCollectionError:
            pass

    # Extract management addresses (IPv4 only) from the address index encoding
    try:
        for oid, _ in client.walk(_REM_MAN_ADDR_COL):
            suffix = _oid_suffix(oid, _REM_MAN_ADDR_COL)
            lp, ri, ip = _parse_man_addr_ipv4(suffix)
            if ip:
                get_rec(lp, ri).setdefault("managementIp", ip)
    except SnmpCollectionError:
        pass

    # Build snapshot components
    devices: list[dict[str, Any]] = []
    l2_neighbors: list[dict[str, Any]] = []
    neighbor_ips: list[str] = []
    seen_ids: set[str] = set()

    for (lp, ri), rec in rem_records.items():
        name = rec.get("sysName") or rec.get("portId") or f"neighbor-{lp}-{ri}"
        mgmt_ip = rec.get("managementIp", "")
        remote_id = f"device-{_slugify(mgmt_ip)}" if mgmt_ip else f"neighbor-{_slugify(name)}-{lp}-{ri}"
        local_port = port_name_by_num.get(lp) or f"port{lp}"
        remote_port = rec.get("portDesc") or rec.get("portId") or "unknown"

        if remote_id not in seen_ids:
            seen_ids.add(remote_id)
            devices.append({
                "id": remote_id,
                "name": name,
                "kind": "neighbor",
                "vendor": _infer_vendor(rec.get("sysDesc", "")),
                "os": rec.get("sysDesc", "")[:120],
                "managementIp": mgmt_ip,
                "site": site_name,
                "interfaces": [
                    {"name": remote_port, "role": "uplink", "mode": "unknown", "allowedVlans": []}
                ],
            })

        l2_neighbors.append({
            "localDeviceId": root_device_id,
            "localInterfaceName": local_port,
            "remoteDeviceId": remote_id,
            "remoteInterfaceName": remote_port,
            "protocol": "lldp",
            "confidence": 0.85,
        })

        if mgmt_ip and mgmt_ip != host:
            neighbor_ips.append(mgmt_ip)

    root_device = {
        "id": root_device_id,
        "name": sys_name,
        "kind": "switch",
        "vendor": _infer_vendor(sys_descr),
        "os": sys_descr[:120],
        "managementIp": host,
        "site": site_name,
        "interfaces": [],
        "networks": [],
    }

    snapshot: dict[str, Any] = {
        "metadata": {
            "name": site_name,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "source": "snmp-lldp",
            "notes": f"SNMP LLDP discovery de {host}.",
            "warnings": [],
        },
        "rootDeviceId": root_device_id,
        "devices": [root_device, *devices],
        "l2Neighbors": l2_neighbors,
        "hosts": [],
        "macTable": [],
    }

    return snapshot, list(dict.fromkeys(neighbor_ips))  # dedup preserving order
