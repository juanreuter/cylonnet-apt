from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any

from .config import RouterOsConfig
from .routeros_api import client_for
from .routeros_rest import RouterOsRestError
from .snapshot_builder import build_snapshot
from .snmp_client import SnmpCollectionError, SnmpTargetConfig, SnmpUnavailableError
from .snmp_snapshot import collect_snmp_target_snapshot


def _slugify(value: Any) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower())
    return text.strip("-") or "unknown"


def _device_id_from_host(host: str) -> str:
    return f"device-{_slugify(host)}"


def _first_non_empty(record: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = record.get(key)
        if value not in (None, "", "unknown"):
            return value
    return None


def _is_mikrotik_neighbor(neighbor: dict[str, Any]) -> bool:
    values = [
        neighbor.get("platform"),
        neighbor.get("board"),
        neighbor.get("system-description"),
        neighbor.get("identity"),
        neighbor.get("version"),
    ]
    haystack = " ".join(str(value) for value in values if value).lower()
    return "mikrotik" in haystack or "routeros" in haystack


def _neighbor_protocol(neighbor: dict[str, Any], current: RouterOsConfig) -> str:
    """REST desde RouterOS 7.1; antes, la API clásica. Sin versión conocida, el mismo que el equipo actual."""
    match = re.search(r"(\d+)\.(\d+)", str(neighbor.get("version") or ""))
    if not match:
        return current.protocol
    return "rest" if (int(match.group(1)), int(match.group(2))) >= (7, 1) else "api"


def _collect_router_snapshot(config: RouterOsConfig) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    client = client_for(config)
    identity = client.fetch_identity()
    resource = client.fetch_resource()
    interfaces = client.fetch_interfaces()
    ip_addresses = client.fetch_ip_addresses()
    neighbors = client.fetch_neighbors()
    bridge_vlans = client.fetch_bridge_vlans()
    bridge_hosts = client.fetch_bridge_hosts()
    arp_entries = client.fetch_arp()

    snapshot = build_snapshot(
        config=config,
        identity=identity,
        resource=resource,
        interfaces=interfaces,
        ip_addresses=ip_addresses,
        neighbors=neighbors,
        bridge_vlans=bridge_vlans,
        bridge_hosts=bridge_hosts,
        arp_entries=arp_entries,
        root_device_id=_device_id_from_host(config.host),
    )
    return snapshot, neighbors


def _merge_devices(
    current: dict[str, Any] | None,
    candidate: dict[str, Any],
) -> dict[str, Any]:
    if current is None:
        return candidate

    merged = dict(current)
    candidate_kind = candidate.get("kind")
    current_kind = current.get("kind")

    if current_kind in (None, "", "neighbor") and candidate_kind not in (None, "", "neighbor"):
        merged["kind"] = candidate_kind

    for field in ("name", "vendor", "os", "managementIp", "site"):
        current_value = merged.get(field)
        candidate_value = candidate.get(field)
        if candidate_value and (not current_value or current_value in ("Unknown", "Discovered neighbor")):
            merged[field] = candidate_value

    interface_map: dict[str, dict[str, Any]] = {}
    for iface in current.get("interfaces", []):
        if iface.get("name"):
            interface_map[str(iface["name"])] = dict(iface)
    for iface in candidate.get("interfaces", []):
        name = iface.get("name")
        if not name:
            continue
        if name not in interface_map:
            interface_map[str(name)] = dict(iface)
            continue
        merged_iface = interface_map[str(name)]
        for key, value in iface.items():
            if value not in (None, "", []):
                merged_iface[key] = value

    network_map: dict[tuple[Any, Any], dict[str, Any]] = {}
    for network in current.get("networks", []):
        key = (network.get("cidr"), network.get("vlanId"))
        network_map[key] = dict(network)
    for network in candidate.get("networks", []):
        key = (network.get("cidr"), network.get("vlanId"))
        if key not in network_map:
            network_map[key] = dict(network)

    merged["interfaces"] = list(interface_map.values())
    if network_map:
        merged["networks"] = list(network_map.values())

    return merged


def _host_direct_score(host: dict[str, Any]) -> int:
    attached = host.get("attachedTo") or {}
    observed = host.get("observedVia") or {}
    if attached.get("deviceId") and attached.get("deviceId") == observed.get("deviceId"):
        return 2
    if attached.get("deviceId"):
        return 1
    return 0


def _merge_hosts(current: dict[str, Any] | None, candidate: dict[str, Any]) -> dict[str, Any]:
    if current is None:
        return candidate

    current_score = _host_direct_score(current)
    candidate_score = _host_direct_score(candidate)
    preferred = candidate if candidate_score >= current_score else current
    fallback = current if preferred is candidate else candidate

    merged = dict(fallback)
    merged.update(preferred)
    if "observedVia" not in preferred and "observedVia" in fallback:
        merged["observedVia"] = fallback["observedVia"]
    return merged


def _merge_snapshots(site_name: str, snapshots: list[dict[str, Any]], root_device_id: str) -> dict[str, Any]:
    devices_by_id: dict[str, dict[str, Any]] = {}
    hosts_by_id: dict[str, dict[str, Any]] = {}
    l2_neighbors: dict[tuple[Any, ...], dict[str, Any]] = {}
    mac_table: dict[tuple[Any, ...], dict[str, Any]] = {}
    warnings: list[str] = []

    for snapshot in snapshots:
        metadata = snapshot.get("metadata", {})
        warnings.extend(metadata.get("warnings", []))

        for device in snapshot.get("devices", []):
            device_id = device.get("id")
            if not device_id:
                continue
            devices_by_id[str(device_id)] = _merge_devices(devices_by_id.get(str(device_id)), device)

        for host in snapshot.get("hosts", []):
            host_id = host.get("id")
            if not host_id:
                continue
            hosts_by_id[str(host_id)] = _merge_hosts(hosts_by_id.get(str(host_id)), host)

        for neighbor in snapshot.get("l2Neighbors", []):
            key = (
                neighbor.get("localDeviceId"),
                neighbor.get("localInterfaceName"),
                neighbor.get("remoteDeviceId"),
                neighbor.get("remoteInterfaceName"),
            )
            reverse_key = (
                neighbor.get("remoteDeviceId"),
                neighbor.get("remoteInterfaceName"),
                neighbor.get("localDeviceId"),
                neighbor.get("localInterfaceName"),
            )
            if key not in l2_neighbors and reverse_key not in l2_neighbors:
                l2_neighbors[key] = neighbor

        for row in snapshot.get("macTable", []):
            key = (
                row.get("deviceId"),
                row.get("interfaceName"),
                row.get("vlanId"),
                row.get("macAddress"),
            )
            mac_table[key] = row

    merged = {
        "metadata": {
            "name": site_name,
            "source": "routeros-rest-recursive",
            "notes": "Snapshot generado desde RouterOS REST con expansion recursiva de vecinos MikroTik.",
            "warnings": warnings,
        },
        "rootDeviceId": root_device_id,
        "devices": list(devices_by_id.values()),
        "l2Neighbors": list(l2_neighbors.values()),
        "hosts": list(hosts_by_id.values()),
        "macTable": list(mac_table.values()),
    }

    primary_metadata = snapshots[0].get("metadata", {}) if snapshots else {}
    if primary_metadata.get("generatedAt"):
        merged["metadata"]["generatedAt"] = primary_metadata["generatedAt"]

    return merged


@dataclass(slots=True)
class RouterOsDiscoveryResult:
    snapshot: dict[str, Any]
    warnings: list[str]


def collect_routeros_discovery(
    config: RouterOsConfig,
    *,
    max_neighbor_depth: int = 1,
) -> RouterOsDiscoveryResult:
    visited: set[str] = set()
    warnings: list[str] = []
    snapshots: list[dict[str, Any]] = []

    def walk_snmp(host: str, depth: int) -> None:
        if host in visited:
            return
        visited.add(host)

        snmp_cfg = SnmpTargetConfig(
            host=host,
            port=config.snmp_port,
            community=config.snmp_community,
            timeout_seconds=min(config.timeout_seconds, 5),
        )
        try:
            result = collect_snmp_target_snapshot(host, config.site_name, snmp_cfg)
        except (SnmpCollectionError, SnmpUnavailableError) as exc:
            warnings.append(f"SNMP {host}: {exc}")
            return

        snapshots.append(result.snapshot)
        warnings.extend(result.warnings)

        if depth >= max_neighbor_depth:
            return

        for neighbor_ip in result.neighbor_ips:
            if neighbor_ip not in visited:
                walk_snmp(neighbor_ip, depth + 1)

    def walk(current_config: RouterOsConfig, depth: int) -> None:
        host = current_config.host
        if host in visited:
            return
        visited.add(host)

        try:
            snapshot, neighbors = _collect_router_snapshot(current_config)
        except RouterOsRestError as exc:
            warnings.append(f"REST {host}: {exc}")
            if config.snmp_community:
                # Fallback: REST no disponible, intentar descubrimiento SNMP/LLDP
                snmp_cfg = SnmpTargetConfig(
                    host=host,
                    port=config.snmp_port,
                    community=config.snmp_community,
                    timeout_seconds=config.timeout_seconds,
                )
                try:
                    result = collect_snmp_target_snapshot(host, current_config.site_name, snmp_cfg)
                    snapshots.append(result.snapshot)
                    warnings.extend(result.warnings)
                    if depth < max_neighbor_depth:
                        for neighbor_ip in result.neighbor_ips:
                            if neighbor_ip not in visited:
                                walk_snmp(neighbor_ip, depth + 1)
                except (SnmpCollectionError, SnmpUnavailableError) as snmp_exc:
                    warnings.append(f"SNMP {host}: {snmp_exc}")
            return

        snapshots.append(snapshot)

        if depth >= max_neighbor_depth:
            return

        for neighbor in neighbors:
            management_ip = _first_non_empty(neighbor, "address", "management-address")
            if not management_ip or management_ip in visited:
                continue

            if _is_mikrotik_neighbor(neighbor):
                walk(
                    RouterOsConfig(
                        site_name=current_config.site_name,
                        host=str(management_ip),
                        username=current_config.username,
                        password=current_config.password,
                        verify_tls=current_config.verify_tls,
                        timeout_seconds=current_config.timeout_seconds,
                        vendor=current_config.vendor,
                        model=current_config.model,
                        snmp_community=current_config.snmp_community,
                        snmp_port=current_config.snmp_port,
                        rest_port=current_config.rest_port if current_config.protocol == "rest" else 443,
                        rest_https=current_config.rest_https if current_config.protocol == "rest" else None,
                        protocol=_neighbor_protocol(neighbor, current_config),
                        api_port=current_config.api_port,
                        api_tls=current_config.api_tls,
                    ),
                    depth + 1,
                )
            elif current_config.snmp_community:
                walk_snmp(str(management_ip), depth + 1)

    walk(config, 0)

    if not snapshots:
        raise RouterOsRestError("No se pudo recolectar ningun snapshot RouterOS.")

    merged = _merge_snapshots(
        config.site_name,
        snapshots,
        root_device_id=_device_id_from_host(config.host),
    )
    if warnings:
        merged.setdefault("metadata", {})
        merged["metadata"]["warnings"] = warnings
    return RouterOsDiscoveryResult(snapshot=merged, warnings=warnings)
