from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from ipaddress import ip_interface
import re
from typing import Any

from .snmp_client import SimpleSnmpClient, SnmpCollectionError, SnmpTargetConfig
from .snmp_lldp import _infer_vendor as _vendor_from_descr, fetch_lldp_snapshot


SYS_NAME_OID = "1.3.6.1.2.1.1.5.0"
SYS_DESCR_OID = "1.3.6.1.2.1.1.1.0"
IF_DESCR_OID = "1.3.6.1.2.1.2.2.1.2"
IP_ADDR_IFINDEX_OID = "1.3.6.1.2.1.4.20.1.2"
IP_ADDR_NETMASK_OID = "1.3.6.1.2.1.4.20.1.3"
BRIDGE_PORT_IFINDEX_OID = "1.3.6.1.2.1.17.1.4.1.2"
FDB_PORT_OID = "1.3.6.1.2.1.17.4.3.1.2"
# Q-BRIDGE-MIB dot1qTpFdbPort (.<fdbId>.<mac>): la tabla de MACs de los switches con VLANs
# (HP/Aruba, TP-Link...), que muchas veces dejan vacía la de BRIDGE-MIB.
QFDB_PORT_OID = "1.3.6.1.2.1.17.7.1.2.2.1.2"
IF_NAME_OID = "1.3.6.1.2.1.31.1.1.1.1"
ARP_MAC_OID = "1.3.6.1.2.1.4.22.1.2"
ARP_IP_NET_TO_MEDIA_PREFIX = "1.3.6.1.2.1.4.22.1"


@dataclass(slots=True)
class SnmpTargetSnapshotResult:
    snapshot: dict[str, Any]
    neighbor_ips: list[str]
    warnings: list[str]


def _slugify(value: Any) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower())
    return text.strip("-") or "unknown"


def _normalize_mac(value: Any) -> str:
    cleaned = re.sub(r"[^0-9a-fA-F]", "", str(value or ""))
    if len(cleaned) != 12:
        return str(value or "").upper()
    return ":".join(cleaned[index:index + 2] for index in range(0, 12, 2)).upper()


def _safe_int(value: Any) -> int | None:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return None


def _infer_vendor(sys_descr: str) -> str:
    return _vendor_from_descr(sys_descr)


def _infer_kind(sys_name: str, sys_descr: str) -> str:
    normalized = f"{sys_name} {sys_descr}".lower()
    if "routeros" in normalized or "router" in normalized or "gateway" in normalized:
        return "router"
    if "switch" in normalized or "procurve" in normalized or "aruba" in normalized:
        return "switch"
    if "access point" in normalized or "unifi ap" in normalized or "omada eap" in normalized or "wifi" in normalized:
        return "ap"
    if "camera" in normalized or "hikvision" in normalized or "dahua" in normalized:
        return "camera"
    if "nvr" in normalized or "dvr" in normalized:
        return "nvr"
    return "switch"


def _oid_suffix(oid: str, prefix: str) -> list[int]:
    # snmpwalk -On devuelve los OID con punto inicial (".1.3.6...")
    suffix = oid.lstrip(".").removeprefix(prefix.lstrip(".")).lstrip(".")
    if not suffix:
        return []
    return [int(part) for part in suffix.split(".") if part]


def _build_interfaces(interface_rows: list[tuple[str, str]],
                      name_rows: list[tuple[str, str]] | None = None) -> dict[int, dict[str, Any]]:
    names: dict[int, str] = {}
    for oid, value in name_rows or []:
        suffix = _oid_suffix(oid, IF_NAME_OID)
        if suffix and value:
            names[suffix[-1]] = str(value)
    interface_map: dict[int, dict[str, Any]] = {}
    for oid, value in interface_rows:
        suffix = _oid_suffix(oid, IF_DESCR_OID)
        if not suffix:
            continue
        if_index = suffix[-1]
        interface_map[if_index] = {
            "name": names.get(if_index) or str(value),
            "role": "interface",
            "mode": "unknown",
            "allowedVlans": [],
        }
    return interface_map


def _build_networks(
    ip_ifindex_rows: list[tuple[str, str]],
    ip_netmask_rows: list[tuple[str, str]],
    interface_map: dict[int, dict[str, Any]],
) -> list[dict[str, Any]]:
    ifindex_by_ip: dict[str, int] = {}
    netmask_by_ip: dict[str, str] = {}
    for oid, value in ip_ifindex_rows:
        suffix = _oid_suffix(oid, IP_ADDR_IFINDEX_OID)
        if len(suffix) == 4:
            ifindex_by_ip[".".join(map(str, suffix))] = int(value)
    for oid, value in ip_netmask_rows:
        suffix = _oid_suffix(oid, IP_ADDR_NETMASK_OID)
        if len(suffix) == 4:
            netmask_by_ip[".".join(map(str, suffix))] = str(value)

    networks: list[dict[str, Any]] = []
    seen: set[str] = set()
    for ip_address, if_index in ifindex_by_ip.items():
        netmask = netmask_by_ip.get(ip_address)
        if not netmask:
            continue
        try:
            iface = ip_interface(f"{ip_address}/{netmask}")
        except ValueError:
            continue
        cidr = str(iface.network)
        if cidr in seen:
            continue
        seen.add(cidr)
        networks.append(
            {
                "cidr": cidr,
                "name": interface_map.get(if_index, {}).get("name", cidr),
                "vlanId": None,
            }
        )
    return networks


def _build_mac_table(
    device_id: str,
    bridge_ifindex_rows: list[tuple[str, str]],
    fdb_rows: list[tuple[str, str]],
    interface_map: dict[int, dict[str, Any]],
    qfdb_rows: list[tuple[str, str]] | None = None,
) -> list[dict[str, Any]]:
    base_port_to_ifindex: dict[int, int] = {}
    for oid, value in bridge_ifindex_rows:
        suffix = _oid_suffix(oid, BRIDGE_PORT_IFINDEX_OID)
        if suffix:
            parsed = _safe_int(value)
            if parsed is not None:
                base_port_to_ifindex[suffix[-1]] = parsed

    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    entries = [(oid, value, FDB_PORT_OID) for oid, value in fdb_rows]
    entries += [(oid, value, QFDB_PORT_OID) for oid, value in qfdb_rows or []]
    for oid, value, prefix in entries:
        suffix = _oid_suffix(oid, prefix)
        if len(suffix) < 6:
            continue
        # En Q-BRIDGE el primer número es la FDB, que en casi todos los switches es la VLAN
        vlan_id = suffix[0] if prefix == QFDB_PORT_OID and len(suffix) >= 7 else None
        base_port = _safe_int(value)
        if base_port is None:
            continue
        if_index = base_port_to_ifindex.get(base_port)
        if if_index is None:
            continue
        iface_name = interface_map.get(if_index, {}).get("name")
        if not iface_name:
            continue
        mac = _normalize_mac(":".join(f"{part:02X}" for part in suffix[-6:]))
        dedupe_key = (iface_name, mac)
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        rows.append(
            {
                "deviceId": device_id,
                "interfaceName": iface_name,
                "vlanId": vlan_id,
                "macAddress": mac,
            }
        )
    return rows


def _build_arp_map(arp_rows: list[tuple[str, str]]) -> dict[str, dict[str, Any]]:
    arp_by_mac: dict[str, dict[str, Any]] = {}
    arp_by_ip: dict[str, dict[str, Any]] = {}

    for oid, value in arp_rows:
        suffix = _oid_suffix(oid, ARP_MAC_OID)
        if len(suffix) < 5:
            continue
        if_index = suffix[0]
        ip_address = ".".join(str(part) for part in suffix[1:5])
        mac = _normalize_mac(value)
        record = {
            "ip": ip_address,
            "mac": mac,
            "ifIndex": if_index,
        }
        if mac:
            arp_by_mac[mac] = record
        arp_by_ip[ip_address] = record

    return {
        "by_mac": arp_by_mac,
        "by_ip": arp_by_ip,
    }


def _build_local_port_neighbors(
    device_id: str,
    neighbor_devices: list[dict[str, Any]],
    l2_neighbors: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    by_port: dict[str, dict[str, Any]] = {}
    neighbor_by_id = {str(device.get("id")): device for device in neighbor_devices}

    for link in l2_neighbors:
        if link.get("localDeviceId") != device_id:
            continue
        remote_id = str(link.get("remoteDeviceId") or "")
        remote_device = neighbor_by_id.get(remote_id)
        local_port = str(link.get("localInterfaceName") or "")
        if not local_port:
            continue
        by_port[local_port] = {
            "remoteDeviceId": remote_id,
            "remoteInterfaceName": str(link.get("remoteInterfaceName") or "unknown"),
            "managementIp": remote_device.get("managementIp") if remote_device else "",
        }

    return by_port


def _build_hosts(
    device_id: str,
    mac_table: list[dict[str, Any]],
    arp_rows: list[tuple[str, str]],
    local_port_neighbors: dict[str, dict[str, Any]],
    neighbor_devices: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    arp_lookup = _build_arp_map(arp_rows)
    arp_by_mac = arp_lookup["by_mac"]
    neighbor_ips = {
        str(device.get("managementIp") or "")
        for device in neighbor_devices
        if device.get("managementIp")
    }

    hosts: list[dict[str, Any]] = []
    seen_host_ids: set[str] = set()
    interface_counters: dict[str, int] = defaultdict(int)

    for row in mac_table:
        mac = _normalize_mac(row.get("macAddress"))
        if not mac:
            continue
        arp = arp_by_mac.get(mac, {})
        ip_address = str(arp.get("ip") or "")
        if ip_address and ip_address in neighbor_ips:
            continue

        interface_name = str(row.get("interfaceName") or "")
        if not interface_name:
            continue

        owner = local_port_neighbors.get(interface_name)
        attached_device_id = str(owner.get("remoteDeviceId")) if owner else device_id
        attached_interface_name = str(owner.get("remoteInterfaceName")) if owner else interface_name

        host_id = f"host-{_slugify(mac)}"
        if host_id in seen_host_ids:
            continue
        seen_host_ids.add(host_id)

        interface_counters[interface_name] += 1
        display_name = ip_address or mac
        hosts.append(
            {
                "id": host_id,
                "name": display_name,
                "kind": "host",
                "ip": ip_address,
                "mac": mac,
                "vlanId": row.get("vlanId"),
                "attachedTo": {
                    "deviceId": attached_device_id,
                    "interfaceName": attached_interface_name,
                },
                "observedVia": {
                    "deviceId": device_id,
                    "interfaceName": interface_name,
                },
                "metadata": {
                    "ordinalOnInterface": interface_counters[interface_name],
                },
            }
        )

    return hosts


def collect_snmp_target_snapshot(
    target: str,
    site_name: str,
    snmp_config: SnmpTargetConfig,
) -> SnmpTargetSnapshotResult:
    client = SimpleSnmpClient(snmp_config)

    sys_name = client.get_scalar(SYS_NAME_OID) or target
    sys_descr = client.get_scalar(SYS_DESCR_OID) or "SNMP device"
    interfaces = client.walk(IF_DESCR_OID)

    def optional_walk(oid: str) -> list[tuple[str, str]]:
        # Tablas que no todos los equipos tienen: si falta una, se sigue con el resto
        try:
            return client.walk(oid)
        except SnmpCollectionError:
            return []

    if_name_rows = optional_walk(IF_NAME_OID)
    ip_ifindex_rows = optional_walk(IP_ADDR_IFINDEX_OID)
    ip_netmask_rows = optional_walk(IP_ADDR_NETMASK_OID)
    bridge_ifindex_rows = optional_walk(BRIDGE_PORT_IFINDEX_OID)
    fdb_rows = optional_walk(FDB_PORT_OID)
    qfdb_rows = optional_walk(QFDB_PORT_OID) if not fdb_rows else []
    arp_rows = optional_walk(ARP_MAC_OID)

    device_id = f"device-{_slugify(target)}"
    interface_map = _build_interfaces(interfaces, if_name_rows)
    networks = _build_networks(ip_ifindex_rows, ip_netmask_rows, interface_map)

    neighbor_devices: list[dict[str, Any]] = []
    l2_neighbors: list[dict[str, Any]] = []
    neighbor_ips: list[str] = []
    warnings: list[str] = []

    try:
        lldp_snapshot, neighbor_ips = fetch_lldp_snapshot(target, snmp_config, site_name)
        neighbor_devices = [
            device
            for device in lldp_snapshot.get("devices", [])
            if device.get("id") != device_id
        ]
        l2_neighbors = lldp_snapshot.get("l2Neighbors", [])
    except Exception as exc:  # LLDP parcial no debe romper el resto del snapshot.
        warnings.append(f"{target}: LLDP parcial no disponible ({exc})")

    local_port_neighbors = _build_local_port_neighbors(device_id, neighbor_devices, l2_neighbors)
    mac_table = _build_mac_table(device_id, bridge_ifindex_rows, fdb_rows, interface_map, qfdb_rows)
    hosts = _build_hosts(device_id, mac_table, arp_rows, local_port_neighbors, neighbor_devices)

    snapshot = {
        "metadata": {
            "name": site_name,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "source": "snmp-generic",
            "notes": "Snapshot generado por SNMP generico con tabla MAC, ARP y LLDP.",
            "warnings": warnings,
        },
        "rootDeviceId": device_id,
        "devices": [
            {
                "id": device_id,
                "name": sys_name,
                "kind": _infer_kind(sys_name, sys_descr),
                "vendor": _infer_vendor(sys_descr),
                "os": sys_descr,
                "managementIp": target,
                "site": site_name,
                "networks": networks,
                "interfaces": list(interface_map.values()),
            },
            *neighbor_devices,
        ],
        "l2Neighbors": l2_neighbors,
        "hosts": hosts,
        "macTable": mac_table,
    }

    return SnmpTargetSnapshotResult(
        snapshot=snapshot,
        neighbor_ips=list(dict.fromkeys(neighbor_ips)),
        warnings=warnings,
    )
