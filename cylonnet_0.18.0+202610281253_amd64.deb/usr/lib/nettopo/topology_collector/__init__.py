"""Topology collector package."""
