from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_config
from .routeros_rest import RouterOsRestClient, RouterOsRestError
from .snapshot_builder import build_snapshot


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Colector inicial de topologia para MikroTik RouterOS REST."
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Ruta al archivo JSON de configuracion del MikroTik.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Ruta del snapshot JSON a generar.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config)
    client = RouterOsRestClient(config)

    try:
        identity = client.fetch_identity()
        resource = client.fetch_resource()
        interfaces = client.fetch_interfaces()
        ip_addresses = client.fetch_ip_addresses()
        neighbors = client.fetch_neighbors()
        bridge_vlans = client.fetch_bridge_vlans()
        bridge_hosts = client.fetch_bridge_hosts()
        arp_entries = client.fetch_arp()
    except RouterOsRestError as exc:
        print(f"ERROR: {exc}")
        return 1

    snapshot = build_snapshot(
        config=config,
        identity=identity,
        resource=resource,
        interfaces=interfaces,
        ip_addresses=ip_addresses,
        neighbors=neighbors,
        bridge_vlans=bridge_vlans,
        bridge_hosts=bridge_hosts,
        arp_entries=arp_entries,
    )

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
    print(f"Snapshot generado en {output_path}")
    return 0
