from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from ipaddress import ip_interface
import re
from typing import Any

from .config import RouterOsConfig


def _split_csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def _normalize_interface_name(value: str | None) -> str:
    options = _split_csv(value)
    if not options:
        return str(value or "").strip()
    for option in options:
        if option.lower() != "bridge":
            return option
    return options[0]


def _safe_vlan_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(str(value))
    except ValueError:
        return None


def _first_non_empty(record: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = record.get(key)
        if value not in (None, "", "unknown"):
            return value
    return None


def _slugify(value: Any) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower())
    return text.strip("-") or "unknown"


def _normalize_mac(value: Any) -> str:
    cleaned = re.sub(r"[^0-9a-fA-F]", "", str(value or ""))
    if len(cleaned) != 12:
        return str(value or "")
    return ":".join(cleaned[index:index + 2] for index in range(0, 12, 2)).upper()


def _ensure_interface(device: dict[str, Any], name: str, *, role: str = "interface") -> None:
    interfaces = device.setdefault("interfaces", [])
    if any(item.get("name") == name for item in interfaces):
        return
    interfaces.append(
        {
            "name": name,
            "role": role,
            "mode": "unknown",
            "allowedVlans": [],
        }
    )


def _neighbor_device_id(item: dict[str, Any], index: int) -> str:
    management_ip = _first_non_empty(item, "address", "management-address")
    identity = _first_non_empty(item, "identity", "system-name", "platform", "address")
    if management_ip:
        return f"device-{_slugify(management_ip)}"
    if identity:
        return f"neighbor-{_slugify(identity)}"
    return f"neighbor-{index}"


def _build_interface_records(
    interfaces: list[dict[str, Any]],
    bridge_vlans: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    interface_map: dict[str, dict[str, Any]] = {}

    for item in interfaces:
        name = str(item.get("name", ""))
        if not name:
            continue
        interface_map[name] = {
            "name": name,
            "role": "interface",
            "mode": "unknown",
            "allowedVlans": [],
        }

    tagged_by_iface: dict[str, set[int]] = defaultdict(set)
    untagged_by_iface: dict[str, set[int]] = defaultdict(set)

    for vlan_record in bridge_vlans:
        vlan_id = _safe_vlan_int(vlan_record.get("vlan-ids"))
        if vlan_id is None:
            continue
        for iface_name in _split_csv(vlan_record.get("tagged")):
            tagged_by_iface[iface_name].add(vlan_id)
        for iface_name in _split_csv(vlan_record.get("untagged")):
            untagged_by_iface[iface_name].add(vlan_id)

    for iface_name, interface in interface_map.items():
        tagged = sorted(tagged_by_iface.get(iface_name, set()))
        untagged = sorted(untagged_by_iface.get(iface_name, set()))

        if tagged and untagged:
            interface["mode"] = "trunk"
            interface["allowedVlans"] = sorted(set(tagged + untagged))
            interface["accessVlanId"] = untagged[0]
            interface["nativeVlanId"] = untagged[0]
        elif tagged:
            interface["mode"] = "trunk"
            interface["allowedVlans"] = tagged
        elif untagged:
            interface["mode"] = "access"
            interface["allowedVlans"] = untagged
            interface["accessVlanId"] = untagged[0]
        else:
            interface["allowedVlans"] = []

    return list(interface_map.values())


def _build_networks(ip_addresses: list[dict[str, Any]]) -> list[dict[str, Any]]:
    networks: list[dict[str, Any]] = []

    for item in ip_addresses:
        address = item.get("address")
        if not address:
            continue

        try:
            iface = ip_interface(str(address))
        except ValueError:
            continue

        networks.append(
            {
                "cidr": str(iface.network),
                "name": item.get("interface") or str(iface.network),
                "vlanId": None,
            }
        )

    unique: dict[str, dict[str, Any]] = {}
    for network in networks:
        unique[network["cidr"]] = network
    return list(unique.values())


def _build_neighbors(
    root_device_id: str,
    neighbors: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, dict[str, Any]]]:
    devices: list[dict[str, Any]] = []
    links: list[dict[str, Any]] = []
    seen_devices: dict[str, dict[str, Any]] = {}
    local_port_map: dict[str, dict[str, Any]] = {}

    for index, item in enumerate(neighbors, start=1):
        remote_name = _first_non_empty(item, "identity", "system-name", "platform", "address")
        local_interface = _normalize_interface_name(_first_non_empty(item, "interface", "local-interface"))
        remote_interface = _first_non_empty(item, "interface-name", "port-id", "port-description")

        if not remote_name or not local_interface:
            continue

        remote_device_id = _neighbor_device_id(item, index)
        device = seen_devices.get(remote_device_id)
        if device is None:
            device = {
                "id": remote_device_id,
                "name": str(remote_name),
                "kind": "neighbor",
                "vendor": _first_non_empty(item, "platform", "board") or "Unknown",
                "os": _first_non_empty(item, "version", "system-description") or "Unknown",
                "managementIp": _first_non_empty(item, "address", "management-address") or "",
                "site": "Discovered neighbor",
                "interfaces": [],
            }
            seen_devices[remote_device_id] = device
            devices.append(device)

        if remote_interface:
            _ensure_interface(device, str(remote_interface), role="uplink")

        links.append(
            {
                "localDeviceId": root_device_id,
                "localInterfaceName": str(local_interface),
                "remoteDeviceId": remote_device_id,
                "remoteInterfaceName": str(remote_interface or "unknown"),
                "protocol": "lldp-or-mndp",
                "confidence": 0.85,
            }
        )
        local_port_map[str(local_interface)] = {
            "remoteDeviceId": remote_device_id,
            "remoteInterfaceName": str(remote_interface or "unknown"),
            "managementIp": device.get("managementIp") or "",
        }

    return devices, links, local_port_map


def _build_mac_table(bridge_hosts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in bridge_hosts:
        interface_name = _first_non_empty(item, "on-interface", "interface")
        mac_address = _first_non_empty(item, "mac-address", "mac")
        vlan_id = _safe_vlan_int(_first_non_empty(item, "vlan-id", "vid"))

        if not interface_name or not mac_address:
            continue

        rows.append(
            {
                "interfaceName": str(interface_name),
                "macAddress": str(mac_address),
                "vlanId": vlan_id,
            }
        )
    return rows


def _build_hosts(
    root_device_id: str,
    mac_table: list[dict[str, Any]],
    arp_entries: list[dict[str, Any]],
    neighbor_devices: list[dict[str, Any]],
    local_port_neighbors: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    neighbor_macs = {
        device.get("managementIp"): device["id"]
        for device in neighbor_devices
        if device.get("managementIp")
    }
    arp_by_mac: dict[str, dict[str, Any]] = {}
    for item in arp_entries:
        mac = _first_non_empty(item, "mac-address", "mac")
        if mac:
            arp_by_mac[str(mac).lower()] = item

    hosts: list[dict[str, Any]] = []
    seen_host_ids: set[str] = set()

    for row in mac_table:
        mac = row["macAddress"].lower()
        arp = arp_by_mac.get(mac, {})
        ip_address = _first_non_empty(arp, "address")
        if ip_address and ip_address in neighbor_macs:
            continue

        host_id = f"host-{_slugify(_normalize_mac(row['macAddress']))}"
        if host_id in seen_host_ids:
            continue

        host_name = _first_non_empty(arp, "host-name", "comment", "address") or row["macAddress"]
        owner = local_port_neighbors.get(row["interfaceName"])
        attached_device_id = owner.get("remoteDeviceId") if owner else root_device_id
        attached_interface_name = owner.get("remoteInterfaceName") if owner else row["interfaceName"]
        hosts.append(
            {
                "id": host_id,
                "name": str(host_name),
                "kind": "host",
                "ip": str(ip_address or ""),
                "mac": row["macAddress"],
                "vlanId": row["vlanId"],
                "attachedTo": {
                    "deviceId": str(attached_device_id),
                    "interfaceName": str(attached_interface_name),
                },
                "observedVia": {
                    "deviceId": root_device_id,
                    "interfaceName": row["interfaceName"],
                },
            }
        )
        seen_host_ids.add(host_id)

    return hosts


def _kind_from_board(board: str) -> str:
    """Tipo de equipo segun el modelo de RouterBOARD (CRS/CSS son switches; cAP/wAP, access points)."""
    name = board.upper()
    if name.startswith(("CRS", "CSS", "NETFIBER")):
        return "switch"
    if name.startswith(("CAP", "WAP", "AUDIENCE")):
        return "access-point"
    return "router"


def build_snapshot(
    config: RouterOsConfig,
    identity: dict[str, Any],
    resource: dict[str, Any],
    interfaces: list[dict[str, Any]],
    ip_addresses: list[dict[str, Any]],
    neighbors: list[dict[str, Any]],
    bridge_vlans: list[dict[str, Any]],
    bridge_hosts: list[dict[str, Any]],
    arp_entries: list[dict[str, Any]],
    root_device_id: str | None = None,
) -> dict[str, Any]:
    root_name = str(identity.get("name") or config.host)
    board = str(resource.get("board-name") or "")
    resolved_root_device_id = root_device_id or f"device-{_slugify(config.host)}"

    interface_records = _build_interface_records(interfaces, bridge_vlans)
    root_device: dict[str, Any] = {
        "id": resolved_root_device_id,
        "name": root_name,
        "kind": _kind_from_board(board),
        "vendor": config.vendor or "MikroTik",
        "os": str(resource.get("version") or "RouterOS"),
        "managementIp": config.host,
        "site": config.site_name,
        "networks": _build_networks(ip_addresses),
        "interfaces": interface_records,
    }
    if config.model or board:
        root_device["model"] = config.model or board

    neighbor_devices, l2_neighbors, local_port_neighbors = _build_neighbors(resolved_root_device_id, neighbors)
    mac_table_rows = _build_mac_table(bridge_hosts)
    hosts = _build_hosts(
        resolved_root_device_id,
        mac_table_rows,
        arp_entries,
        neighbor_devices,
        local_port_neighbors,
    )

    mac_table = [
        {
            "deviceId": resolved_root_device_id,
            "interfaceName": row["interfaceName"],
            "vlanId": row["vlanId"],
            "macAddress": row["macAddress"],
        }
        for row in mac_table_rows
    ]

    snapshot = {
        "metadata": {
            "name": config.site_name,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "source": "routeros-rest",
            "notes": "Snapshot generado desde MikroTik RouterOS REST API.",
        },
        "rootDeviceId": resolved_root_device_id,
        "devices": [root_device, *neighbor_devices],
        "l2Neighbors": l2_neighbors,
        "hosts": hosts,
        "macTable": mac_table,
    }

    return deepcopy(snapshot)
