from __future__ import annotations

import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .config import RouterOsConfig
from .routeros_rest import RouterOsRestClient, RouterOsRestError
from .snmp_client import SimpleSnmpClient, SnmpCollectionError, SnmpTargetConfig


def _tcp_open(host: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _probe_routeros(host: str, username: str, password: str, timeout: int) -> int | None:
    for port in (443, 80):
        if not _tcp_open(host, port, timeout=min(float(timeout), 2.0)):
            continue
        try:
            config = RouterOsConfig(
                site_name="probe",
                host=host,
                username=username,
                password=password,
                verify_tls=False,
                timeout_seconds=timeout,
                rest_port=port,
            )
            RouterOsRestClient(config).get("system/identity")
            return port
        except Exception:
            continue
    return None


def _probe_snmp(host: str, community: str, timeout: int) -> bool:
    try:
        cfg = SnmpTargetConfig(host=host, community=community, timeout_seconds=timeout, retries=0)
        return SimpleSnmpClient(cfg).get_scalar("1.3.6.1.2.1.1.1.0") is not None
    except Exception:
        return False


def _probe_one(ip: str, username: str, password: str, community: str) -> dict[str, Any] | None:
    safe = ip.replace(".", "-")
    routeros_port = _probe_routeros(ip, username, password, timeout=4) if username and password else None
    if routeros_port:
        return {
            "type": "mikrotik-routeros",
            "name": f"mikrotik-{safe}",
            "enabled": True,
            "host": ip,
            "username": username,
            "password": password,
            "port": routeros_port,
            "verify_tls": False,
            "timeout_seconds": 15,
            "max_neighbor_depth": 1,
            "auto_discovered": True,
        }
    if community and _probe_snmp(ip, community, timeout=3):
        return {
            "type": "snmp-generic",
            "name": f"snmp-{safe}",
            "enabled": True,
            "host": ip,
            "targets": [ip],
            "version": "2c",
            "community": community,
            "timeout_seconds": 15,
            "max_neighbor_depth": 1,
            "auto_discovered": True,
        }
    return None


def probe_hosts(
    discovered_ips: list[str],
    default_credentials: dict[str, Any],
    already_known_hosts: set[str],
) -> list[dict[str, Any]]:
    username = str(default_credentials.get("username") or "").strip()
    password = str(default_credentials.get("password") or "")
    community = str(default_credentials.get("snmp_community") or "").strip()

    if not username and not community:
        return []

    # Deduplicate and skip already-configured hosts
    seen: set[str] = set()
    ips_to_probe: list[str] = []
    for ip in discovered_ips:
        if ip and ip not in seen and ip not in already_known_hosts:
            seen.add(ip)
            ips_to_probe.append(ip)

    if not ips_to_probe:
        return []

    results: list[dict[str, Any]] = []
    workers = min(len(ips_to_probe), 10)

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(_probe_one, ip, username, password, community): ip
            for ip in ips_to_probe
        }
        for future in as_completed(futures):
            result = future.result()
            if result is not None:
                results.append(result)

    return results
