"""Herramientas que NetTopo le ofrece a Claude por MCP.

Casi todas son de solo lectura: consultan equipos o la red y nunca cambian nada. La única que
escribe, mikrotik_cambiar, pide antes confirmación al usuario en una ventana propia (cambios.py).
Las claves de los equipos no salen de acá: se tachan de las respuestas.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from typing import Any, Callable

from topology_collector.routeros_api import client_for
from topology_collector.routeros_discovery import collect_routeros_discovery
from topology_collector.routeros_rest import RouterOsRestClient, RouterOsRestError
from topology_collector.site_models import SourceConfig
from topology_collector.sources.local_discovery import LocalDiscoveryAdapter

from . import cambios, controladores, equipos, lab, mikrotik, snmp
from .equipos import ErrorNetTopo

DIR_JS = Path(__file__).resolve().parent.parent / "js"


@dataclass(slots=True)
class Herramienta:
    nombre: str
    descripcion: str
    parametros: dict[str, Any]
    funcion: Callable[..., Any]
    requeridos: tuple[str, ...] = ()
    solo_lectura: bool = True

    def definicion(self) -> dict[str, Any]:
        return {
            "name": self.nombre,
            "description": self.descripcion,
            "inputSchema": {
                "type": "object",
                "properties": self.parametros,
                "required": list(self.requeridos),
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": self.solo_lectura, "destructiveHint": not self.solo_lectura,
                            "openWorldHint": True},
        }


HERRAMIENTAS: dict[str, Herramienta] = {}


def herramienta(descripcion: str, parametros: dict[str, Any] | None = None, requeridos: tuple[str, ...] = (),
                solo_lectura: bool = True):
    def registrar(funcion: Callable[..., Any]) -> Callable[..., Any]:
        HERRAMIENTAS[funcion.__name__] = Herramienta(funcion.__name__, descripcion, parametros or {}, funcion, requeridos,
                                                     solo_lectura)
        return funcion
    return registrar


P_EQUIPO = {"type": "string", "description": "Nombre o IP del equipo, tal como figura en equipos_listar."}


# ── Utilidades ────────────────────────────────────────────────────────────────

# Campos con secretos en RouterOS (claves PPP, IPsec, Wi-Fi, WireGuard, SNMP, usuarios...)
_SENSIBLE = re.compile(r"password|secret|passphrase|private-key|pre-shared-key|(?<!public)-key$|^key$|psk", re.I)


def _tachar(dato: Any, ruta: str = "") -> Any:
    if isinstance(dato, list):
        return [_tachar(item, ruta) for item in dato]
    if isinstance(dato, dict):
        resultado = {}
        for campo, valor in dato.items():
            sensible = _SENSIBLE.search(campo) or (ruta.startswith("snmp/community") and campo == "name")
            resultado[campo] = "***" if sensible and valor not in ("", None) else _tachar(valor, ruta)
        return resultado
    return dato


def _cliente(nombre: str) -> RouterOsRestClient:
    return client_for(equipos.config_routeros(equipos.buscar(nombre)))


def _error_rest(config: Any, exc: Exception) -> ErrorNetTopo:
    if config.protocol == "api":
        return ErrorNetTopo(f"{exc}\n\nRevisá que el servicio api (8728) o api-ssl (8729) esté habilitado en el "
                            "MikroTik (/ip service print) y que acepte conexiones desde esta PC.")
    https = config.rest_https if config.rest_https is not None else config.rest_port != 80
    return ErrorNetTopo(f"{exc}\n\nDiagnóstico: {mikrotik.diagnosticar(config.host, config.rest_port, https)}")


def _consultar(cliente: RouterOsRestClient, ruta: str, **kwargs: Any) -> Any:
    try:
        return cliente.get(ruta, **kwargs)
    except RouterOsRestError as exc:
        if "HTTP 400" in str(exc) or "HTTP 404" in str(exc):  # el equipo responde, el menú no existe
            raise ErrorNetTopo(str(exc)) from exc
        raise _error_rest(cliente.config, exc) from exc


def _avisos_vecinos(vecinos: list[dict]) -> list[str]:
    """Avisos por los MikroTik vecinos con RouterOS menor a 7.1 (no se van a poder relevar)."""
    avisos = []
    for vecino in vecinos:
        nombre = (f"{vecino.get('identity') or vecino.get('identidad') or '?'} "
                  f"({vecino.get('address') or vecino.get('ip') or 'sin IP'})")
        aviso = mikrotik.aviso_version(vecino.get("version"), nombre)
        if aviso:
            avisos.append(aviso)
    return avisos


def _uno(dato: Any) -> dict:
    if isinstance(dato, list):
        return dato[0] if dato else {}
    return dato or {}


def _elegir(registro: dict, *campos: str) -> dict:
    return {campo: registro[campo] for campo in campos if registro.get(campo) not in (None, "")}


def _slug(texto: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", texto.lower()).strip("-") or "sitio"


def _guardar_snapshot(snapshot: dict, sitio: str) -> Path:
    carpeta = equipos.dir_datos() / "snapshots"
    carpeta.mkdir(parents=True, exist_ok=True)
    archivo = carpeta / f"{_slug(sitio)}-{datetime.now():%Y%m%d-%H%M%S}.json"
    texto = json.dumps(snapshot, indent=2, ensure_ascii=False)
    archivo.write_text(texto, encoding="utf-8")
    (carpeta / "ultimo.json").write_text(texto, encoding="utf-8")
    return archivo


def _archivo_snapshot(archivo: str | None) -> Path:
    carpeta = equipos.dir_datos() / "snapshots"
    ruta = Path(archivo) if archivo else carpeta / "ultimo.json"
    if not ruta.is_absolute():
        ruta = carpeta / ruta
    if not ruta.exists():
        raise ErrorNetTopo("Todavía no hay ningún relevamiento guardado: usá red_relevar o red_escanear_local primero.")
    return ruta


def _node(*argumentos: str) -> str:
    if not shutil.which("node"):
        raise ErrorNetTopo("Falta Node.js (paquete nodejs) para armar la topología.")
    resultado = subprocess.run(["node", *argumentos], capture_output=True, text=True, timeout=120)
    if resultado.returncode != 0:
        raise ErrorNetTopo(f"Error al procesar la topología: {resultado.stderr.strip()[-800:]}")
    return resultado.stdout


def _resumen(archivo: Path) -> dict:
    resumen = json.loads(_node(str(DIR_JS / "resumen.js"), str(archivo)))
    resumen["archivo"] = str(archivo)
    return resumen


# ── Inventario ────────────────────────────────────────────────────────────────

@herramienta("Lista los equipos cargados en el inventario de NetTopo (nombre, IP, tipo, sitio y si tiene clave). "
             "Las claves nunca se muestran; las carga el usuario con `nettopo equipo agregar`.")
def equipos_listar() -> Any:
    lista = [equipo.publico() for equipo in equipos.cargar()]
    if not lista:
        return {"equipos": [], "nota": "Inventario vacío. El usuario agrega equipos con: nettopo equipo agregar NOMBRE IP"}
    return {"equipos": lista}


# ── MikroTik ──────────────────────────────────────────────────────────────────

@herramienta("Estado general de un MikroTik: identidad, modelo, versión de RouterOS, uptime, CPU, memoria, "
             "interfaces (con estado y tráfico acumulado), direcciones IP y rutas por defecto.",
             {"equipo": P_EQUIPO}, ("equipo",))
def mikrotik_resumen(equipo: str) -> Any:
    cliente = _cliente(equipo)
    identidad = _uno(_consultar(cliente, "system/identity"))
    recursos = _uno(_consultar(cliente, "system/resource"))
    placa = _uno(_consultar(cliente, "system/routerboard")) if recursos.get("board-name") else {}
    interfaces = _consultar(cliente, "interface") or []
    direcciones = _consultar(cliente, "ip/address") or []
    rutas = _consultar(cliente, "ip/route", filters={"dst-address": "0.0.0.0/0"}) or []
    resultado = {
        "identidad": identidad.get("name"),
        "sistema": _elegir(recursos, "board-name", "version", "uptime", "cpu-load", "cpu-count",
                           "free-memory", "total-memory", "architecture-name"),
        "placa": _elegir(placa, "model", "serial-number", "current-firmware", "upgrade-firmware"),
        "interfaces": [
            _elegir(i, "name", "type", "running", "disabled", "mac-address", "comment", "rx-byte", "tx-byte",
                    "rx-error", "tx-error", "link-downs", "last-link-up-time")
            for i in interfaces
        ],
        "direcciones": [_elegir(d, "address", "interface", "network", "disabled", "dynamic", "comment") for d in direcciones],
        "rutas_por_defecto": [_elegir(r, "gateway", "distance", "active", "disabled", "comment", "routing-table") for r in rutas],
    }
    aviso = None if cliente.config.protocol == "api" else mikrotik.aviso_version(recursos.get("version"), identidad.get("name", ""))
    if aviso:
        resultado["aviso"] = aviso
    return resultado


@herramienta("Consulta de solo lectura a cualquier menú de RouterOS por REST (equivale a `print` en la terminal). "
             "Ejemplos de ruta: 'ip/arp', 'ip/dhcp-server/lease', 'interface/bridge/vlan', 'interface/bridge/port', "
             "'ip/firewall/filter', 'ip/firewall/nat', 'ip/route', 'interface/wireguard/peers', 'log', 'ip/neighbor'. "
             "Los campos con claves o secretos se devuelven tachados.",
             {
                 "equipo": P_EQUIPO,
                 "ruta": {"type": "string", "description": "Menú de RouterOS separado por '/', sin '/rest'. Ej: 'ip/dhcp-server/lease'."},
                 "campos": {"type": "array", "items": {"type": "string"}, "description": "Opcional: solo estos campos (.proplist)."},
                 "filtro": {"type": "object", "additionalProperties": {"type": "string"},
                            "description": "Opcional: filtros por igualdad de campo. Ej: {\"interface\": \"ether2\"}."},
                 "limite": {"type": "integer", "description": "Máximo de registros a devolver (por defecto 300)."},
             },
             ("equipo", "ruta"))
def mikrotik_consultar(equipo: str, ruta: str, campos: list[str] | None = None,
                       filtro: dict[str, str] | None = None, limite: int = 300) -> Any:
    ruta = ruta.strip().strip("/").removeprefix("rest/")
    if not re.fullmatch(r"[a-z0-9][a-z0-9\-/.]*", ruta) or ".." in ruta:
        raise ErrorNetTopo(f"Ruta no válida: '{ruta}'. Usar el formato de menú, por ejemplo 'ip/firewall/filter'.")
    datos = _tachar(_consultar(_cliente(equipo), ruta, proplist=campos, filters=filtro), ruta)
    if isinstance(datos, list) and len(datos) > limite:
        return {"total": len(datos), "mostrando": limite, "registros": datos[:limite]}
    return datos


def _sensible(campo: str) -> bool:
    return bool(_SENSIBLE.search(campo))


def _error_escritura(exc: RouterOsRestError) -> str:
    texto = str(exc)
    if "HTTP 403" in texto or "permission" in texto.lower():
        return (f"{texto}\n\nEl usuario con el que NetTopo entra a este equipo no tiene permiso de escritura "
                "(por ejemplo, es del grupo read). Para habilitar cambios, en el MikroTik: "
                "`/user set nettopo group=write` (o crear otro usuario del grupo write y cargarlo con "
                "`nettopo equipo agregar NOMBRE IP --usuario OTRO`). No se modificó nada.")
    return f"{texto}\n\nEl equipo rechazó el cambio: no se modificó nada."


@herramienta("Aplica UN cambio de configuración en un MikroTik (equivale a add / set / remove / enable / disable "
             "en la terminal). Antes de aplicarlo, NetTopo le muestra al usuario una ventana con el equipo, el "
             "cambio campo por campo (valor actual → nuevo) y el motivo, y solo sigue si el usuario elige Aplicar; "
             "si cancela, no se toca nada. Consultá primero el registro con mikrotik_consultar para conocer su .id "
             "y sus valores. No permite tocar usuarios, paquetes, archivos, scripts, tareas programadas ni "
             "certificados. Cada cambio queda registrado (cambios_listar) junto con la operación para deshacerlo.",
             {
                 "equipo": P_EQUIPO,
                 "ruta": {"type": "string", "description": "Menú de RouterOS. Ej: 'ip/firewall/filter', 'interface/bridge/port', 'ip/dhcp-server/lease'."},
                 "accion": {"type": "string", "enum": list(cambios.ACCIONES)},
                 "id": {"type": "string", "description": "El .id del registro (ej. '*1A'). Obligatorio salvo para agregar."},
                 "valores": {"type": "object", "additionalProperties": {"type": ["string", "number", "boolean"]},
                             "description": "Campos a poner (para agregar o modificar), con los nombres de RouterOS. "
                                            "Ej: {\"disabled\": \"yes\", \"comment\": \"bloqueo temporal\"}."},
                 "motivo": {"type": "string", "description": "Explicación corta para el usuario: qué resuelve el cambio."},
             },
             ("equipo", "ruta", "accion", "motivo"), solo_lectura=False)
def mikrotik_cambiar(equipo: str, ruta: str, accion: str, motivo: str, id: str | None = None,
                     valores: dict[str, Any] | None = None) -> Any:
    if accion not in cambios.ACCIONES:
        raise ErrorNetTopo(f"Acción no válida: '{accion}'. Opciones: {', '.join(cambios.ACCIONES)}.")
    ruta = cambios.validar_ruta(ruta)
    valores = {str(k): ("yes" if v is True else "no" if v is False else str(v)) for k, v in (valores or {}).items()}
    if any(not re.fullmatch(r"[a-z0-9][a-z0-9\-.]*", campo) for campo in valores):
        raise ErrorNetTopo("Nombres de campo no válidos: usar los de RouterOS (ej. 'comment', 'disabled', 'src-address').")
    if accion in ("habilitar", "deshabilitar"):
        valores = {"disabled": "no" if accion == "habilitar" else "yes"}
    if accion in ("agregar", "modificar") and not valores:
        raise ErrorNetTopo(f"Para {accion} hacen falta 'valores'.")
    if accion == "eliminar":
        valores = {}

    datos = equipos.buscar(equipo)
    cliente = client_for(equipos.config_routeros(datos))
    antes: dict | None = None
    if accion != "agregar":
        id = cambios.validar_id(id)
        antes = _uno(_consultar(cliente, f"{ruta}/{id}"))
        if not antes:
            raise ErrorNetTopo(f"No existe el registro {id} en {ruta}.")

    def mostrar(campo: str, valor: Any) -> Any:
        return "***" if _sensible(campo) and valor not in ("", None) else valor

    resumen = {
        "equipo": datos.nombre, "host": datos.host, "accion": accion, "ruta": ruta, "id": id, "motivo": motivo,
        "cambios": {campo: (mostrar(campo, (antes or {}).get(campo)), mostrar(campo, valor)) for campo, valor in valores.items()},
    }
    if antes:
        resumen["descripcion"] = ", ".join(f"{c}={mostrar(c, antes[c])}" for c in
                                           ("name", "chain", "action", "src-address", "dst-address", "address",
                                            "mac-address", "interface", "comment") if antes.get(c))
    entrada = {"equipo": datos.nombre, "host": datos.host, "accion": accion, "ruta": ruta, "id": id,
               "valores": _tachar(valores), "motivo": motivo}

    if not cambios.confirmar(resumen):
        cambios.registrar({**entrada, "resultado": "cancelado por el usuario"})
        return {"aplicado": False, "nota": "El usuario canceló el cambio en la ventana de confirmación. No se tocó nada."}

    try:
        if accion == "agregar":
            despues = _uno(cliente.put(ruta, valores))
            id = despues.get(".id")
        elif accion == "eliminar":
            cliente.delete(f"{ruta}/{id}")
            despues = None
        else:
            cliente.patch(f"{ruta}/{id}", valores)
            despues = _uno(cliente.get(f"{ruta}/{id}"))
    except RouterOsRestError as exc:
        cambios.registrar({**entrada, "resultado": "error", "error": str(exc)})
        raise ErrorNetTopo(_error_escritura(exc)) from exc

    inversa = cambios.deshacer(accion, ruta, id, antes, despues)
    cambios.registrar({**entrada, "id": id, "resultado": "aplicado", "antes": _tachar(antes),
                       "despues": _tachar(despues), "deshacer": _tachar(inversa)})
    resultado: dict[str, Any] = {"aplicado": True, "antes": _tachar(antes, ruta), "despues": _tachar(despues, ruta)}
    if inversa:
        resultado["deshacer"] = _tachar(inversa)
    return resultado


@herramienta("Lista los últimos cambios de configuración hechos con NetTopo (aplicados, cancelados o con error), "
             "con fecha, equipo, motivo, estado anterior y cómo deshacerlos.",
             {"ultimos": {"type": "integer", "description": "Cuántos mostrar (por defecto 20)."}})
def cambios_listar(ultimos: int = 20) -> Any:
    registro = cambios.leer_registro(max(1, min(int(ultimos), 200)))
    if not registro:
        return {"cambios": [], "nota": "Todavía no se hizo ningún cambio con NetTopo."}
    return {"archivo": str(cambios.archivo_registro()), "cambios": registro}


@herramienta("Busca un host (por IP, MAC, nombre o comentario, coincidencia parcial) en las tablas ARP, "
             "DHCP y de MACs del bridge de un MikroTik. Dice en qué puerto y VLAN está conectado: sirve para "
             "responder '¿dónde está enchufada tal PC/impresora/cámara?'.",
             {"equipo": P_EQUIPO, "consulta": {"type": "string", "description": "IP, MAC, nombre o parte de ellos."}},
             ("equipo", "consulta"))
def mikrotik_buscar_host(equipo: str, consulta: str) -> Any:
    cliente = _cliente(equipo)
    texto = consulta.strip().lower()

    def coincide(registro: dict, *campos: str) -> bool:
        return any(texto in str(registro.get(campo, "")).lower() for campo in campos)

    try:
        leases = _consultar(cliente, "ip/dhcp-server/lease") or []
    except ErrorNetTopo:
        leases = []
    leases = [r for r in leases if coincide(r, "address", "active-address", "mac-address", "host-name", "comment")]
    macs = {str(r.get("mac-address", "")).upper() for r in leases if r.get("mac-address")}
    if re.fullmatch(r"[0-9a-f:\-]{4,}", texto):
        macs.add(texto.upper().replace("-", ":"))

    arp = [r for r in _consultar(cliente, "ip/arp") or []
           if coincide(r, "address", "mac-address", "comment") or str(r.get("mac-address", "")).upper() in macs]
    macs |= {str(r.get("mac-address", "")).upper() for r in arp if r.get("mac-address")}
    try:
        hosts_bridge = _consultar(cliente, "interface/bridge/host") or []
    except ErrorNetTopo:
        hosts_bridge = []
    puertos = [h for h in hosts_bridge if any(mac in str(h.get("mac-address", "")).upper() for mac in macs)]

    return {
        "arp": [_elegir(r, "address", "mac-address", "interface", "dynamic", "complete", "comment") for r in arp],
        "dhcp": [_elegir(r, "address", "active-address", "mac-address", "host-name", "server", "status",
                         "last-seen", "expires-after", "comment") for r in leases],
        "puerto_bridge": [_elegir(h, "mac-address", "on-interface", "vid", "bridge", "local", "external") for h in puertos],
        "nota": "puerto_bridge.on-interface es el puerto físico donde se aprendió la MAC; si hay varias MACs en "
                "ese puerto, probablemente haya un switch o AP en el medio." if puertos else
                "Ninguna MAC encontrada en la tabla del bridge (puede estar detrás de otro router o en otra VLAN/bridge).",
    }


@herramienta("Busca los MikroTik del segmento local por MNDP (como la pestaña Neighbors de WinBox), sin "
             "credenciales: identidad, IP, MAC, modelo, versión de RouterOS y uptime. Marca con un aviso los que "
             "tienen RouterOS menor a 7.1 (NetTopo no puede leerlos hasta actualizarlos).",
             {"segundos": {"type": "integer", "description": "Tiempo de escucha (por defecto 6; los equipos se anuncian solos cada 30-60 s)."}})
def mikrotik_descubrir(segundos: int = 6) -> Any:
    try:
        vecinos = mikrotik.descubrir_mndp(max(2, min(int(segundos), 90)))
    except OSError as exc:
        raise ErrorNetTopo(f"No se pudo escuchar MNDP (UDP 5678): {exc}") from exc
    for vecino in vecinos:
        vecino["rest_compatible"] = mikrotik.aviso_version(vecino.get("version")) is None
    resultado: dict[str, Any] = {"mikrotik": vecinos}
    avisos = _avisos_vecinos(vecinos)
    if avisos:
        resultado["avisos"] = avisos
    if not vecinos:
        resultado["nota"] = ("Ningún MikroTik respondió. Probá con más segundos, o revisá que la PC esté en la misma "
                             "VLAN y que el MikroTik tenga Neighbor Discovery habilitado en esa interfaz.")
    return resultado


# ── SNMP (HP/Aruba, TP-Link y otros) ──────────────────────────────────────────

@herramienta("Estado de un switch o AP por SNMP (v2c o v3, solo lectura): nombre, modelo/descripción, uptime, "
             "ubicación, interfaces (estado, velocidad, descripción, errores), IPs, VLANs y vecinos LLDP. Para "
             "equipos de tipo 'snmp' del inventario (HP/Aruba, TP-Link, etc.).",
             {"equipo": P_EQUIPO}, ("equipo",))
def snmp_resumen(equipo: str) -> Any:
    return snmp.resumen(equipo)


@herramienta("Busca una MAC o IP en la tabla de MACs de un switch por SNMP y dice en qué puerto y VLAN la aprendió "
             "(y cuántas MACs hay en ese puerto, para detectar otro switch o AP en el medio). Los switches de capa 2 "
             "no suelen tener ARP: para buscar por IP conviene sacar la MAC del router primero.",
             {"equipo": P_EQUIPO, "consulta": {"type": "string", "description": "MAC (completa o parcial) o IP."}},
             ("equipo", "consulta"))
def snmp_buscar_host(equipo: str, consulta: str) -> Any:
    return snmp.buscar_host(equipo, consulta)


# ── Controladores UniFi / Omada ───────────────────────────────────────────────

P_SITIO = {"type": "string", "description": "Opcional: sitio del controlador (nombre o id). Por defecto todos."}


@herramienta("Lee un controlador UniFi u Omada (solo lectura): sitios, equipos adoptados (APs, switches, gateways) "
             "con modelo, IP, MAC, estado, firmware, cantidad de clientes y a qué equipo/puerto se conectan.",
             {"equipo": {"type": "string", "description": "Nombre del controlador en el inventario."}, "sitio": P_SITIO},
             ("equipo",))
def controlador_resumen(equipo: str, sitio: str | None = None) -> Any:
    return controladores.resumen(equipo, sitio)


@herramienta("Busca un cliente (por nombre, IP, MAC o fabricante, coincidencia parcial) en un controlador UniFi u "
             "Omada y dice a qué AP (y SSID) o a qué switch y puerto está conectado, con su VLAN y señal.",
             {"equipo": {"type": "string", "description": "Nombre del controlador en el inventario."},
              "consulta": {"type": "string", "description": "Nombre, IP, MAC o parte de ellos."}, "sitio": P_SITIO},
             ("equipo", "consulta"))
def controlador_buscar_cliente(equipo: str, consulta: str, sitio: str | None = None) -> Any:
    return controladores.buscar_cliente(equipo, consulta, sitio)


# ── Relevamientos y topología ─────────────────────────────────────────────────

@herramienta("Releva la red a partir de un equipo del inventario. Desde un MikroTik: lee interfaces, IPs, VLANs, "
             "vecinos (MNDP/LLDP/CDP), tabla de MACs y ARP, y sigue por los MikroTik vecinos con las mismas "
             "credenciales. Desde un equipo SNMP: interfaces, IPs, tabla de MACs y vecinos LLDP. Desde un controlador "
             "UniFi u Omada: sus APs/switches/gateways, cómo se conectan entre sí y sus clientes. Guarda el "
             "relevamiento y devuelve el resumen de topología (equipos, enlaces, switches no administrables "
             "inferidos, VLANs y observaciones); topologia_ver lo muestra como mapa. Puede tardar un par de minutos.",
             {"equipo": P_EQUIPO,
              "profundidad": {"type": "integer", "description": "Saltos a recorrer entre MikroTik vecinos (0 = solo este; por defecto 1)."}},
             ("equipo",))
def red_relevar(equipo: str, profundidad: int = 1) -> Any:
    datos = equipos.buscar(equipo)
    if datos.tipo == "snmp":
        resultado_snmp = snmp.relevar(datos.nombre)
        resumen = _resumen(_guardar_snapshot(resultado_snmp.snapshot, datos.sitio or datos.nombre))
        if resultado_snmp.warnings:
            resumen["avisos"] = resultado_snmp.warnings
        return resumen
    if datos.tipo in ("unifi", "omada"):
        return _resumen(_guardar_snapshot(controladores.snapshot(datos.nombre), datos.sitio or datos.nombre))
    config = equipos.config_routeros(datos)
    try:
        resultado = collect_routeros_discovery(config, max_neighbor_depth=max(0, min(int(profundidad), 4)))
    except RouterOsRestError as exc:
        raise _error_rest(config, exc) from exc
    archivo = _guardar_snapshot(resultado.snapshot, config.site_name)
    resumen = _resumen(archivo)
    # Los vecinos con RouterOS 6 se leen por la API clásica: solo se avisa por los que fallaron
    # (warnings del recolector), con los pasos para dejarlos listos.
    avisos = list(resultado.warnings)
    if any("RouterOS API" in a for a in avisos):
        avisos.append("Si algún MikroTik con RouterOS 6 no se pudo leer: NetTopo usa su API clásica (servicio api, "
                      "puerto 8728) con las mismas credenciales; revisá que esté habilitada (/ip service print).")
    if avisos:
        resumen["avisos"] = avisos
    return resumen


@herramienta("Escanea la red local a la que está conectada esta PC (sin credenciales): ping/ARP, nmap, mDNS, "
             "SSDP, NetBIOS y LLDP; identifica fabricantes por MAC y puertos abiertos. Guarda el relevamiento "
             "y devuelve el resumen. Tarda entre 20 segundos y un par de minutos.",
             {"red": {"type": "string", "description": "Opcional: red a barrer en formato CIDR (por defecto la de la interfaz activa)."},
              "sitio": {"type": "string", "description": "Opcional: nombre del lugar para guardar el relevamiento."},
              "max_hosts": {"type": "integer", "description": "Opcional: tope de direcciones a barrer (por defecto 254)."}})
def red_escanear_local(red: str | None = None, sitio: str | None = None, max_hosts: int = 254) -> Any:
    ajustes: dict[str, Any] = {"max_hosts": max(1, min(int(max_hosts), 1024))}
    if red:
        ajustes["network_cidr"] = red
    nombre_sitio = sitio or "red-local"
    fuente = SourceConfig(type="local-discovery", name="nettopo-local", enabled=True, settings=ajustes)
    resultado = LocalDiscoveryAdapter(nombre_sitio, fuente, equipos.dir_datos()).collect()
    if resultado.snapshot is None:
        raise ErrorNetTopo("El escaneo no devolvió datos: " + "; ".join(resultado.warnings))
    archivo = _guardar_snapshot(resultado.snapshot, nombre_sitio)
    resumen = _resumen(archivo)
    if resultado.warnings:
        resumen["avisos"] = resultado.warnings
    return resumen


@herramienta("NetTopo Lab: arma una copia virtual de la red para probar cambios antes de hacerlos en los equipos "
             "reales. Recorre los MikroTik desde un equipo (solo lectura), reconstruye la configuración de cada uno "
             "(bridges, VLANs, IPs, DHCP, rutas, firewall; sin claves ni usuarios) y genera un laboratorio de "
             "containerlab con MikroTik CHR y los enlaces reales. No levanta nada: devuelve la carpeta y el comando "
             "(cylonnet-lab levantar). Con el laboratorio levantado, sus nodos aparecen en equipos_listar como "
             "'lab-<nodo>' y se pueden consultar y cambiar igual que los reales.",
             {"equipo": P_EQUIPO,
              "profundidad": {"type": "integer", "description": "Saltos a recorrer entre MikroTik vecinos (por defecto 1)."},
              "nombre": {"type": "string", "description": "Opcional: nombre del laboratorio (por defecto, el sitio del equipo)."},
              "version_chr": {"type": "string", "description": "Opcional: versión del CHR (por defecto la que se preparó con cylonnet-lab preparar)."}},
             ("equipo",))
def lab_generar(equipo: str, profundidad: int = 1, nombre: str | None = None, version_chr: str | None = None) -> Any:
    return lab.generar(equipo, profundidad, version_chr, nombre)


@herramienta("Devuelve el resumen de topología de un relevamiento guardado (por defecto el último).",
             {"archivo": {"type": "string", "description": "Opcional: nombre del archivo de relevamiento (ver relevamientos_listar)."}})
def topologia_resumen(archivo: str | None = None) -> Any:
    return _resumen(_archivo_snapshot(archivo))


@herramienta("Lista los relevamientos guardados, del más nuevo al más viejo.")
def relevamientos_listar() -> Any:
    carpeta = equipos.dir_datos() / "snapshots"
    archivos = sorted((a for a in carpeta.glob("*.json") if a.name != "ultimo.json"),
                      key=lambda a: a.stat().st_mtime, reverse=True) if carpeta.exists() else []
    return {"carpeta": str(carpeta), "relevamientos": [a.name for a in archivos]}


@herramienta("Exporta un relevamiento (por defecto el último) al formato JSON de NetPlanner, listo para "
             "'Importar JSON' en NetPlanner. Devuelve la ruta del archivo generado.",
             {"archivo": {"type": "string", "description": "Opcional: relevamiento a exportar."},
              "nombre": {"type": "string", "description": "Opcional: nombre de la topología en NetPlanner."}})
def topologia_exportar_netplanner(archivo: str | None = None, nombre: str | None = None) -> Any:
    origen = _archivo_snapshot(archivo)
    carpeta = equipos.dir_datos() / "netplanner"
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / f"{origen.stem if origen.name != 'ultimo.json' else 'ultimo'}-netplanner.json"
    argumentos = [str(DIR_JS / "export-netplanner.js"), "--input", str(origen), "--output", str(destino)]
    if nombre:
        argumentos += ["--topology-name", nombre]
    return {"salida": _node(*argumentos).strip(), "archivo": str(destino)}


def vista_html(archivo: str | None = None) -> Path:
    origen = _archivo_snapshot(archivo)
    carpeta = equipos.dir_datos() / "vista"
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / f"{origen.stem}.html"
    _node(str(DIR_JS / "vista.js"), str(origen), str(destino))
    return destino


@herramienta("Muestra un relevamiento (por defecto el último) como mapa interactivo en el navegador: equipos, "
             "enlaces con sus puertos, switches no administrables inferidos y, opcionalmente, los clientes. Genera "
             "un HTML que funciona sin internet y lo abre si hay escritorio.",
             {"archivo": {"type": "string", "description": "Opcional: relevamiento a mostrar (ver relevamientos_listar)."},
              "abrir": {"type": "boolean", "description": "Abrirlo en el navegador (por defecto sí)."}})
def topologia_ver(archivo: str | None = None, abrir: bool = True) -> Any:
    destino = vista_html(archivo)
    abierto = False
    if abrir and shutil.which("xdg-open") and (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        subprocess.Popen(["xdg-open", str(destino)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        abierto = True
    return {"archivo": str(destino), "abierto": abierto,
            "nota": "Se abrió en el navegador." if abierto else f"Abrilo con: xdg-open '{destino}'"}
