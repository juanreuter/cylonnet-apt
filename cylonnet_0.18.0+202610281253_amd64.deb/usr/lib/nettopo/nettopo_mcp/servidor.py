"""Servidor MCP de NetTopo por stdio (JSON-RPC 2.0, un mensaje por línea).

Implementación mínima sin dependencias: CylonNet no instala el SDK de MCP solo para esto.
Cubre lo que usa Claude Code: initialize, ping, tools/list y tools/call.
"""

from __future__ import annotations

import json
import sys
import traceback
from typing import Any

from . import __version__
from .equipos import ErrorNetTopo
from .herramientas import HERRAMIENTAS

VERSIONES = ("2025-06-18", "2025-03-26", "2024-11-05")

INSTRUCCIONES = """\
NetTopo da acceso a los equipos de red del usuario y a la red local: MikroTik (REST en 7.1+, API clásica en v6),
switches y APs por SNMP v2c/v3 (HP/Aruba, TP-Link...) y controladores UniFi y Omada (solo lectura).
- Empezá por equipos_listar para ver qué equipos hay, de qué tipo son y cómo se llaman.
- Las claves las carga el usuario desde la terminal (`nettopo equipo agregar NOMBRE IP`, con --snmp, --snmp3,
  --unifi u --omada según el equipo); nunca se las pidas en el chat.
- Para "¿dónde está conectado X?": mikrotik_buscar_host, snmp_buscar_host o controlador_buscar_cliente según el tipo.
- Para el mapa de la red: red_relevar (desde cualquier tipo de equipo) o red_escanear_local; topologia_ver lo abre
  como mapa interactivo en el navegador.
- La única herramienta que cambia algo es mikrotik_cambiar: un cambio por llamada, y el usuario lo confirma en una
  ventana propia de NetTopo (si cancela, no se toca nada). Antes, consultá el registro y explicá el cambio en el chat.
- Después de un cambio, verificá que funcionó; si algo salió mal, proponé la operación de "deshacer" que devuelve."""


def _respuesta(id_: Any, resultado: Any = None, error: dict | None = None) -> dict:
    mensaje: dict[str, Any] = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        mensaje["error"] = error
    else:
        mensaje["result"] = resultado
    return mensaje


def _llamar(nombre: str, argumentos: dict[str, Any]) -> dict:
    herramienta = HERRAMIENTAS.get(nombre)
    if herramienta is None:
        return {"content": [{"type": "text", "text": f"Herramienta desconocida: {nombre}"}], "isError": True}
    try:
        resultado = herramienta.funcion(**argumentos)
    except ErrorNetTopo as exc:
        return {"content": [{"type": "text", "text": str(exc)}], "isError": True}
    except TypeError as exc:
        return {"content": [{"type": "text", "text": f"Parámetros no válidos: {exc}"}], "isError": True}
    except Exception as exc:  # cualquier otra falla se informa a Claude en vez de cortar el servidor
        traceback.print_exc(file=sys.stderr)
        return {"content": [{"type": "text", "text": f"{type(exc).__name__}: {exc}"}], "isError": True}
    texto = resultado if isinstance(resultado, str) else json.dumps(resultado, ensure_ascii=False)
    return {"content": [{"type": "text", "text": texto}]}


def atender(mensaje: dict) -> dict | None:
    metodo = mensaje.get("method")
    id_ = mensaje.get("id")
    parametros = mensaje.get("params") or {}

    if id_ is None:  # notificación (initialized, cancelled...): no lleva respuesta
        return None
    if metodo == "initialize":
        pedida = parametros.get("protocolVersion")
        return _respuesta(id_, {
            "protocolVersion": pedida if pedida in VERSIONES else VERSIONES[0],
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "nettopo", "version": __version__},
            "instructions": INSTRUCCIONES,
        })
    if metodo == "ping":
        return _respuesta(id_, {})
    if metodo == "tools/list":
        return _respuesta(id_, {"tools": [h.definicion() for h in HERRAMIENTAS.values()]})
    if metodo == "tools/call":
        return _respuesta(id_, _llamar(parametros.get("name", ""), parametros.get("arguments") or {}))
    return _respuesta(id_, error={"code": -32601, "message": f"Método no soportado: {metodo}"})


def servir() -> int:
    # MCP va siempre en UTF-8, aunque el sistema use otra codificación por defecto
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    salida = sys.stdout
    sys.stdout = sys.stderr  # cualquier print del recolector va a stderr y no rompe el protocolo
    for linea in sys.stdin:
        if not linea.strip():
            continue
        try:
            mensaje = json.loads(linea)
        except json.JSONDecodeError as exc:
            respuesta = _respuesta(None, error={"code": -32700, "message": f"JSON inválido: {exc}"})
        else:
            respuesta = atender(mensaje)
        if respuesta is not None:
            salida.write(json.dumps(respuesta, ensure_ascii=False) + "\n")
            salida.flush()
    return 0
