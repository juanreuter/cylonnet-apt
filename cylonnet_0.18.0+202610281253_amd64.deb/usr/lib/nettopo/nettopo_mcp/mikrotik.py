"""Versión de RouterOS y diagnóstico de acceso REST.

NetTopo habla con los MikroTik por REST, que existe recién desde RouterOS 7.1 y necesita
el servicio www-ssl (o www) habilitado. Este módulo detecta equipos más viejos o sin el
servicio y arma el aviso con los pasos para dejarlos listos.
"""

from __future__ import annotations

import re
import socket
import ssl
import struct
import time
from urllib.request import Request, urlopen

VERSION_MINIMA = (7, 1)

PASOS_WWW_SSL = (
    "Para habilitar REST en el MikroTik (terminal o WinBox → New Terminal), limitando el acceso a tu red de gestión:\n"
    "  /certificate add name=rest common-name=rest days-valid=3650\n"
    "  /certificate sign rest\n"
    "  /ip service set www-ssl certificate=rest disabled=no address=<red de gestión, ej. 192.168.88.0/24>\n"
    "Para solo lectura conviene un usuario aparte:  /user add name=nettopo group=read password=<clave>"
)

PASOS_ACTUALIZAR = (
    "Actualizá a RouterOS 7 (System → Packages → Check For Updates, canal 'stable' o 'long-term' de la 7; "
    "en equipos con v6 viejas puede hacer falta pasar antes por la última 6.49). Hacé un backup antes "
    "(/system backup save y /export file=antes-v7) y revisá el firmware (/system routerboard upgrade)."
)


def version(texto: str | None) -> tuple[int, ...] | None:
    """'6.49.10 (long-term)' → (6, 49, 10)."""
    coincidencia = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", texto or "")
    if not coincidencia:
        return None
    return tuple(int(parte) for parte in coincidencia.groups() if parte is not None)


def aviso_version(texto: str | None, equipo: str = "") -> str | None:
    """Aviso para versiones menores a 7.1 (o None si la versión sirve o no se conoce)."""
    numeros = version(texto)
    if numeros is None or numeros[:2] >= VERSION_MINIMA:
        return None
    nombre = f"{equipo} tiene" if equipo else "El equipo tiene"
    return (f"⚠ {nombre} RouterOS {texto.strip()}: NetTopo necesita RouterOS 7.1 o más nuevo con el servicio "
            f"www-ssl habilitado (la API REST no existe en versiones anteriores).\n{PASOS_ACTUALIZAR}\n"
            f"Después:\n{PASOS_WWW_SSL}\n"
            f"Mientras tanto, NetTopo puede leerlo por la API clásica (servicio api, puerto 8728, habilitado de fábrica "
            f"en v6): nettopo equipo agregar NOMBRE IP --api  (o --api-ssl para el 8729 con TLS). En los relevamientos, "
            f"los vecinos con v6 se leen por la API automáticamente.")


def _puerto_abierto(host: str, puerto: int, espera: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, puerto), timeout=espera):
            return True
    except OSError:
        return False


def _version_webfig(host: str) -> str | None:
    """La página de inicio de WebFig muestra 'RouterOS v6.49.10'."""
    contexto = ssl._create_unverified_context()
    for url in (f"http://{host}/", f"https://{host}/"):
        try:
            with urlopen(Request(url, headers={"User-Agent": "NetTopo"}), timeout=4, context=contexto) as respuesta:
                html = respuesta.read(200_000).decode("utf-8", errors="replace")
        except Exception:
            continue
        coincidencia = re.search(r"RouterOS\s+v?(\d+\.\d+(?:\.\d+)?(?:\s*\([a-z\- ]+\))?)", html)
        if coincidencia:
            return coincidencia.group(1)
    return None


def diagnosticar(host: str, puerto: int, https: bool) -> str:
    """Explica por qué no responde REST: versión vieja, servicio apagado o equipo inalcanzable."""
    texto_version = _version_webfig(host)
    aviso = aviso_version(texto_version)
    if aviso:
        return aviso

    abiertos = [p for p in (puerto, 443, 80, 8728, 8729, 8291, 22) if _puerto_abierto(host, p)]
    abiertos = list(dict.fromkeys(abiertos))
    if not abiertos:
        return (f"{host} no responde en ningún puerto de gestión (REST, API, WinBox, SSH): revisá que sea "
                "alcanzable desde esta PC (ping, VLAN de gestión, firewall /ip service address).")
    if puerto in abiertos:
        detalle = f" (RouterOS {texto_version})" if texto_version else ""
        return (f"{host}{detalle} responde en el puerto {puerto} pero la API REST falló: revisá usuario y clave "
                "(nettopo equipo clave NOMBRE) y que el usuario tenga permiso 'rest-api' o 'api' en su grupo.")
    pista = f"Versión detectada: RouterOS {texto_version}. " if texto_version else (
        "No se pudo leer la versión; si es RouterOS 6 hay que actualizarlo a 7.1 o más nuevo. ")
    servicio = "www-ssl" if https else "www"
    return (f"{host} responde en {', '.join(map(str, abiertos))} pero no en {puerto} ({servicio}): "
            f"el servicio REST está apagado o restringido. {pista}\n{PASOS_WWW_SSL}")


# ── MNDP: descubrimiento de vecinos MikroTik (lo mismo que la pestaña Neighbors de WinBox) ──

_CAMPOS_MNDP = {1: "mac", 5: "identidad", 7: "version", 8: "plataforma", 10: "uptime", 11: "software_id",
                12: "placa", 16: "interfaz", 17: "ip"}


def _decodificar_mndp(datos: bytes) -> dict | None:
    if len(datos) <= 4:
        return None
    equipo: dict = {}
    posicion = 4
    while posicion + 4 <= len(datos):
        tipo, largo = struct.unpack_from(">HH", datos, posicion)
        valor = datos[posicion + 4: posicion + 4 + largo]
        posicion += 4 + largo
        campo = _CAMPOS_MNDP.get(tipo)
        if campo is None:
            continue
        if campo == "mac" and len(valor) == 6:
            equipo[campo] = ":".join(f"{b:02X}" for b in valor)
        elif campo == "ip" and len(valor) == 4:
            equipo[campo] = socket.inet_ntoa(valor)
        elif campo == "uptime" and len(valor) == 4:
            segundos = struct.unpack("<I", valor)[0]
            equipo[campo] = f"{segundos // 86400}d{segundos % 86400 // 3600}h{segundos % 3600 // 60}m"
        else:
            equipo[campo] = valor.decode("utf-8", errors="replace")
    return equipo or None


def descubrir_mndp(segundos: float = 5.0) -> list[dict]:
    """Pide anuncios MNDP por broadcast y escucha las respuestas de los MikroTik del segmento."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    encontrados: dict[str, dict] = {}
    try:
        sock.bind(("", 5678))
        sock.sendto(b"\x00\x00\x00\x00", ("255.255.255.255", 5678))
        limite = time.monotonic() + segundos
        while (restante := limite - time.monotonic()) > 0:
            sock.settimeout(restante)
            try:
                datos, (origen, _) = sock.recvfrom(4096)
            except socket.timeout:
                break
            equipo = _decodificar_mndp(datos)
            if equipo:
                equipo.setdefault("ip", origen)
                encontrados[equipo.get("mac") or origen] = equipo
    finally:
        sock.close()
    return list(encontrados.values())
