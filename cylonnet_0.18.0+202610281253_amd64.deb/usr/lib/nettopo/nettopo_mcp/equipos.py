"""Inventario de equipos de NetTopo y sus claves.

Los datos de cada equipo van en ~/.config/nettopo/equipos.json; las claves, en el llavero
del sistema (Secret Service vía secret-tool, que en Plasma atiende KWallet). Si no hay
llavero se guardan en ~/.config/nettopo/claves.json con permisos 600. Ninguna función de
este módulo que use el MCP devuelve claves: solo se usan para hablar con los equipos.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, fields
import json
import os
from pathlib import Path
import shutil
import subprocess

from topology_collector.config import RouterOsConfig
from topology_collector.snmp_client import SnmpTargetConfig

# Tipos de equipo: MikroTik (REST o API), cualquier switch/AP por SNMP (HP/Aruba, TP-Link...) y los
# controladores UniFi y Omada (se consultan por su API web; los equipos los maneja el controlador).
TIPOS = ("mikrotik", "snmp", "unifi", "omada")


class ErrorNetTopo(RuntimeError):
    """Error que se le muestra tal cual al usuario (o a Claude)."""


@dataclass(slots=True)
class Equipo:
    nombre: str
    host: str
    tipo: str = "mikrotik"
    usuario: str = "admin"
    puerto: int = 443
    https: bool = True
    verificar_tls: bool = False
    sitio: str = ""
    api: bool = False  # API clásica (RouterOS 6): puerto = 8728/8729 y https = TLS
    # SNMP: versión "2c" (la clave es la comunidad) o "3" (usuario = security name; la clave guarda
    # las frases de autenticación y cifrado)
    snmp_version: str = "2c"
    snmp_auth: str = "SHA"
    snmp_priv: str = "AES"
    # Controladores UniFi/Omada: sitio del controlador a consultar ("" = todos)
    sitio_controlador: str = ""

    def publico(self) -> dict:
        return asdict(self) | {"tiene_clave": leer_clave(self.nombre) is not None}


def _base(variable: str, por_defecto: str) -> Path:
    if os.environ.get("NETTOPO_INICIO"):
        return Path(os.environ["NETTOPO_INICIO"]) / Path(por_defecto).name
    return Path(os.environ.get(variable) or Path.home() / por_defecto) / "nettopo"


def dir_config() -> Path:
    return _base("XDG_CONFIG_HOME", ".config")


def dir_datos() -> Path:
    return _base("XDG_DATA_HOME", ".local/share")


def _archivo_equipos() -> Path:
    return dir_config() / "equipos.json"


def cargar() -> list[Equipo]:
    archivo = _archivo_equipos()
    if not archivo.exists():
        return []
    datos = json.loads(archivo.read_text(encoding="utf-8"))
    validos = {campo.name for campo in fields(Equipo)}
    return [Equipo(**{k: v for k, v in item.items() if k in validos}) for item in datos.get("equipos", [])]


def _guardar(equipos: list[Equipo]) -> None:
    archivo = _archivo_equipos()
    archivo.parent.mkdir(parents=True, exist_ok=True)
    contenido = {"equipos": [asdict(equipo) for equipo in equipos]}
    archivo.write_text(json.dumps(contenido, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def buscar(nombre_o_host: str) -> Equipo:
    clave = nombre_o_host.strip().lower()
    for equipo in cargar():
        if clave in (equipo.nombre.lower(), equipo.host.lower()):
            return equipo
    disponibles = ", ".join(equipo.nombre for equipo in cargar()) or "ninguno"
    raise ErrorNetTopo(
        f"No hay ningún equipo '{nombre_o_host}' en el inventario (cargados: {disponibles}). "
        "Se agregan desde la terminal con: nettopo equipo agregar NOMBRE IP"
    )


def agregar(equipo: Equipo, clave: str | None) -> None:
    equipos = [e for e in cargar() if e.nombre.lower() != equipo.nombre.lower()]
    equipos.append(equipo)
    _guardar(sorted(equipos, key=lambda e: (e.sitio, e.nombre)))
    if clave is not None:
        guardar_clave(equipo.nombre, clave)


def quitar(nombre: str) -> None:
    equipo = buscar(nombre)
    _guardar([e for e in cargar() if e.nombre != equipo.nombre])
    borrar_clave(equipo.nombre)


# ── Claves ────────────────────────────────────────────────────────────────────

def _hay_llavero() -> bool:
    return bool(shutil.which("secret-tool") and os.environ.get("DBUS_SESSION_BUS_ADDRESS"))


def _atributos(nombre: str) -> list[str]:
    return ["aplicacion", "nettopo", "equipo", nombre]


def _archivo_claves() -> Path:
    return dir_config() / "claves.json"


def _leer_archivo_claves() -> dict[str, str]:
    archivo = _archivo_claves()
    if not archivo.exists():
        return {}
    return json.loads(archivo.read_text(encoding="utf-8"))


def _escribir_archivo_claves(claves: dict[str, str]) -> None:
    archivo = _archivo_claves()
    archivo.parent.mkdir(parents=True, exist_ok=True)
    archivo.touch(mode=0o600, exist_ok=True)
    os.chmod(archivo, 0o600)
    archivo.write_text(json.dumps(claves, indent=2) + "\n", encoding="utf-8")


def guardar_clave(nombre: str, clave: str) -> str:
    """Guarda la clave y devuelve dónde quedó ('llavero' o 'archivo')."""
    if _hay_llavero():
        resultado = subprocess.run(
            ["secret-tool", "store", f"--label=NetTopo: {nombre}", *_atributos(nombre)],
            input=clave, text=True, capture_output=True, timeout=60,
        )
        if resultado.returncode == 0:
            claves = _leer_archivo_claves()
            if claves.pop(nombre, None) is not None:
                _escribir_archivo_claves(claves)
            return "llavero"
    claves = _leer_archivo_claves()
    claves[nombre] = clave
    _escribir_archivo_claves(claves)
    return "archivo"


def leer_clave(nombre: str) -> str | None:
    if _hay_llavero():
        resultado = subprocess.run(
            ["secret-tool", "lookup", *_atributos(nombre)],
            text=True, capture_output=True, timeout=60,
        )
        if resultado.returncode == 0 and resultado.stdout:
            return resultado.stdout
    return _leer_archivo_claves().get(nombre)


def borrar_clave(nombre: str) -> None:
    if _hay_llavero():
        subprocess.run(["secret-tool", "clear", *_atributos(nombre)], capture_output=True, timeout=60)
    claves = _leer_archivo_claves()
    if claves.pop(nombre, None) is not None:
        _escribir_archivo_claves(claves)


def _clave_obligatoria(equipo: Equipo) -> str:
    clave = leer_clave(equipo.nombre)
    if clave is None:
        raise ErrorNetTopo(
            f"'{equipo.nombre}' no tiene clave guardada. El usuario la carga desde la terminal con: "
            f"nettopo equipo clave {equipo.nombre}"
        )
    return clave


def claves_snmp3(auth: str, priv: str) -> str:
    """Las dos frases de SNMP v3 se guardan juntas, como una sola clave."""
    return json.dumps({"auth": auth, "priv": priv})


def config_snmp(equipo: Equipo) -> SnmpTargetConfig:
    if equipo.tipo != "snmp":
        raise ErrorNetTopo(f"'{equipo.nombre}' es de tipo {equipo.tipo}; esta herramienta es para equipos SNMP.")
    clave = _clave_obligatoria(equipo)
    config = SnmpTargetConfig(host=equipo.host, port=equipo.puerto or 161, version=equipo.snmp_version,
                              timeout_seconds=3, retries=1)
    if equipo.snmp_version == "3":
        try:
            frases = json.loads(clave)
        except ValueError:
            frases = {"auth": clave, "priv": ""}
        config.security_name = equipo.usuario
        config.auth_protocol, config.auth_password = equipo.snmp_auth, frases.get("auth", "")
        config.priv_protocol, config.priv_password = equipo.snmp_priv, frases.get("priv", "")
    else:
        config.community = clave
    return config


def config_routeros(equipo: Equipo) -> RouterOsConfig:
    if equipo.tipo != "mikrotik":
        raise ErrorNetTopo(f"'{equipo.nombre}' es de tipo {equipo.tipo}; esta herramienta es solo para MikroTik.")
    clave = _clave_obligatoria(equipo)
    return RouterOsConfig(
        site_name=equipo.sitio or equipo.nombre,
        host=equipo.host,
        username=equipo.usuario,
        password=clave,
        verify_tls=equipo.verificar_tls,
        timeout_seconds=15,
        vendor="MikroTik",
        rest_port=equipo.puerto if not equipo.api else 443,
        rest_https=equipo.https if not equipo.api else None,
        protocol="api" if equipo.api else "rest",
        api_port=equipo.puerto if equipo.api else 0,
        api_tls=equipo.https if equipo.api else False,
    )
