"""NetTopo Lab: copia virtual de la red relevada, para probar cambios antes de aplicarlos.

Recorre los MikroTik desde un equipo (solo lectura), reconstruye la configuración de cada uno como
script de RouterOS (.rsc) y arma la topología de containerlab con los enlaces reales entre ellos.
Cada equipo pasa a ser un MikroTik CHR (imagen vrnetlab): sus puertos se renombran igual que en
el equipo real, así la configuración se aplica sin cambios.

Qué NO se copia: claves y usuarios, PPP, IPsec, WireGuard, Wi-Fi, certificados, scripts y tareas.
Los switches no administrables y las PC no se replican (se pueden agregar como nodos linux).
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime
import json
import os
from pathlib import Path
import re
from typing import Any

from topology_collector.config import RouterOsConfig
from topology_collector.routeros_api import client_for
from topology_collector.routeros_discovery import _neighbor_protocol
from topology_collector.routeros_rest import RouterOsRestError

from . import equipos
from .equipos import Equipo, ErrorNetTopo

VERSION_CHR = "7.16.2"
RED_GESTION = "172.31.200"  # containerlab: red de gestión de los nodos (.11, .12, ...)
MAX_PUERTOS = 31            # placas de red de datos que tiene un CHR de vrnetlab (ether2..ether32)
CLAVE_LAB = "admin"         # usuario y clave de los CHR de vrnetlab

TIPOS_FISICOS = {"ether", "wlan", "wifi", "wireless"}
SOLO_LECTURA = {".id", ".nextid", ".about", "bytes", "packets", "dynamic", "invalid", "builtin", "running",
                "inactive", "active", "default", "slave", "status", "hw-offload", "hw", "debug-info"}
SECRETO = re.compile(r"password|secret|passphrase|private-key|pre-shared-key|psk", re.I)

# (ruta REST, menú del script, campos a copiar o None = todos menos los de solo lectura)
MENUS: list[tuple[str, str, list[str] | None]] = [
    ("interface/bridge", "/interface bridge", ["name", "vlan-filtering", "protocol-mode", "pvid", "frame-types", "comment", "disabled"]),
    ("interface/vlan", "/interface vlan", ["name", "vlan-id", "interface", "comment", "disabled"]),
    ("interface/list", "/interface list", ["name", "comment"]),
    ("interface/list/member", "/interface list member", ["list", "interface", "comment", "disabled"]),
    ("interface/bridge/port", "/interface bridge port", ["bridge", "interface", "pvid", "frame-types", "ingress-filtering", "comment", "disabled"]),
    ("interface/bridge/vlan", "/interface bridge vlan", ["bridge", "vlan-ids", "tagged", "untagged", "comment", "disabled"]),
    ("ip/address", "/ip address", ["address", "interface", "network", "comment", "disabled"]),
    ("ip/pool", "/ip pool", ["name", "ranges", "next-pool", "comment"]),
    ("ip/dhcp-server", "/ip dhcp-server", ["name", "interface", "address-pool", "lease-time", "comment", "disabled"]),
    ("ip/dhcp-server/network", "/ip dhcp-server network", ["address", "gateway", "dns-server", "domain", "netmask", "comment"]),
    ("ip/dhcp-client", "/ip dhcp-client", ["interface", "add-default-route", "use-peer-dns", "default-route-distance", "comment", "disabled"]),
    ("ip/route", "/ip route", ["dst-address", "gateway", "distance", "routing-table", "check-gateway", "comment", "disabled"]),
    ("ip/firewall/address-list", "/ip firewall address-list", ["list", "address", "comment", "disabled"]),
    ("ip/firewall/filter", "/ip firewall filter", None),
    ("ip/firewall/nat", "/ip firewall nat", None),
    ("ip/firewall/mangle", "/ip firewall mangle", None),
]


def _slug(texto: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(texto).lower()).strip("-") or "equipo"


def _valor(valor: Any) -> str:
    texto = str(valor)
    if texto in ("true", "false"):
        return "yes" if texto == "true" else "no"
    if re.fullmatch(r"[A-Za-z0-9._:/,*+\-]+", texto):
        return texto
    return '"' + texto.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$") + '"'


def _verdadero(valor: Any) -> bool:
    return str(valor).lower() in ("true", "yes")


def _lineas_menu(registros: list[dict], campos: list[str] | None) -> list[str]:
    lineas = []
    for r in registros:
        if _verdadero(r.get("dynamic")) or _verdadero(r.get("builtin")) or _verdadero(r.get("default")):
            continue
        if "special dummy rule" in str(r.get("comment", "")):
            continue
        partes = []
        for campo, valor in r.items():
            if campos is not None and campo not in campos:
                continue
            if campo in SOLO_LECTURA or SECRETO.search(campo) or valor in ("", None):
                continue
            if campo == "disabled" and not _verdadero(valor):
                continue
            partes.append(f"{campo}={_valor(valor)}")
        if partes:
            lineas.append("add " + " ".join(partes))
    return lineas


def _fisicas(interfaces: list[dict]) -> list[dict]:
    return [i for i in interfaces if i.get("type") in TIPOS_FISICOS and not _verdadero(i.get("dynamic"))]


def leer_equipo(cliente: Any) -> dict[str, Any]:
    """Todo lo que hace falta de un MikroTik para replicarlo (solo lecturas)."""
    identidad = cliente.fetch_identity().get("name") or cliente.config.host
    recursos = cliente.fetch_resource()
    interfaces = cliente.fetch_interfaces()
    datos: dict[str, Any] = {
        "identidad": identidad, "host": cliente.config.host, "version": recursos.get("version", ""),
        "placa": recursos.get("board-name", ""), "interfaces": interfaces, "vecinos": cliente.fetch_neighbors(),
        "menus": {}, "avisos": [],
    }
    for ruta, _, _ in MENUS:
        try:
            datos["menus"][ruta] = cliente.get(ruta) or []
        except RouterOsRestError as exc:  # menú que no existe en esa versión o placa
            datos["menus"][ruta] = []
            if "HTTP 400" not in str(exc) and "HTTP 404" not in str(exc):
                datos["avisos"].append(f"{identidad}: no se pudo leer {ruta} ({exc})")
    try:
        dns = cliente.get("ip/dns")
        datos["dns"] = dns[0] if isinstance(dns, list) and dns else (dns or {})
    except RouterOsRestError:
        datos["dns"] = {}
    return datos


def _seguro(comando: str) -> str:
    """Cada línea va sola: si falla (algo que el laboratorio no tiene), queda en el log y el import sigue.
    Sin esto, una sola línea con error corta todo el /import."""
    resumen = re.sub(r'["$\\{}\[\]]', "", comando)[:90]
    return f':do {{ {comando} }} on-error={{ :log warning "NetTopo Lab: no se aplico: {resumen}" }}'


def script_rsc(datos: dict[str, Any], version_chr: str) -> tuple[str, list[str]]:
    """Script de RouterOS que reproduce el equipo en un CHR. Devuelve (script, puertos físicos en orden)."""
    fisicas = _fisicas(datos["interfaces"])
    puertos = [i["name"] for i in fisicas[:MAX_PUERTOS]]
    lineas = [
        f"# NetTopo Lab: {datos['identidad']} ({datos['placa']}, RouterOS {datos['version']})",
        f"# Generado el {datetime.now():%d/%m/%Y %H:%M} desde {datos['host']}, para un CHR {version_chr}.",
        "# No incluye claves, usuarios, PPP, IPsec, WireGuard, Wi-Fi, certificados, scripts ni tareas.",
        "# ether1 del CHR es la gestión del laboratorio (se llama 'mgmt'); los puertos del equipo real",
        "# van en ether2, ether3... con el mismo nombre que tienen en el equipo.",
        "# Las líneas que no se puedan aplicar quedan en el log: /log print where message~\"NetTopo Lab\"",
        "",
        _seguro(f"/system identity set name={_valor(datos['identidad'])}"),
        _seguro("/interface ethernet set [find default-name=ether1] name=mgmt"),
    ]
    for n, interfaz in enumerate(fisicas[:MAX_PUERTOS], start=2):
        extra = f" comment={_valor(interfaz['comment'])}" if interfaz.get("comment") else ""
        estado = " disabled=yes" if _verdadero(interfaz.get("disabled")) else ""
        lineas.append(_seguro(f"/interface ethernet set [find default-name=ether{n}] name={_valor(interfaz['name'])}{extra}{estado}"))
    if len(fisicas) > MAX_PUERTOS:
        lineas.append(f"# Aviso: el equipo tiene {len(fisicas)} puertos; el CHR solo tiene {MAX_PUERTOS} (se omitieron los demás).")
    for ruta, menu, campos in MENUS:
        cuerpo = _lineas_menu(datos["menus"].get(ruta, []), campos)
        if ruta == "ip/firewall/filter":
            # Primero de todo: que el firewall copiado (p. ej. "drop todo lo que no venga de LAN") no corte
            # la gestión del laboratorio.
            cuerpo.insert(0, 'add chain=input in-interface=mgmt action=accept comment="NetTopo Lab: gestion"')
        if cuerpo:
            lineas += ["", f"# {menu}", *(_seguro(f"{menu} {linea}") for linea in cuerpo)]
    dns = {k: v for k, v in datos.get("dns", {}).items() if k in ("servers", "allow-remote-requests") and v not in ("", None)}
    if dns:
        lineas += ["", _seguro("/ip dns set " + " ".join(f"{k}={_valor(v)}" for k, v in dns.items()))]
    lineas += ["", ':log info "NetTopo Lab: configuracion importada"']
    return "\n".join(lineas) + "\n", puertos


def recorrer(inicial: RouterOsConfig, profundidad: int) -> tuple[list[dict], list[str]]:
    """Lee el equipo inicial y los MikroTik vecinos hasta 'profundidad' saltos."""
    equipos_leidos: list[dict] = []
    avisos: list[str] = []
    visitados: set[str] = set()
    pendientes = [(inicial, 0)]
    while pendientes:
        config, nivel = pendientes.pop(0)
        if config.host in visitados:
            continue
        visitados.add(config.host)
        cliente = client_for(config)
        try:
            datos = leer_equipo(cliente)
        except RouterOsRestError as exc:
            avisos.append(f"No se pudo leer {config.host}: {exc}")
            continue
        finally:
            if hasattr(cliente, "close"):
                cliente.close()
        if any(d["identidad"] == datos["identidad"] for d in equipos_leidos):
            continue  # el mismo equipo visto por otra IP
        equipos_leidos.append(datos)
        avisos += datos.pop("avisos")
        if nivel >= profundidad:
            continue
        for vecino in datos["vecinos"]:
            ip = vecino.get("address") or vecino.get("address4")
            texto = f"{vecino.get('platform', '')} {vecino.get('board', '')} {vecino.get('version', '')}".lower()
            if ip and ip not in visitados and ("mikrotik" in texto or "routeros" in texto):
                pendientes.append((replace(config, host=ip, protocol=_neighbor_protocol(vecino, config),
                                           rest_port=config.rest_port if config.protocol == "rest" else 443,
                                           rest_https=config.rest_https if config.protocol == "rest" else None),
                                   nivel + 1))
    return equipos_leidos, avisos


def _puerto_fisico(nombre: str, puertos: list[str]) -> str | None:
    for parte in str(nombre or "").split(","):
        if parte.strip() in puertos:
            return parte.strip()
    return None


def enlaces(leidos: list[dict], puertos: dict[str, list[str]]) -> tuple[list[tuple[str, str, str, str]], list[str]]:
    """Enlaces entre los equipos leídos, con el puerto de cada lado (por la tabla de vecinos de los dos)."""
    por_identidad = {d["identidad"]: d for d in leidos}
    macs = {d["identidad"]: {str(i.get("mac-address", "")).upper(): i["name"] for i in d["interfaces"] if i.get("mac-address")}
            for d in leidos}
    resultado: dict[frozenset, tuple[str, str, str, str]] = {}
    incompletos: set[frozenset] = set()
    for d in leidos:
        a = d["identidad"]
        for vecino in d["vecinos"]:
            b = vecino.get("identity")
            mac = str(vecino.get("mac-address", "")).upper()
            if b not in por_identidad:
                b = next((otro for otro, tabla in macs.items() if mac in tabla), None)
            if not b or b == a:
                continue
            puerto_a = _puerto_fisico(vecino.get("interface"), puertos[a])
            # Del otro lado: su entrada de vecino que nos ve a nosotros, o el puerto dueño de la MAC anunciada
            puerto_b = None
            for v in por_identidad[b]["vecinos"]:
                if v.get("identity") == a or str(v.get("mac-address", "")).upper() in macs[a]:
                    puerto_b = _puerto_fisico(v.get("interface"), puertos[b])
                    if puerto_b:
                        break
            puerto_b = puerto_b or _puerto_fisico(macs[b].get(mac), puertos[b])
            clave = frozenset((a, b))
            if clave in resultado:
                continue
            if puerto_a and puerto_b:
                resultado[clave] = (a, puerto_a, b, puerto_b)
            else:
                incompletos.add(clave)
    avisos = [f"Enlace {' ↔ '.join(sorted(par))}: no se supo el puerto de los dos lados; no se agregó al laboratorio."
              for par in incompletos if par not in resultado]
    return list(resultado.values()), avisos


def carpeta_labs() -> Path:
    if os.environ.get("NETTOPO_INICIO"):
        return equipos.dir_datos() / "labs"
    return Path.home() / "NetTopo" / "labs"


def version_chr_configurada() -> str:
    archivo = equipos.dir_config() / "lab.json"
    try:
        return json.loads(archivo.read_text(encoding="utf-8")).get("version_chr") or VERSION_CHR
    except (OSError, ValueError):
        return VERSION_CHR


def generar(equipo: str, profundidad: int = 1, version_chr: str | None = None, nombre: str | None = None) -> dict[str, Any]:
    datos_equipo = equipos.buscar(equipo)
    inicial = equipos.config_routeros(datos_equipo)
    version_chr = version_chr or version_chr_configurada()
    leidos, avisos = recorrer(inicial, max(0, min(int(profundidad), 4)))
    if not leidos:
        raise ErrorNetTopo("No se pudo leer ningún equipo: " + "; ".join(avisos))

    nombre_lab = _slug(nombre or datos_equipo.sitio or leidos[0]["identidad"])
    carpeta = carpeta_labs() / nombre_lab
    carpeta.mkdir(parents=True, exist_ok=True)
    nodos: dict[str, dict[str, Any]] = {}
    puertos: dict[str, list[str]] = {}
    for n, d in enumerate(leidos):
        nodo = _slug(d["identidad"])
        while nodo in nodos:
            nodo += "-2"
        script, puertos[d["identidad"]] = script_rsc(d, version_chr)
        (carpeta / f"{nodo}.rsc").write_text(script, encoding="utf-8")
        nodos[nodo] = {"identidad": d["identidad"], "real": d["host"], "version_real": d["version"],
                       "gestion": f"{RED_GESTION}.{11 + n}", "puertos": puertos[d["identidad"]]}
    nodo_de = {v["identidad"]: k for k, v in nodos.items()}
    lista_enlaces, avisos_enlaces = enlaces(leidos, puertos)
    avisos += avisos_enlaces

    def eth(identidad: str, puerto: str) -> str:
        return f"{nodo_de[identidad]}:eth{puertos[identidad].index(puerto) + 1}"

    yml = [f"# NetTopo Lab '{nombre_lab}': generado el {datetime.now():%d/%m/%Y %H:%M} desde {datos_equipo.nombre}.",
           "# Levantar: cylonnet-lab levantar " + str(carpeta),
           f"name: {nombre_lab}",
           "mgmt:",
           "  network: nettopo-lab",
           f"  ipv4-subnet: {RED_GESTION}.0/24",
           "topology:",
           "  kinds:",
           "    mikrotik_ros:",
           f"      image: vrnetlab/mikrotik_routeros:{version_chr}",
           "  nodes:"]
    for nodo, info in nodos.items():
        yml += [f"    {nodo}:  # {info['identidad']} (real: {info['real']}, RouterOS {info['version_real']})",
                "      kind: mikrotik_ros",
                f"      mgmt-ipv4: {info['gestion']}",
                f"      startup-config: {nodo}.rsc"]
    yml.append("  links:" if lista_enlaces else "  links: []")
    for a, pa, b, pb in lista_enlaces:
        yml.append(f'    - endpoints: ["{eth(a, pa)}", "{eth(b, pb)}"]  # {a} {pa} <-> {b} {pb}')
    (carpeta / f"{nombre_lab}.clab.yml").write_text("\n".join(yml) + "\n", encoding="utf-8")

    info_lab = {"nombre": nombre_lab, "version_chr": version_chr, "generado": datetime.now().isoformat(timespec="seconds"),
                "desde": datos_equipo.nombre, "nodos": nodos,
                "enlaces": [{"de": a, "puerto_de": pa, "a": b, "puerto_a": pb} for a, pa, b, pb in lista_enlaces]}
    (carpeta / "nodos.json").write_text(json.dumps(info_lab, indent=2, ensure_ascii=False), encoding="utf-8")
    (carpeta / "LEEME.md").write_text(_leeme(nombre_lab, carpeta, nodos, lista_enlaces, avisos), encoding="utf-8")
    return {"carpeta": str(carpeta), "topologia": str(carpeta / f"{nombre_lab}.clab.yml"),
            "nodos": {k: {"equipo_real": v["identidad"], "gestion_lab": v["gestion"], "puertos": len(v["puertos"])}
                      for k, v in nodos.items()},
            "enlaces": [f"{a} {pa} <-> {b} {pb}" for a, pa, b, pb in lista_enlaces],
            "avisos": avisos,
            "siguiente": f"cylonnet-lab levantar {carpeta}  (la primera vez: cylonnet-lab preparar)"}


def _leeme(nombre: str, carpeta: Path, nodos: dict, lista_enlaces: list, avisos: list[str]) -> str:
    filas = "\n".join(f"| {n} | {v['identidad']} | {v['real']} | {v['gestion']} |" for n, v in nodos.items())
    lineas_enlaces = "\n".join(f"- {a} {pa} ↔ {b} {pb}" for a, pa, b, pb in lista_enlaces) or "- (ninguno)"
    lineas_avisos = "\n".join(f"- {a}" for a in avisos) or "- (ninguno)"
    return f"""# NetTopo Lab: {nombre}

Copia virtual de la red para probar cambios antes de hacerlos en los equipos reales.

| Nodo | Equipo real | IP real | Gestión en el laboratorio |
|---|---|---|---|
{filas}

Enlaces:
{lineas_enlaces}

Avisos:
{lineas_avisos}

## Uso
- La primera vez: `cylonnet-lab preparar` (instala Docker, containerlab y la imagen del MikroTik CHR).
- Levantar: `cylonnet-lab levantar {carpeta}` (tarda un par de minutos; registra los nodos en NetTopo como `lab-<nodo>`).
- Bajar: `cylonnet-lab bajar {carpeta}`.
- Entrar a un nodo: WinBox o `ssh admin@<gestión>` (clave `admin`).

Cada `.rsc` es la configuración reconstruida del equipo real (sin claves ni usuarios). Los puertos del CHR
tienen el mismo nombre que en el equipo real; `mgmt` es la gestión del laboratorio.
"""


def registrar(carpeta: str) -> list[str]:
    """Agrega los nodos del laboratorio al inventario de NetTopo como 'lab-<nodo>'."""
    info = json.loads((Path(carpeta) / "nodos.json").read_text(encoding="utf-8"))
    agregados = []
    for nodo, datos in info["nodos"].items():
        nombre = f"lab-{nodo}"
        equipos.agregar(Equipo(nombre=nombre, host=datos["gestion"], usuario="admin", puerto=80, https=False,
                               sitio=f"Lab {info['nombre']}"), None)
        equipos.guardar_clave(nombre, CLAVE_LAB)
        agregados.append(nombre)
    return agregados


def olvidar(carpeta: str) -> list[str]:
    info = json.loads((Path(carpeta) / "nodos.json").read_text(encoding="utf-8"))
    quitados = []
    for nodo in info["nodos"]:
        try:
            equipos.quitar(f"lab-{nodo}")
            quitados.append(f"lab-{nodo}")
        except ErrorNetTopo:
            pass
    return quitados
