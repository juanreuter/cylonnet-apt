"""Comando `nettopo`: inventario de equipos y servidor MCP.

    nettopo equipo agregar NOMBRE IP [--usuario U] [--puerto P] [--http | --api | --api-ssl] [--sitio S] [--verificar-tls]
    nettopo equipo agregar NOMBRE IP --snmp            switch/AP por SNMP v2c (pide la comunidad)
    nettopo equipo agregar NOMBRE IP --snmp3 --usuario U [--auth SHA] [--priv AES]   SNMP v3
    nettopo equipo agregar NOMBRE URL --unifi|--omada --usuario U [--sitio-controlador S]   controlador
    nettopo equipo clave NOMBRE        cambia la clave guardada
    nettopo equipo listar
    nettopo equipo probar NOMBRE       consulta la identidad del equipo
    nettopo equipo quitar NOMBRE
    nettopo descubrir [SEGUNDOS]       MikroTik del segmento por MNDP (avisa si son menores a 7.1)
    nettopo cambios [N]                últimos cambios hechos en los equipos (con cómo deshacerlos)
    nettopo ver [ARCHIVO]              abre el último relevamiento como mapa en el navegador
    nettopo lab generar EQUIPO [--profundidad N] [--nombre X] [--version-chr V]
    nettopo lab registrar|olvidar CARPETA   agrega o quita los nodos del laboratorio del inventario
    nettopo mcp                        servidor MCP por stdio (lo arranca Claude Code)
"""

from __future__ import annotations

import argparse
from getpass import getpass
import json
import sys

from . import equipos
from .equipos import Equipo, ErrorNetTopo
from topology_collector.snmp_client import AUTH_PROTOCOLS, PRIV_PROTOCOLS


def _pedir_clave(nombre: str, que: str = "Clave") -> str:
    if sys.stdin.isatty():
        clave = getpass(f"{que} de {nombre} (no se muestra): ")
    else:  # desde un script: la clave llega por la entrada estándar
        clave = sys.stdin.readline().rstrip("\n")
    if not clave:
        raise ErrorNetTopo("No se ingresó ninguna clave.")
    return clave


def _claves(equipo: Equipo) -> str:
    if equipo.tipo == "snmp" and equipo.snmp_version == "3":
        auth = _pedir_clave(equipo.nombre, f"Frase de autenticación ({equipo.snmp_auth})")
        if sys.stdin.isatty():
            priv = getpass(f"Frase de cifrado ({equipo.snmp_priv}) de {equipo.nombre} (Enter = sin cifrado): ")
        else:
            priv = sys.stdin.readline().rstrip("\n")
        return equipos.claves_snmp3(auth, priv)
    return _pedir_clave(equipo.nombre, "Comunidad SNMP" if equipo.tipo == "snmp" else "Clave")


def _agregar(args: argparse.Namespace) -> None:
    api = args.api or args.api_ssl
    tipo = "snmp" if args.snmp or args.snmp3 else "unifi" if args.unifi else "omada" if args.omada else "mikrotik"
    if tipo == "snmp":
        puerto, cifrado = args.puerto or 161, False
    elif tipo in ("unifi", "omada"):  # si se pasa una URL completa, se usa tal cual
        cifrado = not args.http
        puerto = args.puerto or (443 if tipo == "unifi" else 8043)
    elif api:  # API clásica, para RouterOS 6: 8728 sin cifrar u 8729 con TLS
        puerto, cifrado = args.puerto or (8729 if args.api_ssl else 8728), args.api_ssl
    else:
        puerto, cifrado = args.puerto or (80 if args.http else 443), not args.http
    if args.snmp3 and args.usuario == "admin":
        raise ErrorNetTopo("Para SNMP v3 indicá el usuario v3 con --usuario.")
    equipo = Equipo(
        nombre=args.nombre, host=args.ip, tipo=tipo, usuario=args.usuario, puerto=puerto,
        https=cifrado, verificar_tls=args.verificar_tls, sitio=args.sitio, api=api,
        snmp_version="3" if args.snmp3 else "2c", snmp_auth=args.auth, snmp_priv=args.priv,
        sitio_controlador=args.sitio_controlador,
    )
    equipos.agregar(equipo, None)
    donde = equipos.guardar_clave(equipo.nombre, _claves(equipo))
    print(f"Equipo '{equipo.nombre}' agregado; clave guardada en el {donde}.")
    print("Probando la conexión...")
    try:
        _probar(argparse.Namespace(nombre=equipo.nombre))
    except ErrorNetTopo as exc:
        print(f"No se pudo conectar todavía (el equipo quedó guardado):\n{exc}")


def _clave(args: argparse.Namespace) -> None:
    equipo = equipos.buscar(args.nombre)
    donde = equipos.guardar_clave(equipo.nombre, _claves(equipo))
    print(f"Clave de '{equipo.nombre}' guardada en el {donde}.")


def _listar(_: argparse.Namespace) -> None:
    lista = equipos.cargar()
    if not lista:
        print("No hay equipos. Agregá uno con: nettopo equipo agregar NOMBRE IP")
        return
    print(f"{'NOMBRE':20} {'IP':16} {'TIPO':10} {'USUARIO':12} {'SITIO':16} CLAVE")
    for e in lista:
        clave = "sí" if equipos.leer_clave(e.nombre) is not None else "falta"
        print(f"{e.nombre:20} {e.host:16} {e.tipo:10} {e.usuario:12} {e.sitio:16} {clave}")


def _probar(args: argparse.Namespace) -> None:
    from .herramientas import controlador_resumen, mikrotik_resumen, snmp_resumen

    tipo = equipos.buscar(args.nombre).tipo
    if tipo == "snmp":
        r = snmp_resumen(args.nombre)
        print(f"OK: {r.get('nombre', '?')} — {r.get('fabricante', '?')}, {len(r.get('interfaces', []))} interfaces, "
              f"{len(r.get('vecinos_lldp', []))} vecinos LLDP ({r.get('snmp')})")
        print(f"    {r.get('descripcion', '')[:110]}")
        return
    if tipo in ("unifi", "omada"):
        r = controlador_resumen(args.nombre)
        for sitio in r["sitios"]:
            print(f"OK: sitio {sitio['sitio']}: {len(sitio['equipos'])} equipos, {sitio['clientes']} clientes"
                  + (f", desconectados: {', '.join(sitio['desconectados'])}" if sitio["desconectados"] else ""))
        return

    resumen = mikrotik_resumen(args.nombre)
    sistema = resumen["sistema"]
    print(f"OK: {resumen['identidad']} — {sistema.get('board-name', '?')}, RouterOS {sistema.get('version', '?')}, "
          f"uptime {sistema.get('uptime', '?')}")
    if resumen.get("aviso"):
        print(resumen["aviso"])


def _descubrir(args: argparse.Namespace) -> None:
    from .herramientas import mikrotik_descubrir

    resultado = mikrotik_descubrir(args.segundos)
    vecinos = resultado["mikrotik"]
    if not vecinos:
        print(resultado["nota"])
        return
    print(f"{'IDENTIDAD':22} {'IP':16} {'MAC':18} {'PLACA':18} {'VERSIÓN':22} REST")
    for v in vecinos:
        print(f"{v.get('identidad', '?'):22} {v.get('ip', '?'):16} {v.get('mac', '?'):18} {v.get('placa', '?'):18} "
              f"{v.get('version', '?'):22} {'sí' if v['rest_compatible'] else 'NO (<7.1)'}")
    for aviso in resultado.get("avisos", []):
        print("\n" + aviso)


def _cambios(args: argparse.Namespace) -> None:
    from .cambios import archivo_registro, leer_registro

    registro = leer_registro(args.ultimos)
    if not registro:
        print("Todavía no se hizo ningún cambio con NetTopo.")
        return
    for c in registro:
        print(f"{c['fecha']}  {c['resultado']:24} {c['equipo']:14} {c['accion']:12} /{c['ruta']} {c.get('id') or ''}")
        print(f"    motivo: {c.get('motivo', '')}")
        if c.get("deshacer"):
            print(f"    deshacer: {json.dumps(c['deshacer'], ensure_ascii=False)}")
    print(f"\nRegistro completo: {archivo_registro()}")


def _lab(args: argparse.Namespace) -> None:
    from . import lab

    if args.sub == "generar":
        resultado = lab.generar(args.equipo, args.profundidad, args.version_chr, args.nombre)
        print(f"Laboratorio en {resultado['carpeta']}")
        for nodo, info in resultado["nodos"].items():
            print(f"  {nodo:22} {info['equipo_real']:22} gestión {info['gestion_lab']:16} {info['puertos']} puertos")
        for enlace in resultado["enlaces"]:
            print(f"  enlace: {enlace}")
        for aviso in resultado["avisos"]:
            print(f"  aviso: {aviso}")
        print(f"Siguiente: {resultado['siguiente']}")
    elif args.sub == "registrar":
        print("Agregados al inventario: " + ", ".join(lab.registrar(args.carpeta)))
    else:
        print("Quitados del inventario: " + (", ".join(lab.olvidar(args.carpeta)) or "ninguno"))


def _ver(args: argparse.Namespace) -> None:
    from .herramientas import topologia_ver

    resultado = topologia_ver(args.archivo)
    print(resultado["archivo"])
    if not resultado["abierto"]:
        print(resultado["nota"])


def _quitar(args: argparse.Namespace) -> None:
    equipos.quitar(args.nombre)
    print(f"Equipo '{args.nombre}' quitado.")


def _mcp(_: argparse.Namespace) -> int:
    from .servidor import servir

    return servir()


def main() -> int:
    parser = argparse.ArgumentParser(prog="nettopo", description="NetTopo: herramientas de redes de CylonNet OS.")
    sub = parser.add_subparsers(dest="comando", required=True)

    sub.add_parser("mcp", help="servidor MCP para Claude Code").set_defaults(accion=_mcp)
    p = sub.add_parser("descubrir", help="MikroTik del segmento por MNDP, con aviso si son menores a 7.1")
    p.add_argument("segundos", nargs="?", type=int, default=6)
    p.set_defaults(accion=_descubrir)
    p = sub.add_parser("cambios", help="últimos cambios hechos en los equipos")
    p.add_argument("ultimos", nargs="?", type=int, default=20)
    p.set_defaults(accion=_cambios)
    p = sub.add_parser("ver", help="abre un relevamiento (por defecto el último) como mapa en el navegador")
    p.add_argument("archivo", nargs="?")
    p.set_defaults(accion=_ver)

    lab = sub.add_parser("lab", help="NetTopo Lab: copia virtual de la red").add_subparsers(dest="sub", required=True)
    p = lab.add_parser("generar", help="arma el laboratorio desde un equipo (solo lectura)")
    p.add_argument("equipo")
    p.add_argument("--profundidad", type=int, default=1)
    p.add_argument("--nombre")
    p.add_argument("--version-chr")
    p.set_defaults(accion=_lab)
    for nombre, ayuda in (("registrar", "agrega los nodos del laboratorio al inventario"),
                          ("olvidar", "quita los nodos del laboratorio del inventario")):
        p = lab.add_parser(nombre, help=ayuda)
        p.add_argument("carpeta")
        p.set_defaults(accion=_lab)

    equipo = sub.add_parser("equipo", help="inventario de equipos").add_subparsers(dest="sub", required=True)
    p = equipo.add_parser("agregar", help="agrega o reemplaza un equipo (pide la clave)")
    p.add_argument("nombre")
    p.add_argument("ip")
    p.add_argument("--usuario", default="admin")
    p.add_argument("--puerto", type=int, help="puerto REST (por defecto 443, o 80 con --http)")
    modo = p.add_mutually_exclusive_group()
    modo.add_argument("--http", action="store_true", help="usar el servicio www (sin cifrar) en vez de www-ssl")
    modo.add_argument("--api", action="store_true", help="API clásica, puerto 8728 (para RouterOS 6)")
    modo.add_argument("--api-ssl", action="store_true", help="API clásica con TLS, puerto 8729 (para RouterOS 6)")
    modo.add_argument("--snmp", action="store_true", help="switch/AP por SNMP v2c (HP/Aruba, TP-Link...): pide la comunidad")
    modo.add_argument("--snmp3", action="store_true", help="SNMP v3: --usuario es el usuario v3; pide las frases")
    modo.add_argument("--unifi", action="store_true", help="controlador UniFi (IP o URL; usuario del controlador)")
    modo.add_argument("--omada", action="store_true", help="controlador Omada 5+ (IP o URL, puerto 8043 por defecto)")
    p.add_argument("--auth", default="SHA", choices=AUTH_PROTOCOLS, help="SNMP v3: autenticación (por defecto SHA)")
    p.add_argument("--priv", default="AES", choices=PRIV_PROTOCOLS, help="SNMP v3: cifrado (por defecto AES)")
    p.add_argument("--sitio-controlador", default="", help="UniFi/Omada: consultar solo este sitio")
    p.add_argument("--sitio", default="")
    p.add_argument("--verificar-tls", action="store_true", help="exigir certificado válido")
    p.set_defaults(accion=_agregar)
    for nombre, accion, ayuda in (("clave", _clave, "cambia la clave guardada"),
                                  ("probar", _probar, "consulta la identidad del equipo"),
                                  ("quitar", _quitar, "quita el equipo y su clave")):
        p = equipo.add_parser(nombre, help=ayuda)
        p.add_argument("nombre")
        p.set_defaults(accion=accion)
    equipo.add_parser("listar", help="muestra el inventario").set_defaults(accion=_listar)

    args = parser.parse_args()
    try:
        return args.accion(args) or 0
    except ErrorNetTopo as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
