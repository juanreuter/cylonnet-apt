"""Cambios de configuración en los equipos, siempre confirmados por el usuario.

La confirmación es una ventana propia (kdialog) que abre NetTopo, por fuera de Claude: ningún modo
de Claude Code (tampoco --dangerously-skip-permissions) puede contestarla. Si no se puede mostrar la
ventana, el cambio no se aplica. Cada cambio aplicado o rechazado queda en cambios.jsonl, con el
estado anterior del registro para poder deshacerlo.
"""

from __future__ import annotations

from datetime import datetime
import html
import json
import os
import re
import shutil
import subprocess
from typing import Any

from . import equipos
from .equipos import ErrorNetTopo

ACCIONES = ("agregar", "modificar", "eliminar", "habilitar", "deshabilitar")

# Menús que NetTopo no toca nunca: usuarios y claves de acceso, paquetes, archivos, y scripts o tareas
# programadas (permitirían ejecutar cualquier cosa en el equipo).
PROHIBIDOS = ("user", "system/package", "system/script", "system/scheduler", "file", "certificate",
              "system/reset-configuration", "system/backup", "system/license")

RUTA_VALIDA = re.compile(r"[a-z0-9][a-z0-9\-/.]*")
ID_VALIDO = re.compile(r"\*[0-9A-Fa-f]+|[A-Za-z0-9][A-Za-z0-9._\-]*")
SEGUNDOS_PARA_CONTESTAR = 300


def validar_ruta(ruta: str) -> str:
    ruta = ruta.strip().strip("/").removeprefix("rest/")
    if not RUTA_VALIDA.fullmatch(ruta) or ".." in ruta:
        raise ErrorNetTopo(f"Ruta no válida: '{ruta}'. Usar el formato de menú, por ejemplo 'ip/firewall/filter'.")
    if any(ruta == p or ruta.startswith(p + "/") for p in PROHIBIDOS):
        raise ErrorNetTopo(f"NetTopo no hace cambios en '{ruta}' (usuarios, paquetes, archivos, scripts y certificados "
                           "quedan fuera). Si hace falta, el usuario lo hace a mano en WinBox o la terminal.")
    return ruta


def validar_id(id_: str | None) -> str:
    if not id_ or not ID_VALIDO.fullmatch(id_):
        raise ErrorNetTopo("Para modificar, eliminar, habilitar o deshabilitar hace falta el .id del registro "
                           "(por ejemplo '*1A'); sale de mikrotik_consultar.")
    return id_


# ── Confirmación ──────────────────────────────────────────────────────────────

def _hay_pantalla() -> bool:
    return bool(os.environ.get("WAYLAND_DISPLAY") or os.environ.get("DISPLAY"))


def _texto_confirmacion(resumen: dict[str, Any]) -> str:
    e = lambda v: html.escape(str(v))
    filas = [f"<b>Equipo:</b> {e(resumen['equipo'])} ({e(resumen['host'])})",
             f"<b>Acción:</b> {e(resumen['accion'])} en <tt>/{e(resumen['ruta'].replace('/', ' '))}</tt>"
             + (f" &nbsp;registro <tt>{e(resumen['id'])}</tt>" if resumen.get("id") else "")]
    if resumen.get("descripcion"):
        filas.append(f"<b>Registro:</b> {e(resumen['descripcion'])}")
    if resumen.get("cambios"):
        filas.append("<b>Cambios:</b>")
        for campo, (antes, despues) in resumen["cambios"].items():
            antes_txt = "—" if antes in (None, "") else e(antes)
            filas.append(f"&nbsp;&nbsp;<tt>{e(campo)}</tt>: {antes_txt} → <b>{e(despues)}</b>")
    filas.append(f"<br><b>Motivo (según Claude):</b> {e(resumen['motivo'])}")
    filas.append("<br>¿Aplicar este cambio en el equipo?")
    return "<br>".join(filas)


def confirmar(resumen: dict[str, Any]) -> bool:
    """Muestra la ventana de confirmación y devuelve True solo si el usuario elige Aplicar."""
    kdialog = shutil.which("kdialog")
    if not kdialog or not _hay_pantalla():
        raise ErrorNetTopo("No se pudo mostrar la ventana de confirmación (hace falta kdialog y una sesión gráfica). "
                           "El cambio NO se aplicó.")
    try:
        resultado = subprocess.run(
            [kdialog, "--title", "NetTopo · confirmar cambio", "--warningyesno", _texto_confirmacion(resumen),
             "--yes-label", "Aplicar", "--no-label", "Cancelar"],
            capture_output=True, timeout=SEGUNDOS_PARA_CONTESTAR)
    except subprocess.TimeoutExpired:
        return False
    return resultado.returncode == 0


# ── Registro ──────────────────────────────────────────────────────────────────

def archivo_registro():
    return equipos.dir_datos() / "cambios.jsonl"


def registrar(entrada: dict[str, Any]) -> None:
    archivo = archivo_registro()
    archivo.parent.mkdir(parents=True, exist_ok=True)
    entrada = {"fecha": datetime.now().isoformat(timespec="seconds"), **entrada}
    with archivo.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entrada, ensure_ascii=False) + "\n")


def leer_registro(ultimos: int = 30) -> list[dict[str, Any]]:
    archivo = archivo_registro()
    if not archivo.exists():
        return []
    lineas = archivo.read_text(encoding="utf-8").splitlines()[-max(1, ultimos):]
    return [json.loads(linea) for linea in lineas if linea.strip()]


def deshacer(accion: str, ruta: str, id_: str | None, antes: dict | None, despues: dict | None) -> dict[str, Any] | None:
    """La operación inversa, para que Claude pueda proponerla (también con confirmación)."""
    if accion == "agregar" and despues and despues.get(".id"):
        return {"accion": "eliminar", "ruta": ruta, "id": despues[".id"]}
    if accion == "eliminar" and antes:
        valores = {k: v for k, v in antes.items() if not k.startswith(".") and k not in ("dynamic", "invalid", "bytes", "packets")}
        return {"accion": "agregar", "ruta": ruta, "valores": valores}
    if accion in ("modificar", "habilitar", "deshabilitar") and antes and despues:
        valores = {k: antes.get(k, "") for k in despues if not k.startswith(".") and antes.get(k) != despues.get(k)}
        return {"accion": "modificar", "ruta": ruta, "id": id_, "valores": valores} if valores else None
    return None
