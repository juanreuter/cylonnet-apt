"""Controladores UniFi y Omada: lectura de sitios, equipos (APs, switches, gateways) y clientes.

NetTopo no instala controladores: se conecta a los que ya existen, por su API web, con un usuario
del controlador (alcanza con uno de solo lectura: "View Only" en UniFi, "Viewer" en Omada). Solo
consulta; nunca cambia nada. Cada controlador devuelve los datos con sus propios nombres de campo:
acá se pasan a un formato común (equipos con su enlace de subida, clientes con su AP o puerto).
"""

from __future__ import annotations

from datetime import datetime, timezone
import http.cookiejar
import json
import re
import ssl
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
import urllib.request

from . import equipos
from .equipos import Equipo, ErrorNetTopo


def _mac(valor: Any) -> str:
    limpio = re.sub(r"[^0-9a-fA-F]", "", str(valor or ""))
    return ":".join(limpio[i:i + 2] for i in range(0, 12, 2)).upper() if len(limpio) == 12 else str(valor or "").upper()


def _primero(datos: dict, *campos: str) -> Any:
    for campo in campos:
        valor = datos.get(campo)
        if valor not in (None, "", []):
            return valor
    return None


def _limpio(datos: dict) -> dict:
    return {k: v for k, v in datos.items() if v not in (None, "", [])}


def _slug(texto: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(texto).lower()).strip("-") or "x"


class _Http:
    def __init__(self, base: str, verificar_tls: bool, timeout: int = 20) -> None:
        self.base = base.rstrip("/")
        self.timeout = timeout
        contexto = ssl.create_default_context()
        if not verificar_tls:  # los controladores casi siempre tienen certificado propio
            contexto.check_hostname = False
            contexto.verify_mode = ssl.CERT_NONE
        self.cookies = http.cookiejar.CookieJar()
        self.abridor = urllib.request.build_opener(urllib.request.HTTPSHandler(context=contexto),
                                                   urllib.request.HTTPCookieProcessor(self.cookies))
        self.cabeceras: dict[str, str] = {}
        self.ultimas_cabeceras: dict[str, str] = {}

    def pedir(self, metodo: str, ruta: str, cuerpo: dict | None = None) -> Any:
        datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
        pedido = urllib.request.Request(self.base + ruta, data=datos, method=metodo,
                                        headers={"Accept": "application/json", **self.cabeceras,
                                                 **({"Content-Type": "application/json"} if datos else {})})
        try:
            with self.abridor.open(pedido, timeout=self.timeout) as respuesta:
                self.ultimas_cabeceras = {k.lower(): v for k, v in respuesta.headers.items()}
                texto = respuesta.read().decode("utf-8", "replace")
        except HTTPError as exc:
            raise _ErrorHttp(exc.code, f"HTTP {exc.code} en {ruta}") from exc
        except (URLError, OSError) as exc:
            razon = getattr(exc, "reason", exc)
            raise ErrorNetTopo(f"No se pudo conectar con {self.base}: {razon}") from exc
        try:
            return json.loads(texto) if texto.strip() else {}
        except ValueError as exc:
            raise ErrorNetTopo(f"{self.base}{ruta} no respondió JSON: ¿es la dirección del controlador?") from exc


class _ErrorHttp(ErrorNetTopo):
    def __init__(self, codigo: int, mensaje: str) -> None:
        super().__init__(mensaje)
        self.codigo = codigo


def _url(equipo: Equipo, puerto_por_defecto: int) -> str:
    host = equipo.host.strip().rstrip("/")
    if re.match(r"https?://", host):
        return host
    puerto = equipo.puerto or puerto_por_defecto
    return f"{'https' if equipo.https else 'http'}://{host}{'' if puerto in (443, 80) else f':{puerto}'}"


def _error_login(equipo: Equipo, exc: _ErrorHttp) -> ErrorNetTopo:
    if exc.codigo in (400, 401, 403):
        return ErrorNetTopo(f"El controlador rechazó el usuario '{equipo.usuario}' ({exc}). El usuario puede "
                            f"cargar la clave de nuevo con: nettopo equipo clave {equipo.nombre}. Si la cuenta "
                            "tiene verificación en dos pasos, conviene crear un usuario local de solo lectura.")
    return ErrorNetTopo(str(exc))


# ── UniFi ─────────────────────────────────────────────────────────────────────

class UniFi:
    """UniFi Network: consolas UniFi OS (UDM, Cloud Key Gen2+, UX; API bajo /proxy/network) y
    controladores clásicos (software, puerto 8443)."""

    def __init__(self, equipo: Equipo) -> None:
        self.equipo = equipo
        self.http = _Http(_url(equipo, 443), equipo.verificar_tls)
        self.prefijo = ""

    def entrar(self) -> None:
        cuerpo = {"username": self.equipo.usuario, "password": equipos._clave_obligatoria(self.equipo)}
        try:
            self.http.pedir("POST", "/api/auth/login", cuerpo)  # UniFi OS
            self.prefijo = "/proxy/network"
            token = self.http.ultimas_cabeceras.get("x-csrf-token") or self.http.ultimas_cabeceras.get("x-updated-csrf-token")
            if token:
                self.http.cabeceras["X-CSRF-Token"] = token
            return
        except _ErrorHttp as exc:
            if exc.codigo not in (404, 405):
                raise _error_login(self.equipo, exc) from exc
        try:
            self.http.pedir("POST", "/api/login", cuerpo)  # controlador clásico
        except _ErrorHttp as exc:
            raise _error_login(self.equipo, exc) from exc

    def salir(self) -> None:
        try:
            self.http.pedir("POST", "/api/auth/logout" if self.prefijo else "/api/logout", {})
        except ErrorNetTopo:
            pass

    def _datos(self, ruta: str) -> list[dict]:
        respuesta = self.http.pedir("GET", self.prefijo + ruta)
        return respuesta.get("data", []) if isinstance(respuesta, dict) else []

    def sitios(self) -> list[dict]:
        return [{"id": s.get("name"), "nombre": s.get("desc") or s.get("name")} for s in self._datos("/api/self/sites")]

    def equipos(self, sitio: str) -> list[dict]:
        tipos = {"uap": "ap", "usw": "switch", "ugw": "gateway", "udm": "gateway", "uxg": "gateway", "ubb": "puente"}
        lista = []
        for d in self._datos(f"/api/s/{quote(sitio)}/stat/device"):
            subida = d.get("uplink") or {}
            puertos = [_limpio({"puerto": p.get("port_idx"), "nombre": p.get("name"), "arriba": p.get("up"),
                                "velocidad": p.get("speed"), "poe_w": p.get("poe_power")})
                       for p in d.get("port_table") or [] if p.get("up")]
            lista.append(_limpio({
                "nombre": _primero(d, "name", "hostname", "mac"), "tipo": tipos.get(d.get("type"), d.get("type")),
                "modelo": d.get("model"), "ip": d.get("ip"), "mac": _mac(d.get("mac")),
                "estado": {1: "conectado", 0: "desconectado", 2: "adoptando", 4: "actualizando", 5: "aprovisionando",
                           6: "sin latido"}.get(d.get("state"), d.get("state")),
                "firmware": d.get("version"), "uptime_s": d.get("uptime"), "clientes": d.get("num_sta"),
                "subida": _limpio({"mac": _mac(subida.get("uplink_mac")) if subida.get("uplink_mac") else None,
                                   "puerto_remoto": subida.get("uplink_remote_port"),
                                   "puerto_local": subida.get("port_idx"), "tipo": subida.get("type")}),
                "puertos_activos": puertos,
            }))
        return lista

    def clientes(self, sitio: str) -> list[dict]:
        return [_limpio({
            "nombre": _primero(c, "name", "hostname"), "ip": c.get("ip"), "mac": _mac(c.get("mac")),
            "fabricante": c.get("oui"), "cableado": c.get("is_wired"),
            "ap_mac": _mac(c.get("ap_mac")) if c.get("ap_mac") else None, "ssid": c.get("essid"),
            "switch_mac": _mac(c.get("sw_mac")) if c.get("sw_mac") else None, "puerto": c.get("sw_port"),
            "vlan": c.get("vlan"), "red": c.get("network"), "senal_dbm": c.get("signal"), "uptime_s": c.get("uptime"),
        }) for c in self._datos(f"/api/s/{quote(sitio)}/stat/sta")]


# ── Omada ─────────────────────────────────────────────────────────────────────

class Omada:
    """Omada Controller / OC200 / OC300 / Omada Software Controller, versión 5 o más nueva."""

    def __init__(self, equipo: Equipo) -> None:
        self.equipo = equipo
        self.http = _Http(_url(equipo, 8043), equipo.verificar_tls)
        self.id = ""

    def _resultado(self, metodo: str, ruta: str, cuerpo: dict | None = None) -> Any:
        respuesta = self.http.pedir(metodo, ruta, cuerpo)
        if isinstance(respuesta, dict) and respuesta.get("errorCode", 0) != 0:
            raise ErrorNetTopo(f"Omada respondió error {respuesta.get('errorCode')}: {respuesta.get('msg', '')}")
        return respuesta.get("result") if isinstance(respuesta, dict) else None

    def entrar(self) -> None:
        info = self._resultado("GET", "/api/info") or {}
        self.id = info.get("omadacId", "")
        if not self.id:
            raise ErrorNetTopo("El controlador no informó su omadacId: NetTopo necesita Omada 5 o más nuevo.")
        cuerpo = {"username": self.equipo.usuario, "password": equipos._clave_obligatoria(self.equipo)}
        try:
            resultado = self._resultado("POST", f"/{self.id}/api/v2/login", cuerpo) or {}
        except _ErrorHttp as exc:
            raise _error_login(self.equipo, exc) from exc
        except ErrorNetTopo as exc:
            raise ErrorNetTopo(f"El controlador rechazó el usuario '{self.equipo.usuario}' ({exc}). La clave se "
                               f"carga de nuevo con: nettopo equipo clave {self.equipo.nombre}") from exc
        self.http.cabeceras["Csrf-Token"] = resultado.get("token", "")

    def salir(self) -> None:
        try:
            self.http.pedir("POST", f"/{self.id}/api/v2/logout", {})
        except ErrorNetTopo:
            pass

    def _paginas(self, ruta: str, **filtros: str) -> list[dict]:
        filas: list[dict] = []
        pagina = 1
        while True:
            consulta = urlencode({"currentPage": pagina, "currentPageSize": 500, **filtros})
            resultado = self._resultado("GET", f"/{self.id}/api/v2{ruta}?{consulta}") or {}
            if isinstance(resultado, list):
                return resultado
            datos = resultado.get("data") or []
            filas += datos
            if not datos or len(filas) >= int(resultado.get("totalRows") or 0):
                return filas
            pagina += 1

    def sitios(self) -> list[dict]:
        return [{"id": s.get("id"), "nombre": s.get("name")} for s in self._paginas("/sites")]

    def equipos(self, sitio: str) -> list[dict]:
        lista = []
        for d in self._paginas(f"/sites/{quote(sitio)}/devices"):
            lista.append(_limpio({
                "nombre": _primero(d, "name", "mac"), "tipo": d.get("type"), "modelo": d.get("model"),
                "ip": d.get("ip"), "mac": _mac(d.get("mac")),
                "estado": {0: "desconectado", 1: "conectado", 2: "pendiente", 3: "aislado"}.get(
                    d.get("statusCategory"), d.get("status")),
                "firmware": _primero(d, "firmwareVersion", "version"), "uptime_s": d.get("uptimeLong"),
                "clientes": d.get("clientNum"),
                "subida": _limpio({"mac": _mac(d["uplinkDeviceMac"]) if d.get("uplinkDeviceMac") else None,
                                   "nombre": d.get("uplinkDeviceName"), "puerto_remoto": d.get("uplinkDevicePort")}),
            }))
        return lista

    def clientes(self, sitio: str) -> list[dict]:
        return [_limpio({
            "nombre": _primero(c, "name", "hostName"), "ip": c.get("ip"), "mac": _mac(c.get("mac")),
            "fabricante": c.get("vendor"), "cableado": not c.get("wireless", False),
            "ap_mac": _mac(c.get("apMac")) if c.get("apMac") else None, "ap": c.get("apName"), "ssid": c.get("ssid"),
            "switch_mac": _mac(c.get("switchMac")) if c.get("switchMac") else None, "switch": c.get("switchName"),
            "puerto": c.get("port"), "vlan": c.get("vid"), "red": c.get("networkName"),
            "senal_dbm": c.get("rssi"), "uptime_s": c.get("uptime"),
        }) for c in self._paginas(f"/sites/{quote(sitio)}/clients", **{"filters.active": "true"})]


# ── Uso desde las herramientas ────────────────────────────────────────────────

def _abrir(nombre: str) -> UniFi | Omada:
    equipo = equipos.buscar(nombre)
    if equipo.tipo not in ("unifi", "omada"):
        raise ErrorNetTopo(f"'{equipo.nombre}' es de tipo {equipo.tipo}, no un controlador UniFi u Omada.")
    controlador = UniFi(equipo) if equipo.tipo == "unifi" else Omada(equipo)
    controlador.entrar()
    return controlador


def _sitios_elegidos(controlador: UniFi | Omada, sitio: str | None) -> list[dict]:
    sitios = controlador.sitios()
    buscado = (sitio or controlador.equipo.sitio_controlador or "").strip().lower()
    if not buscado:
        return sitios
    elegidos = [s for s in sitios if buscado in (str(s["id"]).lower(), str(s["nombre"]).lower())]
    if not elegidos:
        raise ErrorNetTopo(f"No existe el sitio '{sitio}' en el controlador. Sitios: "
                           + ", ".join(str(s["nombre"]) for s in sitios))
    return elegidos


def resumen(nombre: str, sitio: str | None = None) -> dict:
    controlador = _abrir(nombre)
    try:
        resultado = []
        for s in _sitios_elegidos(controlador, sitio):
            lista = controlador.equipos(s["id"])
            resultado.append({
                "sitio": s["nombre"], "id": s["id"], "equipos": lista,
                "desconectados": [e["nombre"] for e in lista if e.get("estado") not in ("conectado", None)],
                "clientes": sum(int(e.get("clientes") or 0) for e in lista),
            })
        return {"controlador": controlador.equipo.nombre, "tipo": controlador.equipo.tipo, "sitios": resultado}
    finally:
        controlador.salir()


def buscar_cliente(nombre: str, consulta: str, sitio: str | None = None) -> dict:
    texto = consulta.strip().lower()
    texto_mac = re.sub(r"[^0-9a-f]", "", texto)
    controlador = _abrir(nombre)
    try:
        encontrados = []
        for s in _sitios_elegidos(controlador, sitio):
            nombres = {e["mac"]: e["nombre"] for e in controlador.equipos(s["id"]) if e.get("mac")}
            for c in controlador.clientes(s["id"]):
                campos = [str(c.get(k, "")).lower() for k in ("nombre", "ip", "fabricante")]
                if any(texto in campo for campo in campos) or (len(texto_mac) >= 4 and texto_mac in c.get("mac", "").replace(":", "").lower()):
                    if c.get("ap_mac"):
                        c["conectado_a"] = f"AP {nombres.get(c['ap_mac'], c.get('ap') or c['ap_mac'])} (SSID {c.get('ssid', '?')})"
                    elif c.get("switch_mac"):
                        c["conectado_a"] = f"switch {nombres.get(c['switch_mac'], c.get('switch') or c['switch_mac'])} puerto {c.get('puerto', '?')}"
                    encontrados.append({"sitio": s["nombre"], **c})
        return {"consulta": consulta, "clientes": encontrados[:100], "total": len(encontrados)}
    finally:
        controlador.salir()


def snapshot(nombre: str, sitio: str | None = None) -> dict:
    """Relevamiento en el formato de NetTopo: equipos del controlador, enlaces de subida y clientes."""
    controlador = _abrir(nombre)
    equipo = controlador.equipo
    vendedor = "Ubiquiti" if equipo.tipo == "unifi" else "TP-Link"
    try:
        dispositivos, vecinos, hosts, avisos = [], [], [], []
        for s in _sitios_elegidos(controlador, sitio):
            lista = controlador.equipos(s["id"])
            ids = {e["mac"]: f"device-{_slug(e['mac'])}" for e in lista if e.get("mac")}
            for e in lista:
                if not e.get("mac"):
                    continue
                dispositivos.append({
                    "id": ids[e["mac"]], "name": e["nombre"],
                    "kind": {"ap": "ap", "switch": "switch", "gateway": "router"}.get(e.get("tipo"), "switch"),
                    "vendor": vendedor, "os": f"{e.get('modelo', '')} {e.get('firmware', '')}".strip(),
                    "managementIp": e.get("ip", ""), "site": s["nombre"], "networks": [], "interfaces": [],
                })
                subida = e.get("subida") or {}
                if subida.get("mac") in ids:
                    vecinos.append({
                        "localDeviceId": ids[subida["mac"]],
                        "localInterfaceName": f"puerto {subida['puerto_remoto']}" if subida.get("puerto_remoto") else "unknown",
                        "remoteDeviceId": ids[e["mac"]],
                        "remoteInterfaceName": f"puerto {subida['puerto_local']}" if subida.get("puerto_local") else "uplink",
                        "protocol": equipo.tipo, "confidence": 0.9,
                    })
            for c in controlador.clientes(s["id"]):
                origen = c.get("ap_mac") or c.get("switch_mac")
                if not c.get("mac") or origen not in ids:
                    continue
                puerto = c.get("ssid") if c.get("ap_mac") else f"puerto {c.get('puerto', '?')}"
                hosts.append({
                    "id": f"host-{_slug(c['mac'])}", "name": c.get("nombre") or c.get("ip") or c["mac"], "kind": "host",
                    "ip": c.get("ip", ""), "mac": c["mac"], "vlanId": c.get("vlan"),
                    "attachedTo": {"deviceId": ids[origen], "interfaceName": puerto},
                    "observedVia": {"deviceId": ids[origen], "interfaceName": puerto},
                })
        if not dispositivos:
            avisos.append("El controlador no devolvió equipos adoptados.")
        raiz = next((d["id"] for d in dispositivos if d["kind"] == "router"), dispositivos[0]["id"] if dispositivos else None)
        return {
            "metadata": {"name": equipo.sitio or equipo.nombre, "generatedAt": datetime.now(timezone.utc).isoformat(),
                         "source": f"{equipo.tipo}-controller", "notes": f"Relevado desde el controlador {equipo.nombre}.",
                         "warnings": avisos},
            "rootDeviceId": raiz, "devices": dispositivos, "l2Neighbors": vecinos, "hosts": hosts, "macTable": [],
        }
    finally:
        controlador.salir()
