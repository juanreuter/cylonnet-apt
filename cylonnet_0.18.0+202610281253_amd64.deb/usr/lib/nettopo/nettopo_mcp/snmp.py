"""Lectura de switches y APs por SNMP (v2c o v3): HP/Aruba, TP-Link y cualquier equipo con las MIB estándar.

Solo lectura: NetTopo nunca hace SNMP SET.
"""

from __future__ import annotations

import re
from typing import Any

from topology_collector.snmp_client import SimpleSnmpClient, SnmpCollectionError, SnmpUnavailableError
from topology_collector import snmp_snapshot as ss
from topology_collector.snmp_lldp import fetch_lldp_snapshot

from . import equipos
from .equipos import ErrorNetTopo

SYS_UPTIME = "1.3.6.1.2.1.1.3.0"
SYS_CONTACT = "1.3.6.1.2.1.1.4.0"
SYS_LOCATION = "1.3.6.1.2.1.1.6.0"
IF_OPER = "1.3.6.1.2.1.2.2.1.8"
IF_IN_ERR = "1.3.6.1.2.1.2.2.1.14"
IF_OUT_ERR = "1.3.6.1.2.1.2.2.1.20"
IF_ALIAS = "1.3.6.1.2.1.31.1.1.1.18"
IF_HIGH_SPEED = "1.3.6.1.2.1.31.1.1.1.15"
VLAN_NOMBRES = "1.3.6.1.2.1.17.7.1.4.3.1.1"
ESTADOS = {"1": "arriba", "2": "abajo", "3": "prueba", "5": "dormido", "6": "no presente", "7": "abajo (capa inferior)"}


def _limpio(datos: dict) -> dict:
    return {k: v for k, v in datos.items() if v not in (None, "", [])}


def _cliente(nombre: str) -> tuple[equipos.Equipo, SimpleSnmpClient]:
    equipo = equipos.buscar(nombre)
    try:
        return equipo, SimpleSnmpClient(equipos.config_snmp(equipo))
    except SnmpUnavailableError as exc:
        raise ErrorNetTopo("Falta el paquete snmp (snmpget/snmpwalk).") from exc
    except SnmpCollectionError as exc:
        raise ErrorNetTopo(str(exc)) from exc


def _error(equipo: equipos.Equipo, exc: Exception) -> ErrorNetTopo:
    texto = str(exc)
    if "Timeout" in texto or "timeout" in texto or "No Response" in texto:
        pista = ("El equipo no respondió. Revisá que tenga SNMP habilitado, que acepte consultas desde esta PC "
                 "y que la comunidad sea la correcta (en v2c, una comunidad equivocada se ve igual que un timeout).")
    elif "Authentication failure" in texto or "authorizationError" in texto or "Unknown user" in texto or "wrong digest" in texto.lower():
        pista = (f"El equipo rechazó las credenciales v3 del usuario '{equipo.usuario}'. Revisá usuario, protocolo "
                 f"(--auth {equipo.snmp_auth} / --priv {equipo.snmp_priv}) y frases; se cargan de nuevo con "
                 f"nettopo equipo clave {equipo.nombre}.")
    else:
        pista = "No se pudo leer por SNMP."
    return ErrorNetTopo(f"{equipo.nombre} ({equipo.host}): {texto}\n\n{pista}")


def _por_indice(filas: list[tuple[str, str]], prefijo: str) -> dict[int, str]:
    resultado = {}
    for oid, valor in filas:
        sufijo = ss._oid_suffix(oid, prefijo)
        if sufijo:
            resultado[sufijo[-1]] = valor
    return resultado


def _opcional(cliente: SimpleSnmpClient, oid: str) -> list[tuple[str, str]]:
    try:
        return cliente.walk(oid)
    except SnmpCollectionError:
        return []


def resumen(nombre: str) -> dict[str, Any]:
    equipo, cliente = _cliente(nombre)
    try:
        nombre_sis = cliente.get_scalar(ss.SYS_NAME_OID)
        descripcion = cliente.get_scalar(ss.SYS_DESCR_OID) or ""
        uptime = cliente.get_scalar(SYS_UPTIME)
        ubicacion = cliente.get_scalar(SYS_LOCATION)
        contacto = cliente.get_scalar(SYS_CONTACT)
        interfaces = ss._build_interfaces(cliente.walk(ss.IF_DESCR_OID), _opcional(cliente, ss.IF_NAME_OID))
    except SnmpCollectionError as exc:
        raise _error(equipo, exc) from exc
    estado = _por_indice(_opcional(cliente, IF_OPER), IF_OPER)
    alias = _por_indice(_opcional(cliente, IF_ALIAS), IF_ALIAS)
    velocidad = _por_indice(_opcional(cliente, IF_HIGH_SPEED), IF_HIGH_SPEED)
    err_in = _por_indice(_opcional(cliente, IF_IN_ERR), IF_IN_ERR)
    err_out = _por_indice(_opcional(cliente, IF_OUT_ERR), IF_OUT_ERR)
    redes = ss._build_networks(_opcional(cliente, ss.IP_ADDR_IFINDEX_OID), _opcional(cliente, ss.IP_ADDR_NETMASK_OID), interfaces)
    vlans = [{"vlan": ss._oid_suffix(oid, VLAN_NOMBRES)[-1], "nombre": valor}
             for oid, valor in _opcional(cliente, VLAN_NOMBRES) if ss._oid_suffix(oid, VLAN_NOMBRES)]

    lista = []
    for indice, datos in sorted(interfaces.items()):
        fila = {"indice": indice, "nombre": datos["name"], "estado": ESTADOS.get(re.sub(r"\D", "", estado.get(indice, "")) or "", estado.get(indice))}
        if alias.get(indice):
            fila["descripcion"] = alias[indice]
        if velocidad.get(indice) not in (None, "0"):
            fila["mbps"] = ss._safe_int(velocidad[indice])
        errores = (ss._safe_int(err_in.get(indice)) or 0) + (ss._safe_int(err_out.get(indice)) or 0)
        if errores:
            fila["errores"] = errores
        lista.append(fila)

    vecinos, aviso_lldp = [], None
    try:
        lldp, _ = fetch_lldp_snapshot(equipo.host, equipos.config_snmp(equipo), equipo.sitio or equipo.nombre)
        por_id = {d["id"]: d for d in lldp.get("devices", [])}
        for enlace in lldp.get("l2Neighbors", []):
            remoto = por_id.get(enlace["remoteDeviceId"], {})
            vecinos.append(_limpio({"puerto_local": enlace.get("localInterfaceName"), "vecino": remoto.get("name"),
                                      "puerto_vecino": enlace.get("remoteInterfaceName"), "ip": remoto.get("managementIp"),
                                      "fabricante": remoto.get("vendor")}))
    except Exception as exc:  # LLDP es opcional: hay equipos que no lo exponen por SNMP
        aviso_lldp = f"Vecinos LLDP no disponibles por SNMP ({exc})."

    resultado = _limpio({
        "nombre": nombre_sis, "descripcion": descripcion, "fabricante": ss._infer_vendor(descripcion),
        "uptime": uptime, "ubicacion": ubicacion, "contacto": contacto, "snmp": f"v{equipo.snmp_version}",
        "interfaces": lista, "direcciones": [{"red": r["cidr"], "interfaz": r["name"]} for r in redes],
        "vlans": vlans, "vecinos_lldp": vecinos,
    })
    if aviso_lldp:
        resultado["aviso"] = aviso_lldp
    return resultado


def buscar_host(nombre: str, consulta: str) -> dict[str, Any]:
    equipo, cliente = _cliente(nombre)
    try:
        interfaces = ss._build_interfaces(cliente.walk(ss.IF_DESCR_OID), _opcional(cliente, ss.IF_NAME_OID))
    except SnmpCollectionError as exc:
        raise _error(equipo, exc) from exc
    fdb = _opcional(cliente, ss.FDB_PORT_OID)
    tabla = ss._build_mac_table(equipo.nombre, _opcional(cliente, ss.BRIDGE_PORT_IFINDEX_OID), fdb, interfaces,
                                _opcional(cliente, ss.QFDB_PORT_OID) if not fdb else [])
    arp = ss._build_arp_map(_opcional(cliente, ss.ARP_MAC_OID))

    texto = consulta.strip().lower()
    texto_mac = re.sub(r"[^0-9a-f]", "", texto)
    macs = set()
    if len(texto_mac) >= 4 and not re.fullmatch(r"[\d.]+", texto):
        macs |= {fila["macAddress"] for fila in tabla if texto_mac in fila["macAddress"].replace(":", "").lower()}
    for ip, registro in arp["by_ip"].items():
        if texto in ip:
            macs.add(registro["mac"])

    por_puerto: dict[str, int] = {}
    for fila in tabla:
        por_puerto[fila["interfaceName"]] = por_puerto.get(fila["interfaceName"], 0) + 1
    encontrados = []
    for fila in tabla:
        if fila["macAddress"] in macs:
            encontrados.append(_limpio({
                "mac": fila["macAddress"], "puerto": fila["interfaceName"], "vlan": fila.get("vlanId"),
                "ip": (arp["by_mac"].get(fila["macAddress"]) or {}).get("ip"),
                "macs_en_ese_puerto": por_puerto[fila["interfaceName"]],
            }))
    resultado: dict[str, Any] = {"equipo": equipo.nombre, "encontrados": encontrados, "macs_en_tabla": len(tabla)}
    if not tabla:
        resultado["nota"] = "El equipo no expone su tabla de MACs por SNMP (BRIDGE-MIB / Q-BRIDGE-MIB)."
    elif not encontrados:
        resultado["nota"] = ("No aparece en la tabla de MACs de este equipo. Si buscaste por IP: los switches de capa 2 "
                             "no suelen tener tabla ARP; buscá la MAC en el router con mikrotik_buscar_host.")
    elif any(e["macs_en_ese_puerto"] > 1 for e in encontrados):
        resultado["nota"] = "Si en el puerto hay varias MACs, probablemente haya otro switch o un AP en el medio."
    return resultado


def relevar(nombre: str) -> ss.SnmpTargetSnapshotResult:
    equipo = equipos.buscar(nombre)
    try:
        return ss.collect_snmp_target_snapshot(equipo.host, equipo.sitio or equipo.nombre, equipos.config_snmp(equipo))
    except SnmpUnavailableError as exc:
        raise ErrorNetTopo("Falta el paquete snmp (snmpget/snmpwalk).") from exc
    except SnmpCollectionError as exc:
        raise _error(equipo, exc) from exc
