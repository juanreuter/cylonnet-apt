// Pantalla de inicio de sesión de CylonNet OS (tema SDDM, Qt 6).
// Backdrop, Visor, Anillo, HudField y HudButton se copian desde theme/comun al compilar.
import QtQuick

Rectangle {
    id: root
    width: 1920
    height: 1080
    color: "#04070B"

    readonly property color hielo: "#DDEFFB"
    readonly property color blanco: "#F4FBFF"
    readonly property color tenue: "#8FA9B8"
    readonly property color celeste: "#9FD4F0"
    readonly property color ambar: "#F2A33A"
    readonly property string titulo: "Michroma"
    readonly property string cuerpo: "Exo 2"
    readonly property string mono: "IBM Plex Mono"

    // Escala para pantallas chicas (diseñado para 1600×900; Hyper-V arranca en 1024×768)
    readonly property real escalaAncho: Math.min(1, width / 1600)
    readonly property real escalaAnillo: Math.max(0.55, Math.min(1, (height - 330) / 570, width / 1600 * 1.2))
    readonly property real centroAnillo: height * 0.48 - 40

    property bool otherUser: false
    // Último usuario que entró; si nadie entró todavía (recién instalado), el primero del sistema
    // (Qt.UserRole + 1 = NameRole del modelo de SDDM). "tecnico" es el del modo vivo.
    readonly property string userName: userModel.lastUser !== "" ? userModel.lastUser
        : userModel.count > 0 ? userModel.data(userModel.index(0, 0), Qt.UserRole + 1) : "tecnico"
    property date now: new Date()

    function doLogin() {
        error.visible = false;
        sddm.login(root.otherUser ? userInput.text : root.userName, password.text, sessionModel.lastIndex);
    }

    Timer {
        interval: 1000
        repeat: true
        running: true
        onTriggered: root.now = new Date()
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            error.visible = true;
            password.text = "";
            password.forceActiveFocus();
        }
    }

    Backdrop {
        anchors.fill: parent
        centerXRatio: 0.5
        centerYRatio: 0.48
    }

    // Ojo Cylon fino y rojo, igual que el del escritorio
    Visor {
        x: -20
        y: 10
        width: parent.width + 40
        height: 7
        luz: "#FF2A1F"
        halo: "#FF1A0A"
        nucleo: "#FF0800"
        latido: false
    }

    // Barra de estado superior
    Item {
        x: 40
        y: 40
        width: parent.width - 80
        height: 24
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "CYLON<font color=\"#FF2A1F\">NET</font> OS &nbsp;·&nbsp; ESTACIÓN DE RED"
            textFormat: Text.StyledText
            font.family: root.titulo
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: root.hielo
        }
        Row {
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            spacing: 8
            Text {
                text: "SISTEMA · NOMINAL"
                font.family: root.titulo
                font.pixelSize: 10
                font.letterSpacing: 2.2
                color: root.tenue
            }
            Rectangle {
                width: 6
                height: 6
                radius: 3
                anchors.verticalCenter: parent.verticalCenter
                color: "#BFE6FA"
                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    PropertyAction { value: 1 }
                    PauseAnimation { duration: 1000 }
                    PropertyAction { value: 0.25 }
                    PauseAnimation { duration: 600 }
                }
            }
        }
        Rectangle {
            anchors.bottom: parent.bottom
            width: parent.width
            height: 1
            color: root.celeste
            opacity: 0.14
        }
    }

    // Reloj
    Column {
        x: 64
        y: 110
        spacing: 6
        Text {
            text: Qt.formatTime(root.now, "HH:mm")
            font.family: root.cuerpo
            font.weight: Font.ExtraLight
            font.pixelSize: Math.round(120 * Math.max(0.6, root.escalaAncho))
            color: root.blanco
        }
        Text {
            text: root.now.toLocaleDateString(Qt.locale("es_AR"), "dddd").toUpperCase() + " · " + Qt.formatDate(root.now, "dd.MM.yyyy")
            font.family: root.mono
            font.pixelSize: 14
            font.letterSpacing: 3.4
            color: "#BFD3DE"
        }
    }

    // Anillos de escaneo con el usuario en el centro
    Anillo {
        id: ring
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.centroAnillo - height / 2
        scale: root.escalaAnillo
        inicial: (root.otherUser ? (userInput.text || "?") : root.userName).charAt(0).toUpperCase()
    }

    // Identificación
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        // El anillo está escalado: su borde visible no coincide con ring.bottom
        y: root.centroAnillo + 220 * root.escalaAnillo + 22
        spacing: 10

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: !root.otherUser
            text: root.userName.toUpperCase()
            font.family: root.titulo
            font.pixelSize: 20
            font.letterSpacing: 6.4
            color: root.blanco
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "IDENTIFICACIÓN REQUERIDA"
            font.family: root.titulo
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: root.tenue
        }

        HudField {
            id: userInput
            visible: root.otherUser
            anchors.horizontalCenter: parent.horizontalCenter
            placeholderText: "USUARIO"
            echoMode: TextInput.Normal
            onAccepted: password.forceActiveFocus()
        }

        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 10
            HudField {
                id: password
                focus: true
                placeholderText: "CONTRASEÑA"
                echoMode: TextInput.Password
                onAccepted: root.doLogin()
                Component.onCompleted: forceActiveFocus()
            }
            HudButton {
                text: "INGRESAR ›"
                onClicked: root.doLogin()
            }
        }

        Text {
            id: error
            anchors.horizontalCenter: parent.horizontalCenter
            visible: false
            text: "ACCESO DENEGADO · VERIFICÁ LA CONTRASEÑA"
            font.family: root.titulo
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: root.ambar
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.otherUser ? "VOLVER" : "OTRO USUARIO"
            font.family: root.titulo
            font.pixelSize: 9
            font.letterSpacing: 2
            color: otherArea.containsMouse ? root.hielo : root.tenue
            MouseArea {
                id: otherArea
                anchors.fill: parent
                anchors.margins: -6
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    root.otherUser = !root.otherUser;
                    (root.otherUser ? userInput : password).forceActiveFocus();
                }
            }
        }
    }

    // Estado de la red (texto fijo por ahora; luego lo alimenta NetCraft)
    Column {
        x: 64
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 36
        spacing: 6
        Repeater {
            model: [["RED ········ ", "EN LÍNEA"], ["SESIÓN ····· ", "PLASMA (WAYLAND)"]]
            Text {
                required property var modelData
                text: modelData[0] + "<font color='#DDEFFB'>" + modelData[1] + "</font>"
                textFormat: Text.StyledText
                font.family: root.mono
                font.pixelSize: 11
                font.letterSpacing: 1.3
                color: root.tenue
            }
        }
    }

    // Teclado, reiniciar y apagar
    Row {
        anchors.right: parent.right
        anchors.rightMargin: 40
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 30
        spacing: 6
        HudButton {
            visible: keyboard.layouts.length > 1
            text: keyboard.layouts.length > 0 ? keyboard.layouts[keyboard.currentLayout].shortName.toUpperCase() : ""
            dim: true
            onClicked: keyboard.currentLayout = (keyboard.currentLayout + 1) % keyboard.layouts.length
        }
        HudButton {
            visible: sddm.canReboot
            text: "REINICIAR"
            dim: true
            onClicked: sddm.reboot()
        }
        HudButton {
            visible: sddm.canPowerOff
            text: "APAGAR"
            alert: true
            onClicked: sddm.powerOff()
        }
    }
}
