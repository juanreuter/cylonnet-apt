// Fondo HUD de CylonNet OS: casi negro, cuadrícula fina, halo y anillos concéntricos.
// Es estático (no consume nada después de dibujarse una vez).
import QtQuick
import QtQuick.Shapes

Item {
    id: bg

    // Centro de los anillos, relativo al tamaño de la pantalla.
    property real centerXRatio: 0.62
    property real centerYRatio: 0.52
    readonly property real cx: width * centerXRatio
    readonly property real cy: height * centerYRatio
    readonly property color linea: "#9FD4F0"

    Rectangle {
        anchors.fill: parent
        color: "#04070B"
    }

    Shape {
        anchors.fill: parent
        ShapePath {
            strokeWidth: -1
            fillGradient: RadialGradient {
                centerX: bg.cx
                centerY: bg.cy
                centerRadius: Math.max(bg.width, bg.height) * 0.6
                focalX: bg.cx
                focalY: bg.cy
                GradientStop { position: 0.0; color: "#7328465C" }
                GradientStop { position: 1.0; color: "#0028465C" }
            }
            startX: 0; startY: 0
            PathLine { x: bg.width; y: 0 }
            PathLine { x: bg.width; y: bg.height }
            PathLine { x: 0; y: bg.height }
            PathLine { x: 0; y: 0 }
        }
    }

    // Cuadrícula de 40 px.
    Repeater {
        model: Math.ceil(bg.width / 40)
        Rectangle {
            required property int index
            x: index * 40
            width: 1
            height: bg.height
            color: bg.linea
            opacity: 0.045
        }
    }
    Repeater {
        model: Math.ceil(bg.height / 40)
        Rectangle {
            required property int index
            y: index * 40
            height: 1
            width: bg.width
            color: bg.linea
            opacity: 0.045
        }
    }

    // Anillos concéntricos y cruz.
    Repeater {
        model: [140, 260, 380, 520]
        Rectangle {
            required property var modelData
            width: modelData * 2
            height: width
            radius: modelData
            x: bg.cx - modelData
            y: bg.cy - modelData
            color: "transparent"
            border.color: bg.linea
            border.width: 1
            opacity: 0.09
        }
    }
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            strokeColor: "#389FD4F0"
            strokeWidth: 1
            fillColor: "transparent"
            strokeStyle: ShapePath.DashLine
            dashPattern: [2, 12]
            PathAngleArc { centerX: bg.cx; centerY: bg.cy; radiusX: 320; radiusY: 320; startAngle: 0; sweepAngle: 360 }
        }
        ShapePath {
            strokeColor: "#249FD4F0"
            strokeWidth: 1
            fillColor: "transparent"
            strokeStyle: ShapePath.DashLine
            dashPattern: [40, 8, 4, 8]
            PathAngleArc { centerX: bg.cx; centerY: bg.cy; radiusX: 200; radiusY: 200; startAngle: 0; sweepAngle: 360 }
        }
    }
    Rectangle { x: 0; y: bg.cy; width: bg.width; height: 1; color: bg.linea; opacity: 0.09 }
    Rectangle { x: bg.cx; y: 0; width: 1; height: bg.height; color: bg.linea; opacity: 0.09 }
}
