// Pantalla de bloqueo de CylonNet OS (la carga kscreenlocker_greet desde el tema global).
// Mismo diseño que el login SDDM; Backdrop, Visor, Anillo, HudField y HudButton se copian
// desde theme/comun al compilar. La lógica de desbloqueo sigue a la de Breeze (Plasma 6.3):
// kscreenlocker expone "authenticator", "kscreenlocker_userName" y "wallpaper".
import QtQuick
import org.kde.plasma.private.sessions 2.0

Rectangle {
    id: root
    color: "#04070B"
    implicitWidth: 1600
    implicitHeight: 900

    // Propiedades y señales que busca kscreenlocker
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false
    signal suspendToDisk()
    signal suspendToRam()
    signal clearPassword()

    readonly property color blanco: "#F4FBFF"
    readonly property color hielo: "#DDEFFB"
    readonly property color tenue: "#8FA9B8"
    readonly property color celeste: "#9FD4F0"
    readonly property color ambar: "#F2A33A"
    readonly property string titulo: "Michroma"
    readonly property string cuerpo: "Exo 2"
    readonly property string mono: "IBM Plex Mono"

    // Igual que en el login: diseñado para 1600×900, se achica en pantallas chicas.
    readonly property real escalaAncho: Math.min(1, width / 1600)
    readonly property real escalaAnillo: Math.max(0.55, Math.min(1, (height - 330) / 570, width / 1600 * 1.2))
    readonly property real centroAnillo: height * 0.48 - 40

    readonly property string userName: kscreenlocker_userName
    property date now: new Date()
    // Usuario sin contraseña: se desbloquea con un botón, no solo moviendo el mouse.
    property bool sinClave: false
    property string mensaje: ""
    // Contraseña confirmada antes de que PAM la pidiera: se envía cuando la pida.
    property string pendiente: ""

    onClearPassword: password.text = ""

    // Cuando la pantalla se bloquea sola hay unos segundos de gracia en los que kscreenlocker
    // ignora startAuthenticating(): como Breeze, se vuelve a pedir con cada actividad del
    // usuario (si ya está autenticando no hace nada).
    function despertar() {
        authenticator.startAuthenticating();
    }

    function enviar(clave) {
        if (authenticator.state !== 1) { // 1 = Authenticating
            root.pendiente = clave;
            root.despertar();
            return;
        }
        authenticator.respond(clave);
    }

    Timer {
        interval: 1000
        repeat: true
        running: true
        onTriggered: root.now = new Date()
    }

    Connections {
        target: authenticator
        function onFailed(kind) {
            if (kind != 0) { // 0 = contraseña; el resto son autenticadores no interactivos
                return;
            }
            root.mensaje = "ACCESO DENEGADO · VERIFICÁ LA CONTRASEÑA";
            password.text = "";
            reintento.restart();
        }
        function onSucceeded() {
            if (authenticator.hadPrompt) {
                Qt.quit();
            } else {
                root.sinClave = true;
            }
        }
        function onInfoMessageChanged() {
            root.mensaje = authenticator.infoMessage.toUpperCase();
        }
        function onErrorMessageChanged() {
            root.mensaje = authenticator.errorMessage.toUpperCase();
        }
        function onPromptForSecretChanged() {
            if (root.pendiente !== "" && authenticator.promptForSecret !== "") {
                authenticator.respond(root.pendiente);
                root.pendiente = "";
            }
            password.forceActiveFocus();
        }
    }

    // Después de un intento fallido se espera 3 s antes de volver a pedir la contraseña.
    Timer {
        id: reintento
        interval: 3000
        onTriggered: {
            root.mensaje = "";
            authenticator.startAuthenticating();
        }
    }

    // En X11 el greeter fuerza el teclado virtual de Qt, que tapa media pantalla al enfocar
    // la contraseña. Las PC de CylonNet tienen teclado físico: se oculta siempre.
    Connections {
        target: Qt.inputMethod
        function onVisibleChanged() {
            if (Qt.inputMethod.visible) {
                Qt.inputMethod.hide();
            }
        }
    }

    SessionManagement {
        id: sesion
        onAboutToSuspend: password.text = ""
    }

    Component.onCompleted: {
        // El fondo animado de Plasma queda tapado por el Backdrop: no gastar CPU en él.
        if (typeof wallpaper !== "undefined" && wallpaper) {
            wallpaper.visible = false;
        }
        authenticator.startAuthenticating();
        password.forceActiveFocus();
    }

    Backdrop {
        anchors.fill: parent
        centerXRatio: 0.5
        centerYRatio: 0.48
    }

    // Mover el mouse o hacer clic en cualquier lado (re)inicia la autenticación
    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        onPositionChanged: root.despertar()
        onPressed: root.despertar()
    }

    // Ojo Cylon fino y rojo, igual que el del escritorio
    Visor {
        x: -20
        y: 10
        width: parent.width + 40
        height: 7
        luz: "#FF2A1F"
        halo: "#FF1A0A"
        nucleo: "#FF0800"
        latido: false
    }

    // Barra de estado superior
    Item {
        x: 40
        y: 40
        width: parent.width - 80
        height: 24
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "CYLON<font color=\"#FF2A1F\">NET</font> OS &nbsp;·&nbsp; ESTACIÓN DE RED"
            textFormat: Text.StyledText
            font.family: root.titulo
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: root.hielo
        }
        Row {
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            spacing: 8
            Text {
                text: "SESIÓN · BLOQUEADA"
                font.family: root.titulo
                font.pixelSize: 10
                font.letterSpacing: 2.2
                color: root.ambar
            }
            Rectangle {
                width: 6
                height: 6
                radius: 3
                anchors.verticalCenter: parent.verticalCenter
                color: root.ambar
                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    PropertyAction { value: 1 }
                    PauseAnimation { duration: 1000 }
                    PropertyAction { value: 0.25 }
                    PauseAnimation { duration: 600 }
                }
            }
        }
        Rectangle {
            anchors.bottom: parent.bottom
            width: parent.width
            height: 1
            color: root.celeste
            opacity: 0.14
        }
    }

    // Reloj
    Column {
        x: 64
        y: 110
        spacing: 6
        Text {
            text: Qt.formatTime(root.now, "HH:mm")
            font.family: root.cuerpo
            font.weight: Font.ExtraLight
            font.pixelSize: Math.round(120 * Math.max(0.6, root.escalaAncho))
            color: root.blanco
        }
        Text {
            text: root.now.toLocaleDateString(Qt.locale("es_AR"), "dddd").toUpperCase() + " · " + Qt.formatDate(root.now, "dd.MM.yyyy")
            font.family: root.mono
            font.pixelSize: 14
            font.letterSpacing: 3.4
            color: "#BFD3DE"
        }
    }

    Anillo {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.centroAnillo - height / 2
        scale: root.escalaAnillo
        inicial: root.userName.charAt(0).toUpperCase()
    }

    // Identificación
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.centroAnillo + 220 * root.escalaAnillo + 22
        spacing: 10

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.userName.toUpperCase()
            font.family: root.titulo
            font.pixelSize: 20
            font.letterSpacing: 6.4
            color: root.blanco
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.sinClave ? "SESIÓN SIN CONTRASEÑA" : "CONFIRMÁ TU IDENTIDAD"
            font.family: root.titulo
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: root.tenue
        }

        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 10
            visible: !root.sinClave
            HudField {
                id: password
                focus: true
                enabled: !reintento.running
                placeholderText: "CONTRASEÑA"
                echoMode: TextInput.Password
                onTextEdited: root.despertar()
                onAccepted: root.enviar(text)
            }
            HudButton {
                text: "DESBLOQUEAR ›"
                onClicked: root.enviar(password.text)
            }
        }
        HudButton {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: root.sinClave
            text: "DESBLOQUEAR ›"
            onClicked: Qt.quit()
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: text !== ""
            text: root.mensaje
            font.family: root.titulo
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: root.ambar
        }
    }

    // Suspender y cambiar de usuario
    Row {
        anchors.right: parent.right
        anchors.rightMargin: 40
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 30
        spacing: 6
        HudButton {
            visible: sesion.canSwitchUser
            text: "CAMBIAR USUARIO"
            dim: true
            onClicked: sesion.switchUser()
        }
        HudButton {
            visible: root.suspendToRamSupported
            text: "SUSPENDER"
            dim: true
            onClicked: root.suspendToRam()
        }
    }
}
