// Campo de texto HUD con esquinas marcadas (login SDDM y pantalla de bloqueo).
import QtQuick
import QtQuick.Controls.Basic

TextField {
    width: 300
    height: 42
    leftPadding: 14
    color: "#F4FBFF"
    placeholderTextColor: "#5F7C8C"
    font.family: "IBM Plex Mono"
    font.pixelSize: 13
    font.letterSpacing: 2.6
    selectByMouse: true
    background: Rectangle {
        color: "#D905080C"
        border.color: parent.activeFocus ? "#B3DDEFFB" : "#59DDEFFB"
        Rectangle { x: -1; y: -1; width: 10; height: 2; color: "white" }
        Rectangle { x: -1; y: -1; width: 2; height: 10; color: "white" }
        Rectangle { x: parent.width - 9; y: parent.height - 1; width: 10; height: 2; color: "white" }
        Rectangle { x: parent.width - 1; y: parent.height - 9; width: 2; height: 10; color: "white" }
    }
}
