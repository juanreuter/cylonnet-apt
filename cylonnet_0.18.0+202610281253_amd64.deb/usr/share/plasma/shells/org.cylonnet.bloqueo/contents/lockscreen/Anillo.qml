// Anillos de escaneo con la inicial del usuario en el centro (login SDDM y pantalla de bloqueo).
// Mide 440×440; se achica con scale.
import QtQuick
import QtQuick.Shapes

Item {
    id: ring
    property string inicial
    readonly property color hielo: "#DDEFFB"
    readonly property color celeste: "#9FD4F0"
    readonly property color tenue: "#8FA9B8"

    width: 440
    height: 440

    Item {
        anchors.fill: parent
        RotationAnimator on rotation {
            from: 0
            to: 360
            duration: 90000
            loops: Animation.Infinite
        }
        Repeater {
            model: 120
            Rectangle {
                id: tick
                required property int index
                width: 1
                height: tick.index % 10 === 0 ? 16 : (tick.index % 5 === 0 ? 10 : 6)
                x: 220
                y: 10
                color: ring.hielo
                opacity: tick.index % 10 === 0 ? 0.85 : 0.35
                transform: Rotation { origin.x: 0; origin.y: 210; angle: tick.index * 3 }
            }
        }
    }
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        RotationAnimator on rotation {
            from: 360
            to: 0
            duration: 40000
            loops: Animation.Infinite
        }
        ShapePath {
            strokeColor: "#8C9FD4F0"
            strokeWidth: 2
            fillColor: "transparent"
            strokeStyle: ShapePath.DashLine
            dashPattern: [60, 13, 4, 13]
            PathAngleArc { centerX: 220; centerY: 220; radiusX: 186; radiusY: 186; startAngle: 0; sweepAngle: 360 }
        }
    }
    Rectangle {
        anchors.centerIn: parent
        width: 420
        height: 420
        radius: 210
        color: "transparent"
        border.color: ring.celeste
        opacity: 0.25
    }
    Rectangle {
        anchors.centerIn: parent
        width: 320
        height: 320
        radius: 160
        color: "transparent"
        border.color: ring.celeste
        opacity: 0.18
    }
    // Marcas blancas en cruz
    Repeater {
        model: [[0, 219.5, 40, 1], [400, 219.5, 40, 1], [219.5, 0, 1, 40], [219.5, 400, 1, 40]]
        Rectangle {
            required property var modelData
            x: modelData[0]
            y: modelData[1]
            width: modelData[2]
            height: modelData[3]
            color: "white"
            opacity: 0.6
        }
    }
    Text {
        x: 236
        y: 30
        text: "ID 0001"
        font.family: "IBM Plex Mono"
        font.pixelSize: 10
        font.letterSpacing: 1
        color: ring.tenue
    }
    Text {
        x: 404
        y: 236
        text: "90°"
        font.family: "IBM Plex Mono"
        font.pixelSize: 10
        font.letterSpacing: 1
        color: ring.tenue
    }
    Rectangle {
        anchors.centerIn: parent
        width: 240
        height: 240
        radius: 120
        border.color: "#8CDDEFFB"
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#A628465C" }
            GradientStop { position: 0.7; color: "#F204070B" }
        }
        Text {
            anchors.centerIn: parent
            text: ring.inicial
            font.family: "Exo 2"
            font.weight: Font.ExtraLight
            font.pixelSize: 96
            color: "#F4FBFF"
        }
    }
}
