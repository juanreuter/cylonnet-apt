// Botón rectangular de texto HUD (login SDDM y pantalla de bloqueo).
// dim = secundario, alert = acción delicada (ámbar).
import QtQuick

Rectangle {
    id: btn
    property string text
    property bool dim: false
    property bool alert: false
    signal clicked
    width: label.implicitWidth + 40
    height: dim || alert ? 38 : 42
    color: area.containsMouse ? "#269FD4F0" : (dim || alert ? "transparent" : "#1ADDEFFB")
    border.color: alert ? "#80F2A33A" : (dim ? "#33DDEFFB" : "#DDEFFB")
    Text {
        id: label
        anchors.centerIn: parent
        text: btn.text
        font.family: "Michroma"
        font.pixelSize: 10
        font.letterSpacing: 2.4
        color: btn.alert ? "#F2A33A" : (btn.dim ? "#BFD3DE" : "#F4FBFF")
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: btn.clicked()
    }
}
