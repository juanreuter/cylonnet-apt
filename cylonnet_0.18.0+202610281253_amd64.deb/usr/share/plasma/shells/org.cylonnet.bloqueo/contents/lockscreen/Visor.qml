// Visor escáner "ojo Cylon" de CylonNet OS.
// Una luz recorre la franja de lado a lado dejando estela; con latido: true, al pasar por
// el centro hace un destello corto con forma de latido de electrocardiograma.
// Lo usan el fondo de pantalla (Plasma) y la pantalla de inicio de sesión (SDDM).
import QtQuick
import QtQuick.Shapes
import QtQuick.Effects

Item {
    id: visor

    // Encendido/apagado y segundos que tarda una pasada de un extremo al otro.
    property bool animated: true
    property real passSeconds: 3
    // 0..1 = ida (izquierda a derecha), 1..2 = vuelta.
    property real phase: 0

    // Colores de la luz (estela), del halo sobre el fondo y del núcleo.
    property color luz: "#CFEAFB"
    property color halo: "#9FD4F0"
    property color nucleo: "#FF0800"
    property bool latido: true

    // Posición suavizada (0..1) para una fase cualquiera.
    function eased(p) {
        const q = ((p % 2) + 2) % 2;
        const v = q < 1 ? q : 2 - q;
        return (1 - Math.cos(Math.PI * v)) / 2;
    }
    function eyeX(p) {
        return width * (0.05 + 0.90 * eased(p));
    }

    // Intensidad del destello según cuánto avanzó la pasada actual (0..1).
    // El centro se cruza en 0.5: sube de golpe, baja, segundo golpe más débil y se apaga.
    readonly property var beatKeys: [[0.465, 0], [0.485, 1], [0.505, 0.55], [0.52, 0.85], [0.56, 0]]
    function beatAt(f) {
        const k = beatKeys;
        if (f <= k[0][0] || f >= k[k.length - 1][0])
            return 0;
        for (let i = 1; i < k.length; i++) {
            if (f <= k[i][0]) {
                const t = (f - k[i - 1][0]) / (k[i][0] - k[i - 1][0]);
                return k[i - 1][1] + (k[i][1] - k[i - 1][1]) * t;
            }
        }
        return 0;
    }
    readonly property real beat: animated && latido ? beatAt(phase % 1) : 0

    // 30 cuadros por segundo alcanzan para que se vea fluido y gasta poco.
    Timer {
        interval: 33
        repeat: true
        running: visor.animated && visor.visible
        onTriggered: visor.phase = (visor.phase + 0.033 / Math.max(0.5, visor.passSeconds)) % 2
    }

    // Halo que la luz proyecta sobre el fondo (fuera de la franja).
    Rectangle {
        width: visor.width * 0.12
        height: visor.height * 3
        y: -visor.height
        x: visor.eyeX(visor.phase) - width / 2
        radius: height / 2
        color: visor.halo
        opacity: visor.animated ? 0.22 : 0
        layer.enabled: true
        layer.effect: MultiEffect {
            blurEnabled: true
            blur: 1.0
            blurMax: 48
        }
    }

    // Contenido de la franja, recortado con forma de elipse (fina en los extremos).
    Item {
        id: slotContent
        anchors.fill: parent
        layer.enabled: true
        layer.effect: MultiEffect {
            maskEnabled: true
            maskSource: slotMask
            maskThresholdMin: 0.5
            maskSpreadAtMin: 0.5
        }

        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: "#0D000000" }
                GradientStop { position: 0.5; color: "#73000000" }
                GradientStop { position: 1.0; color: "#0D000000" }
            }
        }

        // Estela: copias de la luz que van un poco atrasadas.
        Repeater {
            model: [1, 0.6, 0.4, 0.26, 0.16, 0.08]
            Rectangle {
                required property var modelData
                required property int index
                visible: visor.animated
                width: visor.width * 0.04
                height: visor.height * 0.6
                y: visor.height * 0.2
                x: visor.eyeX(visor.phase - index * 0.023) - width / 2
                radius: height / 2
                color: visor.luz
                opacity: modelData
            }
        }

        // Núcleo: rojo más intenso que la estela.
        Rectangle {
            visible: visor.animated
            width: visor.width * 0.014
            height: visor.height * 0.4
            y: visor.height * 0.3
            x: visor.eyeX(visor.phase) - width / 2
            radius: height / 2
            color: visor.nucleo
        }
    }

    Item {
        id: slotMask
        anchors.fill: parent
        visible: false
        layer.enabled: true
        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                strokeWidth: -1
                fillColor: "white"
                PathAngleArc {
                    centerX: slotMask.width / 2
                    centerY: slotMask.height / 2
                    radiusX: slotMask.width / 2
                    radiusY: slotMask.height / 2
                    startAngle: 0
                    sweepAngle: 360
                }
            }
        }
    }

    // Destello central: resplandor, línea horizontal y trazo de electrocardiograma.
    Item {
        id: flash
        width: 260
        height: 64
        x: visor.width / 2 - width / 2
        y: visor.height / 2 - height / 2
        opacity: visor.beat
        visible: opacity > 0.01

        Rectangle {
            width: 90
            height: 90
            radius: 45
            anchors.centerIn: parent
            color: "white"
            opacity: 0.7
            layer.enabled: true
            layer.effect: MultiEffect {
                blurEnabled: true
                blur: 1.0
                blurMax: 64
            }
        }
        Rectangle {
            width: 900
            height: 2
            anchors.centerIn: parent
            gradient: Gradient {
                orientation: Gradient.Horizontal
                GradientStop { position: 0.0; color: "transparent" }
                GradientStop { position: 0.5; color: "white" }
                GradientStop { position: 1.0; color: "transparent" }
            }
        }
        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            layer.enabled: true
            layer.effect: MultiEffect {
                shadowEnabled: true
                shadowColor: visor.halo
                shadowBlur: 0.6
                shadowHorizontalOffset: 0
                shadowVerticalOffset: 0
            }
            ShapePath {
                strokeColor: "#F4FBFF"
                strokeWidth: 2
                fillColor: "transparent"
                joinStyle: ShapePath.RoundJoin
                capStyle: ShapePath.RoundCap
                startX: 0; startY: 32
                PathPolyline {
                    path: [
                        Qt.point(0, 32), Qt.point(96, 32), Qt.point(104, 27), Qt.point(112, 32),
                        Qt.point(124, 32), Qt.point(130, 38), Qt.point(138, 4), Qt.point(146, 58),
                        Qt.point(152, 32), Qt.point(168, 32), Qt.point(180, 23), Qt.point(194, 32),
                        Qt.point(260, 32)
                    ]
                }
            }
        }
    }
}
