// CylonNet: íconos del escritorio más juntos en los escritorios armados antes de este cambio. Plasma
// deja 64 px y reserva dos líneas de texto por ícono, y la columna queda muy separada; pasa a 48 px con
// una línea (etiquetas anchas para que no se corten). Plasma corre este script una sola vez por usuario
// y respeta lo que el usuario haya cambiado a mano (solo toca los valores que siguen de fábrica).
desktops().forEach(function (d) {
    d.currentConfigGroup = ["General"];
    if (String(d.readConfig("iconSize", 3)) === "3") {
        d.writeConfig("iconSize", 2);
    }
    if (String(d.readConfig("textLines", 2)) === "2") {
        d.writeConfig("textLines", 1);
    }
    if (String(d.readConfig("labelWidth", 1)) === "1") {
        d.writeConfig("labelWidth", 2);
    }
});
