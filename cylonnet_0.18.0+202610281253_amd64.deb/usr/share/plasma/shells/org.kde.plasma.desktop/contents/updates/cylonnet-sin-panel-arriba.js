// CylonNet: saca el panel invisible de arriba (org.cylonnet.barra) de los escritorios armados antes de
// la versión que lo quitó. Ese panel se corría ante las ventanas, pero reaparecía al tocar el borde de
// arriba y tapaba la barra de título de las maximizadas. Plasma corre este script una sola vez por
// usuario; deja los widgets y los íconos debajo de la franja del ojo Cylon y la línea de estado.
var FRANJA = 64;

var habiaPanel = false;
panels().forEach(function (p) {
    if (p.location === "top" && p.widgets("org.cylonnet.barra").length > 0) {
        p.remove();
        habiaPanel = true;
    }
});

if (habiaPanel) {
    desktops().forEach(function (d) {
        // Widgets Sistema y Tráfico: bajarlos lo que ocupaba el panel
        d.widgets().forEach(function (w) {
            if (w.type.indexOf("org.cylonnet.") !== 0) {
                return;
            }
            var g = w.geometry;
            if (g.y < FRANJA) {
                w.geometry = { x: g.x, y: g.y + FRANJA, width: g.width, height: g.height };
            }
        });

        // Íconos: en una columna desde la segunda fila, salvo que el usuario ya los haya acomodado a mano
        d.currentConfigGroup = ["General"];
        if (String(d.readConfig("sortMode", 0)) === "-1") {
            return;
        }
        d.writeConfig("sortMode", -1);
        var posiciones = ["1", "6"];
        ["papelera", "asistente", "equipo", "guia", "red"].forEach(function (n, fila) {
            posiciones.push("desktop:/" + n + ".desktop", "0", String(fila + 1));
        });
        var s = screenGeometry(d.screen);
        var resolucion = {};
        resolucion[s.width + "x" + s.height] = posiciones;
        d.writeConfig("positions", JSON.stringify(resolucion));
    });
}
