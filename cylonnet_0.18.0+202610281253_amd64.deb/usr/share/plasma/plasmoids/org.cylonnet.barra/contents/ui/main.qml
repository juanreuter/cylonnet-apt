// Antiguo panel de arriba de CylonNet (separador invisible). Ya no se usa: tapaba la barra de título de
// las ventanas maximizadas al tocar el borde de arriba. Queda instalado solo para que los escritorios
// armados antes lo carguen hasta que el script de actualización cylonnet-sin-panel-arriba.js lo quite.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore

PlasmoidItem {
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    fullRepresentation: Item {
        Layout.fillWidth: true
        Layout.minimumWidth: 100
        Layout.preferredHeight: 64
    }
}
