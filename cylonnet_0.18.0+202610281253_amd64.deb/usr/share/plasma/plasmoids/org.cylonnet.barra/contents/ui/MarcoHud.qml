// Marco HUD de los widgets del escritorio: fondo casi negro translúcido, borde fino y esquinas
// marcadas arriba a la izquierda y abajo a la derecha (como en la maqueta).
// Con el mouse encima aparece una × para cerrarlo (señal cerrar(); el widget lo quita del escritorio).
import QtQuick

Rectangle {
    id: marcoHud
    signal cerrar()

    color: "#D605080C"
    border.color: "#29DDEFFB"
    Rectangle { x: -1; y: -1; width: 14; height: 2; color: "#DDEFFB" }
    Rectangle { x: -1; y: -1; width: 2; height: 14; color: "#DDEFFB" }
    Rectangle { x: parent.width - 13; y: parent.height - 1; width: 14; height: 2; color: "#DDEFFB" }
    Rectangle { x: parent.width - 1; y: parent.height - 13; width: 2; height: 14; color: "#DDEFFB" }

    HoverHandler { id: encima }

    Text {
        z: 10
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.topMargin: 3
        anchors.rightMargin: 7
        visible: encima.hovered
        text: "×"
        font.pixelSize: 15
        color: cerrarBoton.containsMouse ? "#FF2A1F" : "#8FA9B8"
        MouseArea {
            id: cerrarBoton
            anchors.fill: parent
            anchors.margins: -5
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: marcoHud.cerrar()
        }
    }
}
