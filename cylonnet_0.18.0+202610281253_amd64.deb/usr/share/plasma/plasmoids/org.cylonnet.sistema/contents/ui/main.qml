// Widget "Sistema": CPU, memoria, disco y temperatura con barras finas (datos de ksystemstats).
// MarcoHud.qml se copia desde theme/comun al compilar.
import QtQuick
import QtQuick.Window
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.ksysguard.sensors as Sensors

PlasmoidItem {
    id: root
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    // Cada 2 s alcanza para ver tendencias sin gastar CPU
    readonly property int periodo: 2000

    Sensors.Sensor { id: cpu; sensorId: "cpu/all/usage"; updateRateLimit: root.periodo }
    Sensors.Sensor { id: memUsada; sensorId: "memory/physical/used"; updateRateLimit: root.periodo }
    Sensors.Sensor { id: memTotal; sensorId: "memory/physical/total"; updateRateLimit: root.periodo }
    Sensors.Sensor { id: disco; sensorId: "disk/all/usedPercent"; updateRateLimit: root.periodo }
    Sensors.Sensor { id: temp; sensorId: "cpu/all/averageTemperature"; updateRateLimit: root.periodo }

    function gb(bytes) {
        return (bytes / 1073741824).toLocaleString(Qt.locale("es_AR"), "f", 1);
    }

    fullRepresentation: MarcoHud {
        id: marco
        // Compacto en anchos chicos (el layout le da 175-210 px): letra y márgenes menores
        readonly property bool chico: width < 300
        // La × del marco lo quita del escritorio (Plasma ofrece deshacer; cylonnet-escritorio lo repone)
        onCerrar: Plasmoid.internalAction("remove").trigger()
        Layout.minimumWidth: 160
        Layout.minimumHeight: 120
        // Plasma usa este tamaño en el escritorio: la mitad del original, más chico en pantallas bajas
        Layout.preferredWidth: Screen.height < 900 ? 175 : 210
        Layout.preferredHeight: Screen.height < 900 ? 130 : 150

        Column {
            anchors.fill: parent
            anchors.margins: marco.chico ? 10 : 18
            anchors.topMargin: marco.chico ? 9 : 16
            spacing: marco.chico ? 6 : 14

            Text {
                text: "SISTEMA"
                font.family: "Michroma"
                font.pixelSize: marco.chico ? 8 : 10
                font.letterSpacing: 2.2
                color: "#DDEFFB"
            }

            Repeater {
                model: [
                    { k: "CPU", v: Math.round(cpu.value || 0) + " %", p: (cpu.value || 0) / 100 },
                    { k: "MEMORIA", v: memTotal.value ? root.gb(memUsada.value) + " / " + root.gb(memTotal.value) + " GB" : "—",
                      p: memTotal.value ? memUsada.value / memTotal.value : 0 },
                    { k: "DISCO", v: Math.round(disco.value || 0) + " %", p: (disco.value || 0) / 100 },
                    // Las máquinas virtuales no informan temperatura
                    { k: "TEMPERATURA", v: temp.value ? Math.round(temp.value) + " °C" : "—", p: temp.value ? temp.value / 100 : 0 }
                ]
                Column {
                    id: medidor
                    required property var modelData
                    width: parent.width
                    spacing: marco.chico ? 3 : 6
                    Item {
                        width: parent.width
                        height: valor.implicitHeight
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: medidor.modelData.k
                            font.family: "Michroma"
                            font.pixelSize: marco.chico ? 7 : 9
                            font.letterSpacing: marco.chico ? 1.4 : 2
                            color: "#8FA9B8"
                        }
                        Text {
                            id: valor
                            anchors.right: parent.right
                            text: medidor.modelData.v
                            font.family: "IBM Plex Mono"
                            font.pixelSize: marco.chico ? 9 : 12
                            color: "#DDEFFB"
                        }
                    }
                    Rectangle {
                        width: parent.width
                        height: marco.chico ? 2 : 3
                        color: "#249FD4F0"
                        Rectangle {
                            height: parent.height
                            width: parent.width * Math.max(0, Math.min(1, medidor.modelData.p))
                            // Arriba del 85 % se pone ámbar
                            color: medidor.modelData.p > 0.85 ? "#F2A33A" : "#DDEFFB"
                            Behavior on width { NumberAnimation { duration: 400 } }
                        }
                    }
                }
            }
        }
    }
}
