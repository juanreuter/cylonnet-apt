// Widget "Tráfico de red": bajada (hielo) y subida (ámbar) de todas las interfaces, últimos 60 s.
// MarcoHud.qml se copia desde theme/comun al compilar.
import QtQuick
import QtQuick.Window
import QtQuick.Layouts
import QtQuick.Shapes
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.ksysguard.sensors as Sensors

PlasmoidItem {
    id: root
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    readonly property int muestras: 60
    // Mbps; la escala nunca baja de 1 Mbps para que el ruido no llene el gráfico
    property var bajada: []
    property var subida: []
    readonly property real escala: Math.max(1, ...bajada, ...subida) * 1.15

    Sensors.Sensor { id: sBajada; sensorId: "network/all/download"; updateRateLimit: 1000 }
    Sensors.Sensor { id: sSubida; sensorId: "network/all/upload"; updateRateLimit: 1000 }

    function agregar(lista, bytes) {
        const l = lista.concat([(bytes || 0) * 8 / 1e6]);
        return l.length > muestras ? l.slice(l.length - muestras) : l;
    }

    function mbps(v) {
        return v === undefined ? "—" : v.toLocaleString(Qt.locale("es_AR"), "f", v < 10 ? 2 : 1);
    }

    Timer {
        interval: 1000
        repeat: true
        running: true
        onTriggered: {
            root.bajada = root.agregar(root.bajada, sBajada.value);
            root.subida = root.agregar(root.subida, sSubida.value);
        }
    }

    fullRepresentation: MarcoHud {
        id: marco
        // Compacto en anchos chicos (el layout le da 175-210 px): letra y márgenes menores
        readonly property bool chico: width < 300
        // La × del marco lo quita del escritorio (Plasma ofrece deshacer; cylonnet-escritorio lo repone)
        onCerrar: Plasmoid.internalAction("remove").trigger()
        Layout.minimumWidth: 160
        Layout.minimumHeight: 110
        // Plasma usa este tamaño en el escritorio: la mitad del original, más chico en pantallas bajas
        Layout.preferredWidth: Screen.height < 900 ? 175 : 210
        Layout.preferredHeight: Screen.height < 900 ? 115 : 135

        Item {
            anchors.fill: parent
            anchors.margins: marco.chico ? 10 : 18
            anchors.topMargin: marco.chico ? 9 : 16

            Text {
                text: "TRÁFICO DE RED"
                font.family: "Michroma"
                font.pixelSize: marco.chico ? 8 : 10
                font.letterSpacing: marco.chico ? 1.6 : 2.2
                color: "#DDEFFB"
            }
            Text {
                anchors.right: parent.right
                visible: !marco.chico
                text: "TODAS · 60 S"
                font.family: "Michroma"
                font.pixelSize: marco.chico ? 7 : 9
                font.letterSpacing: marco.chico ? 1.4 : 2
                color: "#8FA9B8"
            }

            Item {
                id: grafico
                y: marco.chico ? 18 : 28
                width: parent.width
                height: parent.height - y - (marco.chico ? 18 : 26)

                // Cuadrícula
                Repeater {
                    model: 3
                    Rectangle {
                        required property int index
                        y: grafico.height * (index + 1) / 4
                        width: grafico.width
                        height: 1
                        color: "#1A9FD4F0"
                    }
                }
                Repeater {
                    model: 5
                    Rectangle {
                        required property int index
                        x: grafico.width * (index + 1) / 6
                        width: 1
                        height: grafico.height
                        color: "#1A9FD4F0"
                    }
                }

                Shape {
                    anchors.fill: parent
                    preferredRendererType: Shape.CurveRenderer
                    ShapePath {
                        strokeColor: "#DDEFFB"
                        strokeWidth: 1.4
                        fillColor: "transparent"
                        PathPolyline { path: grafico.linea(root.bajada) }
                    }
                    ShapePath {
                        strokeColor: "#D9F2A33A"
                        strokeWidth: 1.1
                        fillColor: "transparent"
                        PathPolyline { path: grafico.linea(root.subida) }
                    }
                }

                // Puntos del gráfico: la muestra más nueva queda a la derecha
                function linea(valores) {
                    const pts = [];
                    const paso = grafico.width / (root.muestras - 1);
                    const x0 = grafico.width - (valores.length - 1) * paso;
                    for (let i = 0; i < valores.length; i++) {
                        pts.push(Qt.point(x0 + i * paso, grafico.height - 1 - valores[i] / root.escala * (grafico.height - 2)));
                    }
                    return pts;
                }
            }

            Row {
                anchors.bottom: parent.bottom
                spacing: marco.chico ? 12 : 24
                // En compacto, solo las flechas: "▼ 0,08  ▲ 1,47 Mbps"
                Text {
                    text: "<font color='#DDEFFB'>▼" + (marco.chico ? "" : " BAJADA") + "</font> "
                        + root.mbps(root.bajada[root.bajada.length - 1]) + (marco.chico ? "" : " Mbps")
                    textFormat: Text.StyledText
                    font.family: "IBM Plex Mono"
                    font.pixelSize: marco.chico ? 9 : 11
                    color: "#8FA9B8"
                }
                Text {
                    text: "<font color='#F2A33A'>▲" + (marco.chico ? "" : " SUBIDA") + "</font> "
                        + root.mbps(root.subida[root.subida.length - 1]) + " Mbps"
                    textFormat: Text.StyledText
                    font.family: "IBM Plex Mono"
                    font.pixelSize: marco.chico ? 9 : 11
                    color: "#8FA9B8"
                }
            }
        }
    }
}
