// Ajustes del fondo CylonNet: encender/apagar el visor y su velocidad.
import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: page

    property alias cfg_Animated: animatedBox.checked
    property alias cfg_Speed: speedSlider.value

    QQC2.CheckBox {
        id: animatedBox
        Kirigami.FormData.label: "Visor escáner:"
        text: "Animado"
    }

    RowLayout {
        Kirigami.FormData.label: "Segundos por pasada:"
        enabled: animatedBox.checked
        QQC2.Slider {
            id: speedSlider
            from: 1.5
            to: 6
            stepSize: 0.5
            Layout.preferredWidth: Kirigami.Units.gridUnit * 12
        }
        QQC2.Label {
            text: speedSlider.value.toFixed(1) + " s"
        }
    }
}
