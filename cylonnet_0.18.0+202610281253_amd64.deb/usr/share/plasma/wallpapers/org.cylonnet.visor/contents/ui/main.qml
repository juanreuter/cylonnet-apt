// Fondo de pantalla de CylonNet OS para Plasma 6.
// Backdrop.qml y Visor.qml se copian desde theme/comun al compilar.
import QtQuick
import org.kde.plasma.plasmoid

WallpaperItem {
    id: root

    Backdrop {
        anchors.fill: parent
    }

    // Ojo Cylon y línea de estado arriba, en el fondo y en el mismo lugar que en la pantalla de
    // inicio de sesión (SDDM): fijos en el escritorio; las ventanas los tapan como al resto del fondo.
    Visor {
        x: -20
        y: 10
        width: parent.width + 40
        height: 7
        luz: "#FF2A1F"
        halo: "#FF1A0A"
        nucleo: "#FF0800"
        latido: false
        animated: root.configuration.Animated
        passSeconds: root.configuration.Speed
    }
    Estado {
        x: 40
        y: 40
        width: parent.width - 80
        height: 24
    }

    // Emblema CN en la esquina de abajo a la derecha, por encima de la barra de tareas
    Emblema {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.rightMargin: 28
        anchors.bottomMargin: 68
        animated: root.configuration.Animated
    }
}
