// Línea de estado del escritorio, dibujada en el fondo igual que en la pantalla de inicio de sesión:
// "CYLONNET · ESTACIÓN DE RED · <equipo>" (sin el equipo si se llama cylonnet, como en vivo), fecha y
// hora, y estado del enlace (NetworkManager). Las ventanas la tapan como al resto del fondo.
import QtQuick
import org.kde.plasma.plasma5support as P5Support

Item {
    id: estado

    property date ahora: new Date()
    property string equipo: ""
    // Estado de NetworkManager en inglés (LC_ALL=C): connected, connecting, disconnected...
    property string red: ""

    readonly property var enlace: red === "connected" ? ["ESTABLE", "#DDEFFB"]
        : red.startsWith("connected") ? ["LIMITADO", "#F2A33A"]
        : red === "connecting" ? ["CONECTANDO", "#BFD3DE"]
        : red === "" ? ["—", "#8FA9B8"] : ["SIN ENLACE", "#F2A33A"]

    // Comandos cortos: se conectan, se lee la salida y se desconectan
    P5Support.DataSource {
        id: comandos
        engine: "executable"
        onNewData: (fuente, datos) => {
            const salida = (datos["stdout"] || "").trim();
            if (fuente.startsWith("hostname")) {
                estado.equipo = salida.toUpperCase();
            } else {
                estado.red = salida;
            }
            disconnectSource(fuente);
        }
    }

    Timer {
        interval: 1000
        repeat: true
        running: true
        triggeredOnStart: true
        property int vueltas: 0
        onTriggered: {
            estado.ahora = new Date();
            // El enlace cada 5 s alcanza
            if (vueltas % 5 === 0) {
                comandos.connectSource("LC_ALL=C nmcli -t -f STATE general");
            }
            vueltas++;
        }
    }

    Component.onCompleted: comandos.connectSource("hostname")

    Text {
        anchors.verticalCenter: parent.verticalCenter
        text: "CYLON<font color=\"#FF2A1F\">NET</font> · ESTACIÓN DE RED" + (estado.equipo && estado.equipo !== "CYLONNET" ? " · " + estado.equipo : "")
        textFormat: Text.StyledText
        font.family: "Michroma"
        font.pixelSize: 10
        font.letterSpacing: 2.2
        color: "#DDEFFB"
    }
    Text {
        anchors.centerIn: parent
        text: Qt.formatDate(estado.ahora, "dd.MM.yyyy") + " — " + Qt.formatTime(estado.ahora, "HH:mm:ss")
        font.family: "IBM Plex Mono"
        font.pixelSize: 12
        font.letterSpacing: 1.4
        color: "#BFE6FA"
    }
    Row {
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        spacing: 8
        Text {
            text: "ENLACE · <font color='" + estado.enlace[1] + "'>" + estado.enlace[0] + "</font>"
            textFormat: Text.StyledText
            font.family: "Michroma"
            font.pixelSize: 10
            font.letterSpacing: 2.2
            color: "#8FA9B8"
        }
        Rectangle {
            width: 6
            height: 6
            radius: 3
            anchors.verticalCenter: parent.verticalCenter
            color: estado.enlace[1]
            SequentialAnimation on opacity {
                loops: Animation.Infinite
                PropertyAction { value: 1 }
                PauseAnimation { duration: 1000 }
                PropertyAction { value: 0.25 }
                PauseAnimation { duration: 600 }
            }
        }
    }
    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width
        height: 1
        color: "#9FD4F0"
        opacity: 0.14
    }
}
