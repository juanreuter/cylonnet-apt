// Emblema "CN" de CylonNet para la esquina del escritorio: letras de metal hielo,
// anillos que giran como los del login y la línea de luz roja del visor cruzando al medio.
// Mide 200×200. Las letras y el destello se dibujan en la grilla de 1254 px del dibujo original.
import QtQuick
import QtQuick.Shapes
import QtQuick.Effects

Item {
    id: emblema
    property bool animated: true
    property color rojo: "#FF2A1F"
    readonly property color hielo: "#DDEFFB"
    readonly property color celeste: "#9FD4F0"

    width: 200
    height: 200

    // Marcas de escala que giran despacio (como el anillo del login)
    Item {
        anchors.fill: parent
        RotationAnimator on rotation {
            running: emblema.animated
            from: 0
            to: 360
            duration: 90000
            loops: Animation.Infinite
        }
        Repeater {
            model: 72
            Rectangle {
                id: marca
                required property int index
                width: 1
                height: marca.index % 6 === 0 ? 7 : 3
                x: 99.5
                y: 4
                color: emblema.hielo
                opacity: marca.index % 6 === 0 ? 0.55 : 0.2
                transform: Rotation { origin.x: 0.5; origin.y: 96; angle: marca.index * 5 }
            }
        }
    }

    // Cuatro arcos en diagonal que giran al revés; uno es rojo
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        RotationAnimator on rotation {
            running: emblema.animated
            from: 360
            to: 0
            duration: 40000
            loops: Animation.Infinite
        }
        ShapePath {
            strokeColor: "#999FD4F0"
            strokeWidth: 2
            fillColor: "transparent"
            capStyle: ShapePath.FlatCap
            PathAngleArc { centerX: 100; centerY: 100; radiusX: 84; radiusY: 84; startAngle: 20; sweepAngle: 32 }
            PathAngleArc { centerX: 100; centerY: 100; radiusX: 84; radiusY: 84; startAngle: 200; sweepAngle: 32; moveToStart: true }
            PathAngleArc { centerX: 100; centerY: 100; radiusX: 84; radiusY: 84; startAngle: 290; sweepAngle: 32; moveToStart: true }
        }
        ShapePath {
            strokeColor: emblema.rojo
            strokeWidth: 2
            fillColor: "transparent"
            capStyle: ShapePath.FlatCap
            PathAngleArc { centerX: 100; centerY: 100; radiusX: 84; radiusY: 84; startAngle: 110; sweepAngle: 32 }
        }
    }

    // Círculos finos fijos y círculo punteado que gira
    Rectangle {
        anchors.centerIn: parent
        width: 150; height: 150; radius: 75
        color: "transparent"
        border.color: emblema.celeste
        opacity: 0.18
    }
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        RotationAnimator on rotation {
            running: emblema.animated
            from: 0
            to: 360
            duration: 60000
            loops: Animation.Infinite
        }
        ShapePath {
            strokeColor: "#669FD4F0"
            strokeWidth: 1
            fillColor: "transparent"
            strokeStyle: ShapePath.DashLine
            dashPattern: [2, 6]
            PathAngleArc { centerX: 100; centerY: 100; radiusX: 68; radiusY: 68; startAngle: 0; sweepAngle: 360 }
        }
    }

    // Cruz de mira
    Rectangle { x: 99.5; y: 0; width: 1; height: 200; color: emblema.celeste; opacity: 0.08 }
    Repeater {
        model: [[99.5, 6, 1, 10], [99.5, 184, 1, 10]]
        Rectangle {
            required property var modelData
            x: modelData[0]; y: modelData[1]; width: modelData[2]; height: modelData[3]
            color: "white"
            opacity: 0.6
        }
    }

    // Letras y luz, en la grilla del dibujo original
    Item {
        width: 1254
        height: 1254
        scale: emblema.width / 1254
        transformOrigin: Item.TopLeft

        Shape {
            anchors.fill: parent
            preferredRendererType: Shape.CurveRenderer
            layer.enabled: true
            layer.effect: MultiEffect {
                shadowEnabled: true
                shadowColor: emblema.celeste
                shadowBlur: 0.5
                shadowOpacity: 0.7
                shadowHorizontalOffset: 0
                shadowVerticalOffset: 0
            }
            ShapePath {
                strokeColor: "#B3F4FBFF"
                strokeWidth: 6
                joinStyle: ShapePath.MiterJoin
                fillGradient: LinearGradient {
                    x1: 0; y1: 445; x2: 0; y2: 722
                    GradientStop { position: 0.0; color: "#EEF7FD" }
                    GradientStop { position: 0.5; color: "#B9CCDA" }
                    GradientStop { position: 1.0; color: "#7F97A8" }
                }
                // C
                PathSvg { path: "M330 445 L565 445 L600 480 L600 527 L352 527 L330 549 L330 618 L352 640 L600 640 L600 687 L565 722 L330 722 L248 640 L248 527 Z" }
                // N
                PathSvg { path: "M612 722 L612 445 L700 445 L912 628 L912 445 L955 445 L992 482 L992 722 L905 722 L692 538 L692 722 Z" }
            }
        }

        // Línea de luz roja de lado a lado, por delante de las letras
        Rectangle {
            x: 60
            y: 580
            width: 1134
            height: 5
            opacity: 0.85
            gradient: Gradient {
                orientation: Gradient.Horizontal
                GradientStop { position: 0.0; color: "transparent" }
                GradientStop { position: 0.5; color: emblema.rojo }
                GradientStop { position: 1.0; color: "transparent" }
            }
        }

        // Destello rojo en el cruce, que respira despacio
        Item {
            id: destello
            x: 627 - 160
            y: 583 - 160
            width: 320
            height: 320
            SequentialAnimation on opacity {
                running: emblema.animated
                loops: Animation.Infinite
                NumberAnimation { from: 0.55; to: 1; duration: 1800; easing.type: Easing.InOutSine }
                NumberAnimation { from: 1; to: 0.55; duration: 1800; easing.type: Easing.InOutSine }
            }
            Rectangle {
                anchors.centerIn: parent
                width: 120; height: 120; radius: 60
                color: emblema.rojo
                opacity: 0.5
                layer.enabled: true
                layer.effect: MultiEffect {
                    blurEnabled: true
                    blur: 1.0
                    blurMax: 64
                }
            }
            Rectangle {
                anchors.centerIn: parent
                width: 240; height: 6; radius: 3
                color: "#FFD8C8"
            }
            Rectangle {
                anchors.centerIn: parent
                width: 26; height: 10; radius: 5
                color: "white"
            }
        }
    }
}
