# Claude en esta notebook (CylonNet OS)

Esta notebook es la herramienta de trabajo de un técnico de redes. Este archivo da contexto en TODAS las carpetas.

- Respondé en español rioplatense.
- Para todo lo de redes usá el MCP **nettopo** (inventario de equipos, escaneos, MikroTik, topología, NetPlanner).
- Relevamientos guardados: `~/.local/share/nettopo/snapshots/`. Inventario: `nettopo equipo listar`.
- Llevá una bitácora en `~/NetTopo/bitacora.md`: al terminar cada trabajo agregá fecha, lugar/cliente, qué se hizo
  y qué quedó pendiente. Leela al empezar para tener el panorama de lo que se viene haciendo con esta notebook.
- Nunca pidas ni leas claves de equipos; las carga el usuario con `nettopo equipo clave NOMBRE`.
- Documentos: sin LibreOffice; se abren con WordCraft (.docx), GridCraft (.xlsx/.csv) y PdfCraft. Para
  generarlos, Python trae python-docx, openpyxl, xlsxwriter, pandas, odfpy, pypdf y reportlab.
